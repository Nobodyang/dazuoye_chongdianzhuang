const palette = ['#47a7ff', '#4ce4d3', '#f3bd5b', '#ec6d72'];

function currency(value) {
  return Number(value || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function baseOption() {
  return {
    animationDuration: 850,
    textStyle: { color: '#bcd3e6', fontFamily: 'Microsoft YaHei' },
    tooltip: { trigger: 'axis', backgroundColor: 'rgba(8,25,43,.96)', borderColor: '#2d6f9f', textStyle: { color: '#eaf5ff' } },
    grid: { left: 48, right: 22, top: 28, bottom: 38 },
    xAxis: { axisLine: { lineStyle: { color: '#35536b' } }, axisLabel: { color: '#86a5bd' } },
    yAxis: { splitLine: { lineStyle: { color: 'rgba(90,135,168,.16)' } }, axisLine: { show: false }, axisLabel: { color: '#86a5bd' } }
  };
}

function render(data) {
  document.getElementById('todayRevenue').textContent = currency(data.metrics.todayRevenue);
  document.getElementById('monthRevenue').textContent = currency(data.metrics.monthRevenue);
  document.getElementById('onlineRate').textContent = data.metrics.onlineRate.toFixed(1);
  document.getElementById('forecastPeak').textContent = data.metrics.forecastPeak.toFixed(1);
  document.getElementById('generated').textContent = `数据生成于 ${data.generatedAt.replace('T', ' ')}`;
  document.getElementById('modelInfo').textContent = `预测模型：${data.model.name} · ${data.model.trainingRows} 条训练记录`;
  document.getElementById('forecastNote').textContent = `预计峰值出现在 ${data.metrics.forecastPeakTime}，建议提前调度电力与运维人员。`;

  const revenue = echarts.init(document.getElementById('revenueChart'));
  revenue.setOption({
    ...baseOption(),
    xAxis: { ...baseOption().xAxis, type: 'category', data: data.revenue.map(item => item.day.slice(5)), boundaryGap: false },
    yAxis: { ...baseOption().yAxis, type: 'value', name: '元' },
    series: [{ type: 'line', smooth: true, symbol: 'none', data: data.revenue.map(item => item.revenue), lineStyle: { width: 3, color: palette[0] }, areaStyle: { color: 'rgba(71,167,255,.18)' } }]
  });

  const statusNames = { idle: '空闲', in_use: '在用', fault: '故障' };
  const status = echarts.init(document.getElementById('statusChart'));
  status.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 4, textStyle: { color: '#8ba7c1' } },
    series: [{ type: 'pie', radius: ['48%', '72%'], center: ['50%', '46%'], label: { color: '#dcefff', formatter: '{b}\n{d}%' }, itemStyle: { borderColor: '#0b1d30', borderWidth: 3 }, data: data.chargerStatus.map((item, index) => ({ name: statusNames[item.status] || item.status, value: item.count, itemStyle: { color: palette[index] } })) }]
  });

  const forecast = echarts.init(document.getElementById('forecastChart'));
  forecast.setOption({
    ...baseOption(),
    xAxis: { ...baseOption().xAxis, type: 'category', data: data.forecast.map(item => item.time.slice(6)), boundaryGap: false, axisLabel: { color: '#86a5bd', interval: 2 } },
    yAxis: { ...baseOption().yAxis, type: 'value', name: 'kW' },
    series: [{ type: 'line', smooth: true, showSymbol: false, data: data.forecast.map(item => item.loadKw), lineStyle: { width: 3, color: palette[1] }, areaStyle: { color: 'rgba(76,228,211,.16)' }, markPoint: { symbolSize: 46, data: [{ type: 'max', name: '峰值' }] } }]
  });

  const station = echarts.init(document.getElementById('stationChart'));
  station.setOption({
    ...baseOption(),
    grid: { left: 42, right: 20, top: 20, bottom: 62 },
    xAxis: { ...baseOption().xAxis, type: 'category', data: data.stationLoad.map(item => item.name.replace('充电站', '').replace('充电中心', '')), axisLabel: { color: '#86a5bd', interval: 0, rotate: 25 } },
    yAxis: { ...baseOption().yAxis, type: 'value', name: 'kW' },
    series: [{ type: 'bar', barWidth: '48%', data: data.stationLoad.map((item, index) => ({ value: item.avg_load, itemStyle: { color: palette[index % palette.length], borderRadius: [5, 5, 0, 0] } })) }]
  });

  document.getElementById('stationStrip').innerHTML = data.stations.map(item => `<article><strong>${item.name}</strong><span>${item.area} · ¥${item.price.toFixed(2)}/度</span></article>`).join('');
  window.addEventListener('resize', () => [revenue, status, forecast, station].forEach(chart => chart.resize()));
}

function updateClock() {
  document.getElementById('clock').textContent = new Date().toLocaleString('zh-CN', { hour12: false });
}
setInterval(updateClock, 1000);
updateClock();

fetch('data.json')
  .then(response => {
    if (!response.ok) throw new Error('data.json 加载失败');
    return response.json();
  })
  .then(render)
  .catch(error => {
    document.body.innerHTML = `<main><section class="panel"><h1>大屏数据加载失败</h1><p>${error.message}</p><p>请先运行 generate_dashboard.py，并通过 HTTP 服务器打开 dashboard 目录。</p></section></main>`;
  });
