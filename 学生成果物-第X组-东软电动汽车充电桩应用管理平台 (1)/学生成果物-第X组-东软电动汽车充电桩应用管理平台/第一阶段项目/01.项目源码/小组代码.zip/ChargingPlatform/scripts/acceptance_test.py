#!/usr/bin/env python3
"""ChargingPlatform protocol and credit-policy acceptance tests.

Run the Qt server first with an isolated database:
  CHARGING_DB_PATH="$PWD/data/credit-test.db" ./build/bin/charging_server
Then run:
  python3 scripts/acceptance_test.py --db data/credit-test.db
"""

from __future__ import annotations

import argparse
import json
import socket
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path


class JsonClient:
    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port
        self.socket = socket.create_connection((host, port), timeout=5)
        self.socket.settimeout(5)
        self.buffer = b""
        self.request_id = 1000
        self.session_token = ""

    def close(self) -> None:
        self.socket.close()

    def next_request(self, action: str, **payload: object) -> dict:
        self.request_id += 1
        request = {"action": action, "requestId": self.request_id, **payload}
        if self.session_token:
            request["sessionToken"] = self.session_token
        if action in {
            "recharge", "start_charging", "stop_charging", "buy_monthly_card",
            "update_profile", "create_feedback", "reply_feedback",
        } and "idempotencyKey" not in request:
            request["idempotencyKey"] = str(uuid.uuid4())
        return request

    def send(self, action: str, **payload: object) -> dict:
        request = self.next_request(action, **payload)
        self.socket.sendall(json.dumps(request, ensure_ascii=False).encode() + b"\n")
        response = self.receive()
        check(response.get("requestId") == request["requestId"], "响应 requestId 与请求一致")
        if action in {"login_user", "login_admin"} and response.get("ok"):
            self.session_token = str(response.get("data", {}).get("sessionToken", ""))
        return response

    def receive(self) -> dict:
        while b"\n" not in self.buffer:
            chunk = self.socket.recv(65536)
            if not chunk:
                raise RuntimeError("服务器提前断开连接")
            self.buffer += chunk
        line, self.buffer = self.buffer.split(b"\n", 1)
        return json.loads(line.decode())


def check(condition: bool, description: str) -> None:
    if not condition:
        raise AssertionError(description)
    print(f"[PASS] {description}")


def update_user(database: Path, user_id: int, sql: str, values: tuple = ()) -> None:
    with sqlite3.connect(database, timeout=5) as connection:
        connection.execute(f"UPDATE users SET {sql} WHERE id=?", (*values, user_id))


def user_row(database: Path, user_id: int) -> sqlite3.Row:
    with sqlite3.connect(database, timeout=5) as connection:
        connection.row_factory = sqlite3.Row
        row = connection.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if row is None:
            raise AssertionError("测试用户不存在")
        return row


def idle_charger(client: JsonClient) -> int:
    stations = client.send("list_stations", area="全部区域", latitude=39.957, longitude=116.327)
    check(stations.get("ok") and stations.get("data"), "能够查询电站")
    for station in stations["data"]:
        detail = client.send("station_detail", stationId=station["id"])
        for charger in detail.get("data", []):
            if charger.get("status") == "idle":
                return int(charger["id"])
    raise AssertionError("没有可供测试的空闲电桩")


def idle_charger_by_type(client: JsonClient, charger_type: str) -> int:
    stations = client.send("list_stations", area="全部区域", latitude=39.957, longitude=116.327)
    for station in stations.get("data", []):
        detail = client.send("station_detail", stationId=station["id"])
        for charger in detail.get("data", []):
            if charger.get("status") == "idle" and charger.get("type") == charger_type:
                return int(charger["id"])
    raise AssertionError(f"没有可供测试的{charger_type}电桩")


def wait_for(client: JsonClient, action: str, predicate, timeout: float = 6, **payload: object) -> dict:
    deadline = time.time() + timeout
    last = {}
    while time.time() < deadline:
        last = client.send(action, **payload)
        if predicate(last):
            return last
        time.sleep(0.5)
    raise AssertionError(f"等待 {action} 状态超时，最后响应：{last}")


def reset_previous_test_account(database: Path) -> None:
    """Remove only this script's account so the isolated test can be rerun."""
    if not database.exists():
        return
    with sqlite3.connect(database, timeout=5) as connection:
        row = connection.execute(
            "SELECT id FROM users WHERE phone=?", ("18800009999",)
        ).fetchone()
        if row is None:
            return
        user_id = int(row[0])
        connection.execute("DELETE FROM sessions WHERE actor_id=? AND role='user'", (user_id,))
        connection.execute(
            "DELETE FROM order_card_details WHERE order_id IN (SELECT id FROM orders WHERE user_id=?)",
            (user_id,),
        )
        connection.execute(
            "DELETE FROM order_tariff_details WHERE order_id IN (SELECT id FROM orders WHERE user_id=?)",
            (user_id,),
        )
        connection.execute(
            "DELETE FROM daily_card_usage WHERE card_id IN (SELECT id FROM user_monthly_cards WHERE user_id=?)",
            (user_id,),
        )
        connection.execute("DELETE FROM user_monthly_cards WHERE user_id=?", (user_id,))
        connection.execute(
            "DELETE FROM feedback_messages WHERE feedback_id IN (SELECT id FROM feedback WHERE user_id=?)",
            (user_id,),
        )
        connection.execute("DELETE FROM feedback WHERE user_id=?", (user_id,))
        connection.execute("DELETE FROM credit_events WHERE user_id=?", (user_id,))
        connection.execute(
            "UPDATE chargers SET status='idle' WHERE id IN "
            "(SELECT charger_id FROM orders WHERE user_id=? AND status='charging')",
            (user_id,),
        )
        connection.execute("DELETE FROM orders WHERE user_id=?", (user_id,))
        connection.execute("DELETE FROM users WHERE id=?", (user_id,))


def test_protocol(client: JsonClient, user_id: int) -> None:
    first = client.next_request("profile", userId=user_id)
    second = client.next_request("list_orders", userId=user_id)
    client.socket.sendall(
        json.dumps(first).encode() + b"\n" + json.dumps(second).encode() + b"\n"
    )
    responses = {client.receive()["requestId"], client.receive()["requestId"]}
    check(responses == {first["requestId"], second["requestId"]}, "粘包中的两个请求均被正确处理")

    fragmented = client.next_request("profile", userId=user_id)
    encoded = json.dumps(fragmented).encode() + b"\n"
    midpoint = len(encoded) // 2
    client.socket.sendall(encoded[:midpoint])
    time.sleep(0.1)
    client.socket.sendall(encoded[midpoint:])
    response = client.receive()
    check(response.get("ok") and response.get("requestId") == fragmented["requestId"],
          "拆分发送的请求可被重新组装")

    client.socket.sendall(b"{not-json}\n")
    response = client.receive()
    check(response.get("ok") is False and "JSON" in response.get("message", ""),
          "错误 JSON 被拒绝且服务器保持连接")

    response = client.send("recharge", userId=user_id, amount=-1)
    check(response.get("ok") is False, "非法充值金额被拒绝")

    no_session = JsonClient(client.host, client.port)
    try:
        response = no_session.send("profile", userId=user_id)
        check(response.get("ok") is False and "登录状态" in response.get("message", ""),
              "未携带会话令牌不能读取用户资料")
    finally:
        no_session.close()


def test_security_and_concurrency(client: JsonClient, database: Path, user_id: int) -> None:
    other = JsonClient(client.host, client.port)
    admin = JsonClient(client.host, client.port)
    try:
        other_login = other.send("login_user", phone="13800138000")
        check(other_login.get("ok") is True, "第二个用户能够建立独立会话")
        other_id = int(other_login["data"]["id"])
        spoofed = other.send("profile", userId=user_id)
        check(spoofed.get("ok") and int(spoofed["data"]["id"]) == other_id,
              "服务器忽略伪造 userId，并以会话身份为准")

        admin_login = admin.send("login_admin", username="admin", password="123456")
        check(admin_login.get("ok") is True, "PBKDF2 管理员密码可正常验证")
        wildcard = admin.send("admin_users", keyword="%")
        check(wildcard.get("ok") and not wildcard.get("data"),
              "用户搜索中的百分号按普通字符匹配")

        update_user(
            database, user_id,
            "balance_cents=10000,debt_cents=0,credit_score=60,status='normal',debt_since='',credit_penalty_points=0",
        )
        charger_id = idle_charger(client)
        started = client.send("start_charging", userId=user_id, chargerId=charger_id)
        check(started.get("ok") is True, "权限测试订单能够开始")
        order_id = int(started["data"]["orderId"])
        unauthorized_stop = other.send("stop_charging", orderId=order_id)
        check(unauthorized_stop.get("ok") is False and "其他用户" in unauthorized_stop.get("message", ""),
              "其他用户不能结束不属于自己的订单")
        unsafe_restart = admin.send("restart_charger", chargerId=charger_id,
                                    idempotencyKey=str(uuid.uuid4()))
        check(unsafe_restart.get("ok") is False and "正在充电" in unsafe_restart.get("message", ""),
              "在用电桩拒绝普通远程重启")
        check(client.send("stop_charging", orderId=order_id).get("ok") is True,
              "订单所有者可以安全结束订单")

        update_user(database, user_id, "balance_cents=0,debt_cents=0,credit_score=60,status='normal'")
        key = str(uuid.uuid4())
        first = client.send("recharge", userId=user_id, amount=20, idempotencyKey=key)
        second = client.send("recharge", userId=user_id, amount=20, idempotencyKey=key)
        check(first.get("ok") and second.get("ok") and second.get("idempotentReplay")
              and int(user_row(database, user_id)["balance_cents"]) == 2000,
              "重复充值请求只入账一次")

        update_user(database, user_id, "balance_cents=10000,debt_cents=0,credit_score=60,status='normal'")
        charger_a = idle_charger(client)
        with sqlite3.connect(database, timeout=5) as connection:
            row = connection.execute(
                "SELECT id FROM chargers WHERE status='idle' AND id!=? ORDER BY id LIMIT 1", (charger_a,)
            ).fetchone()
        if row is None:
            raise AssertionError("并发测试缺少第二个空闲电桩")
        charger_b = int(row[0])
        concurrent = JsonClient(client.host, client.port)
        concurrent_login = concurrent.send("login_user", phone="18800009999")
        check(concurrent_login.get("ok") is True, "同一用户可在第二连接建立会话")
        results: list[dict] = []
        lock = threading.Lock()

        def start_from(connection: JsonClient, charger: int) -> None:
            result = connection.send("start_charging", userId=user_id, chargerId=charger)
            with lock:
                results.append(result)

        first_thread = threading.Thread(target=start_from, args=(client, charger_a))
        second_thread = threading.Thread(target=start_from, args=(concurrent, charger_b))
        first_thread.start()
        second_thread.start()
        first_thread.join()
        second_thread.join()
        check(sum(1 for item in results if item.get("ok")) == 1,
              "两个并发开单请求只有一个成功")
        winning_order = next(int(item["data"]["orderId"]) for item in results if item.get("ok"))
        check(client.send("stop_charging", orderId=winning_order).get("ok") is True,
              "并发测试成功订单可正常结算")

        update_user(database, user_id, "balance_cents=10000,debt_cents=0,credit_score=60,status='normal'")
        update_user(database, other_id, "balance_cents=10000,debt_cents=0,credit_score=60,status='normal'")
        shared_charger = idle_charger(client)
        shared_results: list[tuple[str, dict]] = []

        def start_shared(label: str, connection: JsonClient) -> None:
            result = connection.send("start_charging", chargerId=shared_charger)
            with lock:
                shared_results.append((label, result))

        first_thread = threading.Thread(target=start_shared, args=("primary", client))
        second_thread = threading.Thread(target=start_shared, args=("other", other))
        first_thread.start()
        second_thread.start()
        first_thread.join()
        second_thread.join()
        check(sum(1 for _, item in shared_results if item.get("ok")) == 1,
              "两个用户并发占用同一电桩时只有一个成功")
        winner_label, winner_result = next(item for item in shared_results if item[1].get("ok"))
        owner_client = client if winner_label == "primary" else other
        check(owner_client.send("stop_charging", orderId=winner_result["data"]["orderId"]).get("ok"),
              "同桩并发测试成功订单可正常结算")
        old_token = other.session_token
        check(other.send("logout").get("ok"), "用户可以主动退出会话")
        other.session_token = old_token
        revoked = other.send("profile", userId=other_id)
        check(revoked.get("ok") is False and "登录状态" in revoked.get("message", ""),
              "退出后的旧会话令牌立即失效")
        concurrent.close()
    finally:
        other.close()
        admin.close()


def test_tariff_card_and_feedback(client: JsonClient, database: Path, user_id: int) -> None:
    tariffs = client.send("tariffs")
    check(tariffs.get("ok") and any(
        row.get("card_multiplier") == 2 and row.get("multiplier_percent", 0) > 100
        for row in tariffs.get("data", [])
    ), "峰谷电价包含高峰溢价及月卡双倍消耗规则")

    update_user(database, user_id,
                "balance_cents=10000,debt_cents=0,credit_score=8,status='normal',debt_since='',credit_penalty_points=0")
    plans = client.send("monthly_card_plans")
    slow_plan = next(row for row in plans.get("data", []) if row.get("charger_type") == "慢充")
    purchase_key = str(uuid.uuid4())
    purchase = client.send("buy_monthly_card", userId=user_id, planId=slow_plan["id"],
                           idempotencyKey=purchase_key)
    replay = client.send("buy_monthly_card", userId=user_id, planId=slow_plan["id"],
                         idempotencyKey=purchase_key)
    cards = client.send("my_monthly_cards", userId=user_id)
    check(purchase.get("ok") and replay.get("idempotentReplay") and len(cards.get("data", [])) == 1,
          "月卡购买幂等且每日额度可查询")

    update_user(database, user_id, "balance_cents=0,credit_score=8,status='normal'")
    slow_charger = idle_charger_by_type(client, "慢充")
    started = client.send("start_charging", userId=user_id, chargerId=slow_charger)
    check(started.get("ok") and started.get("data", {}).get("firstMinuteCardCovered"),
          "最低信誉用户余额为零时仍可使用已预付月卡额度")
    stopped = client.send("stop_charging", orderId=started["data"]["orderId"])
    check(stopped.get("ok") and stopped.get("data", {}).get("cardDiscount", 0) > 0,
          "结算显示月卡抵扣并扣减当日等效分钟")

    created = client.send("create_feedback", userId=user_id, category="计费问题",
                          title="验收测试反馈", content="请核对月卡抵扣明细。")
    feedback_id = int(created.get("data", {}).get("feedbackId", 0))
    mine = client.send("my_feedback", userId=user_id)
    check(created.get("ok") and any(int(row["id"]) == feedback_id for row in mine.get("data", [])),
          "用户可以创建并查看客服反馈")

    admin = JsonClient(client.host, client.port)
    try:
        check(admin.send("login_admin", username="admin", password="123456").get("ok"),
              "客服验收管理员登录成功")
        tickets = admin.send("admin_feedback")
        check(any(int(row["id"]) == feedback_id for row in tickets.get("data", [])),
              "管理员可以查看用户反馈")
        replied = admin.send("admin_reply_feedback", feedbackId=feedback_id,
                             content="已核对，抵扣记录正常。", idempotencyKey=str(uuid.uuid4()))
        check(replied.get("ok"), "管理员可以回复反馈")
    finally:
        admin.close()
    messages = client.send("feedback_messages", userId=user_id, feedbackId=feedback_id)
    check(messages.get("ok") and any(
        row.get("sender_role") == "admin" for row in messages.get("data", {}).get("messages", [])
    ), "用户可以看到管理员回复")


def test_credit(client: JsonClient, database: Path, user_id: int) -> None:
    charger_id = idle_charger(client)

    update_user(
        database,
        user_id,
        "balance_cents=0,credit_score=8,debt_cents=0,debt_since='',credit_penalty_points=0,status='normal'",
    )
    response = client.send("start_charging", userId=user_id, chargerId=charger_id)
    check(response.get("ok") is False and "最低" in response.get("message", ""),
          "0～10 分且余额为零时禁止开始充电")

    update_user(
        database,
        user_id,
        "balance_cents=10000,credit_score=60,debt_cents=0,debt_since='',credit_penalty_points=0,status='normal'",
    )
    response = client.send("start_charging", userId=user_id, chargerId=charger_id)
    check(response.get("ok") is True, "余额充足时可以开始充电")
    order_id = int(response["data"]["orderId"])
    ten_minutes_ago = (datetime.now() - timedelta(minutes=10)).isoformat(timespec="seconds")
    with sqlite3.connect(database, timeout=5) as connection:
        connection.execute("UPDATE orders SET started_at=? WHERE id=?", (ten_minutes_ago, order_id))
    response = client.send("stop_charging", orderId=order_id)
    check(response.get("ok") and response["data"].get("creditScore") == 61,
          "正常结清订单后信誉分增加 1 分")

    update_user(
        database,
        user_id,
        "balance_cents=0,credit_score=11,debt_cents=0,debt_since='',credit_penalty_points=0,status='normal'",
    )
    charger_id = idle_charger(client)
    response = client.send("start_charging", userId=user_id, chargerId=charger_id)
    check(response.get("ok") is True, "11 分用户可使用 10 元信誉额度开始充电")
    auto_order_id = int(response["data"]["orderId"])
    five_minutes_ago = (datetime.now() - timedelta(minutes=10)).isoformat(timespec="seconds")
    with sqlite3.connect(database, timeout=5) as connection:
        connection.execute("UPDATE orders SET started_at=? WHERE id=?", (five_minutes_ago, auto_order_id))
    wait_for(
        client,
        "active_order",
        lambda item: item.get("ok") and not item.get("data", {}).get("active", True),
        userId=user_id,
    )
    with sqlite3.connect(database, timeout=5) as connection:
        row = connection.execute(
            "SELECT status,outstanding,auto_stopped FROM orders WHERE id=?", (auto_order_id,)
        ).fetchone()
    check(row is not None and row[0] == "unpaid" and row[1] > 0 and row[2] == 1,
          "费用达到额度边界后自动停桩并生成欠费")

    first_overdue = (datetime.now() - timedelta(seconds=181)).isoformat(timespec="seconds")
    update_user(
        database,
        user_id,
        "credit_score=11,debt_since=?,credit_penalty_points=0,status='normal'",
        (first_overdue,),
    )
    wait_for(
        client,
        "profile",
        lambda item: item.get("data", {}).get("credit_score") == 9,
        userId=user_id,
    )
    check(user_row(database, user_id)["credit_penalty_points"] == 2,
          "欠费满 3 分钟首次扣除 2 分")

    second_overdue = (datetime.now() - timedelta(seconds=361)).isoformat(timespec="seconds")
    update_user(
        database,
        user_id,
        "credit_score=9,debt_since=?,credit_penalty_points=2",
        (second_overdue,),
    )
    wait_for(
        client,
        "profile",
        lambda item: item.get("data", {}).get("credit_score") == 8,
        userId=user_id,
    )
    check(user_row(database, user_id)["credit_penalty_points"] == 3,
          "此后每增加 3 分钟继续扣除 1 分")

    debt = int(user_row(database, user_id)["debt_cents"]) / 100.0
    response = client.send("recharge", userId=user_id, amount=debt)
    check(response.get("ok") and response.get("data", {}).get("debt", 1) <= 0.005,
          "充值优先偿还欠费并停止逾期计时")

    update_user(
        database,
        user_id,
        "balance_cents=10000,credit_score=11,debt_cents=0,debt_since='',credit_penalty_points=0,status='normal'",
    )
    charger_id = idle_charger(client)
    response = client.send("start_charging", userId=user_id, chargerId=charger_id)
    check(response.get("ok") is True, "封号测试订单能够开始")
    banned_order_id = int(response["data"]["orderId"])
    update_user(database, user_id, "credit_score=0,status='banned'")
    wait_for(
        client,
        "active_order",
        lambda item: item.get("ok") and not item.get("data", {}).get("active", True),
        userId=user_id,
    )
    with sqlite3.connect(database, timeout=5) as connection:
        row = connection.execute(
            "SELECT auto_stopped FROM orders WHERE id=?", (banned_order_id,)
        ).fetchone()
    check(row is not None and row[0] == 1 and user_row(database, user_id)["credit_score"] == 0,
          "信誉分降至 0 后活动订单被停止且不会因结算恢复分数")
    response = client.send("login_user", phone="18800009999")
    check(response.get("ok") is False and "封禁" in response.get("message", ""),
          "信誉分降至 0 后账号被封禁")


def main() -> None:
    parser = argparse.ArgumentParser(description="充电平台协议与信誉分验收测试")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=9999, type=int)
    parser.add_argument("--db", type=Path, help="服务器正在使用的独立测试数据库")
    arguments = parser.parse_args()

    if arguments.db is not None:
        reset_previous_test_account(arguments.db.resolve())

    client = JsonClient(arguments.host, arguments.port)
    try:
        login = client.send("login_user", phone="18800009999")
        check(login.get("ok") is True, "测试用户能够登录或自动注册")
        user_id = int(login["data"]["id"])
        test_protocol(client, user_id)
        if arguments.db is not None:
            database = arguments.db.resolve()
            check(database.exists(), "信誉测试数据库存在")
            test_security_and_concurrency(client, database, user_id)
            test_tariff_card_and_feedback(client, database, user_id)
            test_credit(client, database, user_id)
        else:
            print("[SKIP] 未指定 --db，仅完成无侵入协议测试")
    finally:
        client.close()
    print("\n全部验收测试通过。")


if __name__ == "__main__":
    main()
