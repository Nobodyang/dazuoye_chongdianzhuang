#!/usr/bin/env python3
"""Execute the table contract embedded in database_manager.cpp without Qt.

This is a fast structural test for CI. Full protocol/business acceptance still
requires the compiled Qt server and scripts/acceptance_test.py.
"""

from __future__ import annotations

import ast
import re
import sqlite3
from pathlib import Path


def cpp_string_items(block: str) -> list[str]:
    body = block[block.index("{") + 1 :]
    items: list[str] = []
    current: list[str] = []
    in_string = False
    escaped = False
    for character in body:
        if in_string:
            current.append(character)
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                in_string = False
        elif character == '"':
            in_string = True
            current.append(character)
        elif character == ",":
            literals = re.findall(r'"(?:\\.|[^"\\])*"', "".join(current))
            if literals:
                items.append("".join(ast.literal_eval(item) for item in literals))
            current = []
        else:
            current.append(character)
    literals = re.findall(r'"(?:\\.|[^"\\])*"', "".join(current))
    if literals:
        items.append("".join(ast.literal_eval(item) for item in literals))
    return items


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    source = (root / "server" / "database_manager.cpp").read_text(encoding="utf-8")
    start = source.index("const QStringList statements = {")
    end = source.index("    };", start)
    statements = cpp_string_items(source[start:end])
    if len(statements) < 17:
        raise AssertionError(f"只提取到 {len(statements)} 条建表语句")

    connection = sqlite3.connect(":memory:")
    connection.execute("PRAGMA foreign_keys=ON")
    for statement in statements:
        connection.execute(statement)

    connection.executescript(
        """
        INSERT INTO users(phone,nickname,balance,balance_cents,status,registered_at)
          VALUES('18800001111','A',100,10000,'normal','2026-09-03T12:00:00');
        INSERT INTO users(phone,nickname,balance,balance_cents,status,registered_at)
          VALUES('18800002222','B',100,10000,'normal','2026-09-03T12:00:00');
        INSERT INTO stations(name,area,address,latitude,longitude,price,price_cents,created_at)
          VALUES('S','A','X',0,0,1.38,138,'2026-09-03T12:00:00');
        INSERT INTO chargers(station_id,code,type,power,status) VALUES(1,'C1','快充',120,'in_use');
        INSERT INTO chargers(station_id,code,type,power,status) VALUES(1,'C2','快充',120,'idle');
        INSERT INTO orders(user_id,charger_id,status,started_at) VALUES(1,1,'charging','2026-09-03T12:00:00');
        """
    )
    invariant_start = source.index("const QStringList invariants = {")
    invariant_end = source.index("    };", invariant_start)
    invariants = cpp_string_items(source[invariant_start:invariant_end])
    for statement in invariants:
        connection.execute(statement)

    for sql in (
        "INSERT INTO orders(user_id,charger_id,status,started_at) VALUES(1,2,'charging','2026-09-03T12:00:01')",
        "INSERT INTO orders(user_id,charger_id,status,started_at) VALUES(2,1,'charging','2026-09-03T12:00:01')",
    ):
        try:
            connection.execute(sql)
        except sqlite3.IntegrityError:
            pass
        else:
            raise AssertionError("活动订单唯一索引未阻止并发冲突")

    try:
        connection.execute("UPDATE users SET balance_cents=-1 WHERE id=1")
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("钱包非负约束未生效")

    connection.execute("UPDATE users SET balance_cents=1234,debt_cents=56 WHERE id=1")
    money = connection.execute("SELECT balance,debt FROM users WHERE id=1").fetchone()
    if money != (12.34, 0.56):
        raise AssertionError(f"兼容金额触发器错误：{money}")

    required = {"sessions", "idempotency_keys", "tariff_periods", "monthly_card_plans",
                "user_monthly_cards", "daily_card_usage", "feedback", "feedback_messages",
                "order_tariff_details", "audit_logs", "credit_events"}
    actual = {row[0] for row in connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    )}
    missing = required - actual
    if missing:
        raise AssertionError(f"缺少 V1.2 表：{sorted(missing)}")
    views = {row[0] for row in connection.execute(
        "SELECT name FROM sqlite_master WHERE type='view'"
    )}
    if {"v_user_accounts", "v_order_settlements", "v_monthly_card_usage",
        "v_feedback_overview"} - views:
        raise AssertionError("V1.2 管理视图未完整创建")
    print("[PASS] V1.2 数据库结构、金额约束和活动订单唯一索引")


if __name__ == "__main__":
    main()
