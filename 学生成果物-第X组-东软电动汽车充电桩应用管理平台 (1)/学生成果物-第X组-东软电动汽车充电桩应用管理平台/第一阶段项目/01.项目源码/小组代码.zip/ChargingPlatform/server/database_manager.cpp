#include "database_manager.h"

#include "business_rules.h"
#include "database_transaction.h"
#include "security_utils.h"

#include <QBuffer>
#include <QDate>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QImage>
#include <QImageReader>
#include <QJsonDocument>
#include <QMap>
#include <QProcessEnvironment>
#include <QRegularExpression>
#include <QSaveFile>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QStandardPaths>
#include <QStringList>
#include <QUuid>
#include <QtMath>

#include <algorithm>

namespace {

double distanceKilometers(double latitude1,
                          double longitude1,
                          double latitude2,
                          double longitude2)
{
    const double earthRadius = 6371.0;
    const double latDelta = qDegreesToRadians(latitude2 - latitude1);
    const double lonDelta = qDegreesToRadians(longitude2 - longitude1);
    const double a = qPow(qSin(latDelta / 2.0), 2.0)
            + qCos(qDegreesToRadians(latitude1))
            * qCos(qDegreesToRadians(latitude2))
            * qPow(qSin(lonDelta / 2.0), 2.0);
    return earthRadius * 2.0 * qAtan2(qSqrt(a), qSqrt(1.0 - a));
}

QString nowIso()
{
    return QDateTime::currentDateTime().toString(Qt::ISODate);
}

QString todayIso()
{
    return QDate::currentDate().toString(Qt::ISODate);
}

QString transactionFailure(const QString &message, const DatabaseTransaction &transaction)
{
    QString details = transaction.error();
    if (!transaction.rollbackError().isEmpty()) {
        details += (details.isEmpty() ? QString() : QString("；"))
                + "回滚失败：" + transaction.rollbackError();
    }
    return details.isEmpty() ? message : message + "：" + details;
}

bool requiresIdempotency(const QString &action)
{
    static const QStringList actions = {
        "recharge", "start_charging", "stop_charging", "buy_monthly_card",
        "update_profile", "create_feedback", "reply_feedback",
        "admin_reply_feedback", "update_feedback_status", "restart_charger",
        "add_station", "toggle_user"
    };
    return actions.contains(action);
}

bool isPublicAction(const QString &action)
{
    return action == "login_user" || action == "login_admin"
            || action == "list_stations" || action == "station_detail"
            || action == "tariffs" || action == "monthly_card_plans";
}

bool isAdminAction(const QString &action)
{
    return action == "dashboard" || action == "admin_chargers"
            || action == "restart_charger" || action == "admin_stations"
            || action == "add_station" || action == "admin_users"
            || action == "toggle_user" || action == "admin_orders"
            || action == "admin_monthly_cards"
            || action == "admin_feedback" || action == "admin_reply_feedback"
            || action == "update_feedback_status" || action == "audit_logs";
}

QJsonArray jsonArrayFromString(const QString &text)
{
    const QJsonDocument document = QJsonDocument::fromJson(text.toUtf8());
    return document.isArray() ? document.array() : QJsonArray();
}

int normalizedCreditScore(int score)
{
    return qBound(0, score, 100);
}

int creditLimitForScore(int score)
{
    const int normalized = normalizedCreditScore(score);
    if (normalized <= 10) {
        return 0;
    }
    if (normalized <= 30) {
        return 10;
    }
    if (normalized <= 60) {
        return 30;
    }
    if (normalized <= 89) {
        return 80;
    }
    return 200;
}

QString creditLevelForScore(int score)
{
    const int normalized = normalizedCreditScore(score);
    if (normalized == 0) {
        return "封禁";
    }
    if (normalized <= 10) {
        return "最低";
    }
    if (normalized <= 30) {
        return "较低";
    }
    if (normalized <= 60) {
        return "一般";
    }
    if (normalized <= 89) {
        return "良好";
    }
    return "优秀";
}

double chargingFee(double power, double price, int minutes)
{
    const double energy = power * qMax(1, minutes) / 60.0 * 0.85;
    return qRound(energy * price * 100.0) / 100.0;
}

} // namespace

DatabaseManager::DatabaseManager()
    : m_connectionName("charging_server_main")
{
}

DatabaseManager::~DatabaseManager()
{
    if (m_database.isValid()) {
        m_database.close();
    }
}

bool DatabaseManager::open()
{
    QString configuredPath = qEnvironmentVariable("CHARGING_DB_PATH");
    if (configuredPath.isEmpty()) {
        const QString dataDirectory =
                QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        QDir().mkpath(dataDirectory);
        configuredPath = QDir(dataDirectory).filePath("charging_platform.db");
    } else {
        QDir().mkpath(QFileInfo(configuredPath).absolutePath());
    }

    m_databasePath = configuredPath;
    m_database = QSqlDatabase::addDatabase("QSQLITE", m_connectionName);
    m_database.setDatabaseName(m_databasePath);

    if (!m_database.open()) {
        m_lastError = m_database.lastError().text();
        return false;
    }

    if (!execute("PRAGMA foreign_keys = ON")
            || !execute("PRAGMA journal_mode = WAL")
            || !createTables()
            || !migrateSchema()
            || !seedData()) {
        return false;
    }
    return true;
}

QString DatabaseManager::databasePath() const
{
    return m_databasePath;
}

QString DatabaseManager::lastError() const
{
    return m_lastError;
}

bool DatabaseManager::execute(const QString &sql)
{
    QSqlQuery query(m_database);
    if (!query.exec(sql)) {
        m_lastError = query.lastError().text() + " | SQL: " + sql;
        return false;
    }
    return true;
}

bool DatabaseManager::createTables()
{
    const QStringList statements = {
        "CREATE TABLE IF NOT EXISTS admins("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, "
        "password TEXT NOT NULL DEFAULT '',password_hash TEXT NOT NULL DEFAULT '',"
        "password_salt TEXT NOT NULL DEFAULT '',password_iterations INTEGER NOT NULL DEFAULT 120000)",
        "CREATE TABLE IF NOT EXISTS users("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE NOT NULL, "
        "nickname TEXT NOT NULL, avatar TEXT DEFAULT '', balance REAL DEFAULT 100.0, "
        "balance_cents INTEGER NOT NULL DEFAULT 10000 CHECK(balance_cents>=0),"
        "status TEXT DEFAULT 'normal', registered_at TEXT NOT NULL, "
        "credit_score INTEGER NOT NULL DEFAULT 60, debt REAL NOT NULL DEFAULT 0, "
        "debt_cents INTEGER NOT NULL DEFAULT 0 CHECK(debt_cents>=0),"
        "debt_since TEXT DEFAULT '', credit_penalty_points INTEGER NOT NULL DEFAULT 0)",
        "CREATE TABLE IF NOT EXISTS stations("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, area TEXT NOT NULL, "
        "address TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL, "
        "price REAL NOT NULL,price_cents INTEGER NOT NULL DEFAULT 100 CHECK(price_cents>=0),"
        "created_at TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS chargers("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, station_id INTEGER NOT NULL, "
        "code TEXT UNIQUE NOT NULL, type TEXT NOT NULL, power REAL NOT NULL, "
        "status TEXT DEFAULT 'idle', charge_count INTEGER DEFAULT 0, "
        "charge_minutes INTEGER DEFAULT 0, last_restart TEXT DEFAULT '', "
        "FOREIGN KEY(station_id) REFERENCES stations(id) ON DELETE CASCADE)",
        "CREATE TABLE IF NOT EXISTS orders("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, "
        "charger_id INTEGER NOT NULL, status TEXT NOT NULL, started_at TEXT NOT NULL, "
        "ended_at TEXT DEFAULT '', minutes INTEGER DEFAULT 0, energy REAL DEFAULT 0, "
        "fee REAL DEFAULT 0, paid_amount REAL DEFAULT 0, outstanding REAL DEFAULT 0, "
        "base_price_cents INTEGER NOT NULL DEFAULT 0 CHECK(base_price_cents>=0),"
        "gross_fee_cents INTEGER NOT NULL DEFAULT 0 CHECK(gross_fee_cents>=0),"
        "fee_cents INTEGER NOT NULL DEFAULT 0 CHECK(fee_cents>=0),"
        "paid_amount_cents INTEGER NOT NULL DEFAULT 0 CHECK(paid_amount_cents>=0),"
        "outstanding_cents INTEGER NOT NULL DEFAULT 0 CHECK(outstanding_cents>=0),"
        "card_discount_cents INTEGER NOT NULL DEFAULT 0 CHECK(card_discount_cents>=0),"
        "charger_type TEXT NOT NULL DEFAULT '',power_kw REAL NOT NULL DEFAULT 0,"
        "tariff_snapshot TEXT NOT NULL DEFAULT '',"
        "auto_stopped INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(user_id) REFERENCES users(id), "
        "FOREIGN KEY(charger_id) REFERENCES chargers(id))",
        "CREATE TABLE IF NOT EXISTS hourly_load("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, station_id INTEGER NOT NULL, "
        "timestamp TEXT NOT NULL, load_kw REAL NOT NULL, available_count INTEGER NOT NULL, "
        "weather REAL DEFAULT 20, is_holiday INTEGER DEFAULT 0, "
        "FOREIGN KEY(station_id) REFERENCES stations(id))",
        "CREATE TABLE IF NOT EXISTS sessions("
        "token TEXT PRIMARY KEY,role TEXT NOT NULL CHECK(role IN ('user','admin')),"
        "actor_id INTEGER NOT NULL,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,"
        "last_seen TEXT NOT NULL,revoked INTEGER NOT NULL DEFAULT 0)",
        "CREATE TABLE IF NOT EXISTS idempotency_keys("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,actor_role TEXT NOT NULL,actor_id INTEGER NOT NULL,"
        "action TEXT NOT NULL,idempotency_key TEXT NOT NULL,response_json TEXT NOT NULL,"
        "created_at TEXT NOT NULL,UNIQUE(actor_role,actor_id,action,idempotency_key))",
        "CREATE TABLE IF NOT EXISTS tariff_periods("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,start_minute INTEGER NOT NULL,"
        "end_minute INTEGER NOT NULL,multiplier_percent INTEGER NOT NULL,"
        "card_multiplier INTEGER NOT NULL DEFAULT 1,active INTEGER NOT NULL DEFAULT 1,"
        "CHECK(start_minute>=0 AND start_minute<=1439),"
        "CHECK(end_minute>=1 AND end_minute<=1440),CHECK(multiplier_percent>0),"
        "CHECK(card_multiplier>=1))",
        "CREATE TABLE IF NOT EXISTS monthly_card_plans("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,"
        "price_cents INTEGER NOT NULL CHECK(price_cents>=0),daily_minutes INTEGER NOT NULL CHECK(daily_minutes>0),"
        "valid_days INTEGER NOT NULL CHECK(valid_days>0),charger_type TEXT NOT NULL DEFAULT '全部',"
        "status TEXT NOT NULL DEFAULT 'active')",
        "CREATE TABLE IF NOT EXISTS user_monthly_cards("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,plan_id INTEGER NOT NULL,"
        "purchased_at TEXT NOT NULL,valid_from TEXT NOT NULL,valid_to TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',"
        "FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(plan_id) REFERENCES monthly_card_plans(id))",
        "CREATE TABLE IF NOT EXISTS daily_card_usage("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,card_id INTEGER NOT NULL,usage_date TEXT NOT NULL,"
        "used_equivalent_minutes INTEGER NOT NULL DEFAULT 0 CHECK(used_equivalent_minutes>=0),"
        "UNIQUE(card_id,usage_date),FOREIGN KEY(card_id) REFERENCES user_monthly_cards(id))",
        "CREATE TABLE IF NOT EXISTS order_card_details("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,card_id INTEGER NOT NULL,"
        "usage_date TEXT NOT NULL,tariff_name TEXT NOT NULL,actual_minutes INTEGER NOT NULL,"
        "equivalent_minutes INTEGER NOT NULL,covered_cents INTEGER NOT NULL,"
        "FOREIGN KEY(order_id) REFERENCES orders(id),FOREIGN KEY(card_id) REFERENCES user_monthly_cards(id))",
        "CREATE TABLE IF NOT EXISTS order_tariff_details("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,usage_date TEXT NOT NULL,"
        "tariff_name TEXT NOT NULL,actual_minutes INTEGER NOT NULL,gross_cents INTEGER NOT NULL,"
        "card_covered_cents INTEGER NOT NULL,payable_cents INTEGER NOT NULL,"
        "FOREIGN KEY(order_id) REFERENCES orders(id))",
        "CREATE TABLE IF NOT EXISTS feedback("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,category TEXT NOT NULL,"
        "title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,"
        "FOREIGN KEY(user_id) REFERENCES users(id))",
        "CREATE TABLE IF NOT EXISTS feedback_messages("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,feedback_id INTEGER NOT NULL,sender_role TEXT NOT NULL,"
        "sender_id INTEGER NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL,"
        "FOREIGN KEY(feedback_id) REFERENCES feedback(id) ON DELETE CASCADE)",
        "CREATE TABLE IF NOT EXISTS audit_logs("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,level TEXT NOT NULL DEFAULT 'info',"
        "actor_role TEXT NOT NULL DEFAULT 'system',actor_id INTEGER NOT NULL DEFAULT 0,"
        "action TEXT NOT NULL,request_id TEXT NOT NULL DEFAULT '',success INTEGER NOT NULL DEFAULT 1,"
        "message TEXT NOT NULL DEFAULT '')",
        "CREATE TABLE IF NOT EXISTS credit_events("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,event_date TEXT NOT NULL,"
        "event_type TEXT NOT NULL,points INTEGER NOT NULL,order_id INTEGER,created_at TEXT NOT NULL,"
        "UNIQUE(user_id,event_date,event_type),FOREIGN KEY(user_id) REFERENCES users(id))"
    };

    for (const QString &statement : statements) {
        if (!execute(statement)) {
            return false;
        }
    }
    return true;
}

bool DatabaseManager::columnExists(const QString &table, const QString &column)
{
    QSqlQuery query(m_database);
    if (!query.exec(QString("PRAGMA table_info(%1)").arg(table))) {
        m_lastError = query.lastError().text();
        return false;
    }
    while (query.next()) {
        if (query.value(1).toString() == column) {
            return true;
        }
    }
    return false;
}

bool DatabaseManager::addColumnIfMissing(const QString &table,
                                         const QString &column,
                                         const QString &definition)
{
    if (columnExists(table, column)) {
        return true;
    }
    return execute(QString("ALTER TABLE %1 ADD COLUMN %2 %3")
                   .arg(table)
                   .arg(column)
                   .arg(definition));
}

bool DatabaseManager::migrateSchema()
{
    const bool creditWasMissing = !columnExists("users", "credit_score");
    if (!addColumnIfMissing("admins", "password_hash", "TEXT NOT NULL DEFAULT ''")
            || !addColumnIfMissing("admins", "password_salt", "TEXT NOT NULL DEFAULT ''")
            || !addColumnIfMissing("admins", "password_iterations", "INTEGER NOT NULL DEFAULT 120000")
            || !addColumnIfMissing("users", "credit_score", "INTEGER NOT NULL DEFAULT 60")
            || !addColumnIfMissing("users", "debt", "REAL NOT NULL DEFAULT 0")
            || !addColumnIfMissing("users", "balance_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(balance_cents>=0)")
            || !addColumnIfMissing("users", "debt_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(debt_cents>=0)")
            || !addColumnIfMissing("users", "debt_since", "TEXT DEFAULT ''")
            || !addColumnIfMissing("users", "credit_penalty_points", "INTEGER NOT NULL DEFAULT 0")
            || !addColumnIfMissing("stations", "price_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(price_cents>=0)")
            || !addColumnIfMissing("orders", "paid_amount", "REAL DEFAULT 0")
            || !addColumnIfMissing("orders", "outstanding", "REAL DEFAULT 0")
            || !addColumnIfMissing("orders", "base_price_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(base_price_cents>=0)")
            || !addColumnIfMissing("orders", "gross_fee_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(gross_fee_cents>=0)")
            || !addColumnIfMissing("orders", "fee_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(fee_cents>=0)")
            || !addColumnIfMissing("orders", "paid_amount_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(paid_amount_cents>=0)")
            || !addColumnIfMissing("orders", "outstanding_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(outstanding_cents>=0)")
            || !addColumnIfMissing("orders", "card_discount_cents", "INTEGER NOT NULL DEFAULT 0 CHECK(card_discount_cents>=0)")
            || !addColumnIfMissing("orders", "charger_type", "TEXT NOT NULL DEFAULT ''")
            || !addColumnIfMissing("orders", "power_kw", "REAL NOT NULL DEFAULT 0")
            || !addColumnIfMissing("orders", "tariff_snapshot", "TEXT NOT NULL DEFAULT ''")
            || !addColumnIfMissing("orders", "auto_stopped", "INTEGER NOT NULL DEFAULT 0")) {
        return false;
    }

    if (creditWasMissing) {
        if (!execute("UPDATE users SET credit_score=95 WHERE phone='13800138000'")
                || !execute("UPDATE users SET credit_score=75 WHERE phone='13900139000'")
                || !execute("UPDATE users SET credit_score=8 WHERE phone='13700137000'")) {
            return false;
        }
    }
    if (!execute("UPDATE users SET credit_score=MIN(100,MAX(0,credit_score)),"
                 "debt=MAX(0,ROUND(debt,2)),credit_penalty_points=MAX(0,credit_penalty_points),"
                 "balance_cents=CASE WHEN balance_cents=0 AND balance>0 THEN CAST(ROUND(balance*100) AS INTEGER) ELSE balance_cents END,"
                 "debt_cents=CASE WHEN debt_cents=0 AND debt>0 THEN CAST(ROUND(debt*100) AS INTEGER) ELSE debt_cents END")
            || !execute("UPDATE stations SET price_cents=CAST(ROUND(price*100) AS INTEGER) WHERE price_cents=0")
            || !execute("UPDATE orders SET paid_amount=fee WHERE status='completed' AND paid_amount=0 AND fee>0")
            || !execute("UPDATE orders SET fee_cents=CAST(ROUND(fee*100) AS INTEGER),"
                        "gross_fee_cents=CASE WHEN gross_fee_cents=0 THEN CAST(ROUND(fee*100) AS INTEGER) ELSE gross_fee_cents END,"
                        "paid_amount_cents=CAST(ROUND(paid_amount*100) AS INTEGER),"
                        "outstanding_cents=CAST(ROUND(outstanding*100) AS INTEGER) WHERE status!='charging'")
            || !execute("UPDATE orders SET base_price_cents=(SELECT s.price_cents FROM chargers c JOIN stations s ON s.id=c.station_id WHERE c.id=orders.charger_id) WHERE base_price_cents=0")
            || !execute("UPDATE orders SET charger_type=(SELECT type FROM chargers WHERE id=orders.charger_id) WHERE charger_type='' ")
            || !execute("UPDATE orders SET power_kw=(SELECT power FROM chargers WHERE id=orders.charger_id) WHERE power_kw=0")) {
        return false;
    }

    QSqlQuery legacyAdmins(m_database);
    if (!legacyAdmins.exec("SELECT id,password FROM admins WHERE password_hash=''")) {
        m_lastError = legacyAdmins.lastError().text();
        return false;
    }
    QList<QVariantList> adminsToMigrate;
    while (legacyAdmins.next()) {
        adminsToMigrate.append({legacyAdmins.value(0), legacyAdmins.value(1)});
    }
    legacyAdmins.finish();
    for (const QVariantList &admin : adminsToMigrate) {
        const int adminId = admin.at(0).toInt();
        const QString legacyPassword = admin.at(1).toString();
        const QString salt = QString::fromLatin1(SecurityUtils::randomBytes(16).toHex());
        const int iterations = 120000;
        QSqlQuery updateAdmin(m_database);
        updateAdmin.prepare("UPDATE admins SET password='',password_hash=:hash,password_salt=:salt,"
                            "password_iterations=:iterations WHERE id=:id");
        updateAdmin.bindValue(":hash", SecurityUtils::passwordHash(legacyPassword, salt, iterations));
        updateAdmin.bindValue(":salt", salt);
        updateAdmin.bindValue(":iterations", iterations);
        updateAdmin.bindValue(":id", adminId);
        if (!updateAdmin.exec()) {
            m_lastError = updateAdmin.lastError().text();
            return false;
        }
    }

    const QStringList invariants = {
        "UPDATE orders SET status='cancelled_migration',ended_at=datetime('now','localtime') "
        "WHERE status='charging' AND id NOT IN (SELECT MIN(id) FROM orders WHERE status='charging' GROUP BY user_id)",
        "UPDATE orders SET status='cancelled_migration',ended_at=datetime('now','localtime') "
        "WHERE status='charging' AND id NOT IN (SELECT MIN(id) FROM orders WHERE status='charging' GROUP BY charger_id)",
        "UPDATE chargers SET status=CASE WHEN EXISTS(SELECT 1 FROM orders o WHERE o.charger_id=chargers.id AND o.status='charging') THEN 'in_use' WHEN status='in_use' THEN 'idle' ELSE status END",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_orders_active_user ON orders(user_id) WHERE status='charging'",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_orders_active_charger ON orders(charger_id) WHERE status='charging'",
        "CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at,revoked)",
        "CREATE INDEX IF NOT EXISTS idx_feedback_user ON feedback(user_id,updated_at)",
        "CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at)",
        "CREATE VIEW IF NOT EXISTS v_user_accounts AS SELECT id,phone,nickname,status,credit_score,balance_cents/100.0 AS balance,debt_cents/100.0 AS debt,registered_at,CASE WHEN avatar='' THEN 0 ELSE 1 END AS has_avatar FROM users",
        "CREATE VIEW IF NOT EXISTS v_order_settlements AS SELECT o.id,o.user_id,o.charger_id,o.status,o.started_at,o.ended_at,o.minutes,o.energy,o.gross_fee_cents/100.0 AS gross_fee,o.card_discount_cents/100.0 AS card_discount,o.fee_cents/100.0 AS fee,o.paid_amount_cents/100.0 AS paid_amount,o.outstanding_cents/100.0 AS outstanding,o.auto_stopped FROM orders o",
        "CREATE VIEW IF NOT EXISTS v_monthly_card_usage AS SELECT c.id AS card_id,c.user_id,p.name AS plan,c.valid_from,c.valid_to,d.usage_date,d.used_equivalent_minutes,p.daily_minutes FROM user_monthly_cards c JOIN monthly_card_plans p ON p.id=c.plan_id LEFT JOIN daily_card_usage d ON d.card_id=c.id",
        "CREATE VIEW IF NOT EXISTS v_feedback_overview AS SELECT f.id,f.user_id,u.phone,f.category,f.title,f.status,f.created_at,f.updated_at,(SELECT COUNT(*) FROM feedback_messages m WHERE m.feedback_id=f.id) AS message_count FROM feedback f JOIN users u ON u.id=f.user_id",
        "CREATE TRIGGER IF NOT EXISTS sync_users_money_update AFTER UPDATE OF balance_cents,debt_cents ON users BEGIN UPDATE users SET balance=NEW.balance_cents/100.0,debt=NEW.debt_cents/100.0 WHERE id=NEW.id; END",
        "CREATE TRIGGER IF NOT EXISTS sync_stations_price_update AFTER UPDATE OF price_cents ON stations BEGIN UPDATE stations SET price=NEW.price_cents/100.0 WHERE id=NEW.id; END",
        "CREATE TRIGGER IF NOT EXISTS sync_orders_money_update AFTER UPDATE OF fee_cents,paid_amount_cents,outstanding_cents ON orders BEGIN UPDATE orders SET fee=NEW.fee_cents/100.0,paid_amount=NEW.paid_amount_cents/100.0,outstanding=NEW.outstanding_cents/100.0 WHERE id=NEW.id; END"
    };
    for (const QString &sql : invariants) {
        if (!execute(sql)) {
            return false;
        }
    }
    return true;
}

bool DatabaseManager::seedData()
{
    QSqlQuery countQuery(m_database);
    if (!countQuery.exec("SELECT COUNT(*) FROM admins") || !countQuery.next()) {
        m_lastError = countQuery.lastError().text();
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        const QString salt = QString::fromLatin1(SecurityUtils::randomBytes(16).toHex());
        QSqlQuery insertAdmin(m_database);
        insertAdmin.prepare("INSERT INTO admins(username,password,password_hash,password_salt,password_iterations) "
                            "VALUES('admin','',:hash,:salt,120000)");
        insertAdmin.bindValue(":hash", SecurityUtils::passwordHash("123456", salt, 120000));
        insertAdmin.bindValue(":salt", salt);
        if (!insertAdmin.exec()) {
            m_lastError = insertAdmin.lastError().text();
            return false;
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM tariff_periods") || !countQuery.next()) {
        m_lastError = countQuery.lastError().text();
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        const QStringList tariffs = {
            "INSERT INTO tariff_periods(name,start_minute,end_minute,multiplier_percent,card_multiplier) VALUES('谷时',0,420,70,1)",
            "INSERT INTO tariff_periods(name,start_minute,end_minute,multiplier_percent,card_multiplier) VALUES('早高峰',420,600,130,2)",
            "INSERT INTO tariff_periods(name,start_minute,end_minute,multiplier_percent,card_multiplier) VALUES('平时',600,1020,100,1)",
            "INSERT INTO tariff_periods(name,start_minute,end_minute,multiplier_percent,card_multiplier) VALUES('晚高峰',1020,1260,150,2)",
            "INSERT INTO tariff_periods(name,start_minute,end_minute,multiplier_percent,card_multiplier) VALUES('夜间平时',1260,1440,100,1)"
        };
        for (const QString &sql : tariffs) {
            if (!execute(sql)) {
                return false;
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM monthly_card_plans") || !countQuery.next()) {
        m_lastError = countQuery.lastError().text();
        return false;
    }
    if (countQuery.value(0).toInt() == 0
            && (!execute("INSERT INTO monthly_card_plans(name,price_cents,daily_minutes,valid_days,charger_type) VALUES('慢充畅享月卡',2990,120,30,'慢充')")
                || !execute("INSERT INTO monthly_card_plans(name,price_cents,daily_minutes,valid_days,charger_type) VALUES('全桩通用月卡',5990,90,30,'全部')"))) {
        return false;
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM stations") || !countQuery.next()) {
        m_lastError = countQuery.lastError().text();
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        const QString current = nowIso();
        QSqlQuery insertStation(m_database);
        insertStation.prepare("INSERT INTO stations(name,area,address,latitude,longitude,price,price_cents,created_at) "
                              "VALUES(?,?,?,?,?,?,?,?)");
        const QList<QVariantList> stations = {
            {"中关村新能源充电站", "海淀区", "北京市海淀区中关村南大街5号", 39.9587, 116.3269, 1.38, current},
            {"魏公村智慧充电中心", "海淀区", "北京市海淀区魏公村路2号", 39.9535, 116.3235, 1.22, current},
            {"西单绿色出行站", "西城区", "北京市西城区西单北大街120号", 39.9102, 116.3741, 1.48, current},
            {"国贸快速充电站", "朝阳区", "北京市朝阳区建国门外大街1号", 39.9086, 116.4605, 1.65, current}
        };
        for (const QVariantList &station : stations) {
            for (int index = 0; index < station.size(); ++index) {
                insertStation.bindValue(index, station.at(index));
            }
            insertStation.bindValue(6, BusinessRules::centsFromAmount(station.at(5).toDouble()));
            insertStation.bindValue(7, station.at(6));
            if (!insertStation.exec()) {
                m_lastError = insertStation.lastError().text();
                return false;
            }
            const int stationId = insertStation.lastInsertId().toInt();
            for (int chargerIndex = 1; chargerIndex <= 6; ++chargerIndex) {
                QSqlQuery insertCharger(m_database);
                insertCharger.prepare("INSERT INTO chargers(station_id,code,type,power,status) "
                                      "VALUES(:station,:code,:type,:power,:status)");
                insertCharger.bindValue(":station", stationId);
                insertCharger.bindValue(":code",
                                        QString("S%1-C%2")
                                        .arg(stationId, 2, 10, QChar('0'))
                                        .arg(chargerIndex, 2, 10, QChar('0')));
                insertCharger.bindValue(":type", chargerIndex <= 4 ? "快充" : "慢充");
                insertCharger.bindValue(":power", chargerIndex <= 4 ? 120.0 : 7.0);
                insertCharger.bindValue(":status",
                                        chargerIndex == 5 && stationId == 3 ? "fault" : "idle");
                if (!insertCharger.exec()) {
                    m_lastError = insertCharger.lastError().text();
                    return false;
                }
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM users") || !countQuery.next()) {
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        QSqlQuery insertUser(m_database);
        insertUser.prepare("INSERT INTO users(phone,nickname,balance,balance_cents,status,registered_at,credit_score) "
                           "VALUES(?,?,?,?,?,?,?)");
        const QList<QVariantList> users = {
            {"13800138000", "演示用户8000", 188.0, "normal", QDateTime::currentDateTime().addDays(-30).toString(Qt::ISODate), 95},
            {"13900139000", "绿色先锋9000", 92.5, "normal", QDateTime::currentDateTime().addDays(-18).toString(Qt::ISODate), 75},
            {"13700137000", "测试用户7000", 65.0, "frozen", QDateTime::currentDateTime().addDays(-8).toString(Qt::ISODate), 8}
        };
        for (const QVariantList &user : users) {
            insertUser.bindValue(0, user.at(0));
            insertUser.bindValue(1, user.at(1));
            insertUser.bindValue(2, user.at(2));
            insertUser.bindValue(3, BusinessRules::centsFromAmount(user.at(2).toDouble()));
            insertUser.bindValue(4, user.at(3));
            insertUser.bindValue(5, user.at(4));
            insertUser.bindValue(6, user.at(5));
            if (!insertUser.exec()) {
                m_lastError = insertUser.lastError().text();
                return false;
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM orders") || !countQuery.next()) {
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        for (int day = 12; day >= 1; --day) {
            const int chargerId = (day % 20) + 1;
            const int userId = (day % 2) + 1;
            const int minutes = 24 + day * 3;
            const double energy = minutes * (chargerId % 5 == 0 ? 7.0 : 120.0) / 60.0 * 0.72;
            const double fee = energy * (1.18 + (chargerId % 4) * 0.1);
            const QDateTime start = QDateTime::currentDateTime().addDays(-day).addSecs(-3600);
            QSqlQuery order(m_database);
            const qint64 feeCents = BusinessRules::centsFromAmount(fee);
            order.prepare("INSERT INTO orders(user_id,charger_id,status,started_at,ended_at,minutes,energy,fee,paid_amount,"
                          "gross_fee_cents,fee_cents,paid_amount_cents,outstanding_cents) "
                          "VALUES(?,?,'completed',?,?,?,?,?,?,?,?,?,0)");
            order.addBindValue(userId);
            order.addBindValue(chargerId);
            order.addBindValue(start.toString(Qt::ISODate));
            order.addBindValue(start.addSecs(minutes * 60).toString(Qt::ISODate));
            order.addBindValue(minutes);
            order.addBindValue(energy);
            order.addBindValue(fee);
            order.addBindValue(fee);
            order.addBindValue(feeCents);
            order.addBindValue(feeCents);
            order.addBindValue(feeCents);
            if (!order.exec()) {
                m_lastError = order.lastError().text();
                return false;
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM hourly_load") || !countQuery.next()) {
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        QSqlQuery loadInsert(m_database);
        loadInsert.prepare("INSERT INTO hourly_load(station_id,timestamp,load_kw,available_count,weather,is_holiday) "
                           "VALUES(?,?,?,?,?,?)");
        for (int hoursAgo = 24 * 21; hoursAgo >= 1; --hoursAgo) {
            const QDateTime time = QDateTime::currentDateTime().addSecs(-hoursAgo * 3600);
            const int hour = time.time().hour();
            const double rush = (hour >= 7 && hour <= 10) || (hour >= 17 && hour <= 21) ? 1.0 : 0.45;
            for (int stationId = 1; stationId <= 4; ++stationId) {
                const double load = 25.0 + stationId * 8.0 + rush * 92.0
                        + ((hoursAgo * 17 + stationId * 13) % 31);
                loadInsert.bindValue(0, stationId);
                loadInsert.bindValue(1, time.toString(Qt::ISODate));
                loadInsert.bindValue(2, load);
                loadInsert.bindValue(3, qMax(0, 6 - qRound(load / 45.0)));
                loadInsert.bindValue(4, 18.0 + ((hoursAgo + stationId) % 12));
                loadInsert.bindValue(5, time.date().dayOfWeek() >= 6 ? 1 : 0);
                if (!loadInsert.exec()) {
                    m_lastError = loadInsert.lastError().text();
                    return false;
                }
            }
        }
    }

    return true;
}

QJsonArray DatabaseManager::selectRows(const QString &sql, const QVariantMap &bindings)
{
    QJsonArray result;
    QSqlQuery query(m_database);
    query.prepare(sql);
    for (auto iterator = bindings.constBegin(); iterator != bindings.constEnd(); ++iterator) {
        query.bindValue(iterator.key(), iterator.value());
    }
    if (!query.exec()) {
        m_lastError = query.lastError().text();
        return result;
    }
    while (query.next()) {
        QJsonObject row;
        const QSqlRecord record = query.record();
        for (int index = 0; index < record.count(); ++index) {
            row.insert(record.fieldName(index), QJsonValue::fromVariant(query.value(index)));
        }
        result.append(row);
    }
    return result;
}

QJsonObject DatabaseManager::selectOne(const QString &sql, const QVariantMap &bindings)
{
    const QJsonArray rows = selectRows(sql, bindings);
    return rows.isEmpty() ? QJsonObject() : rows.first().toObject();
}

QJsonObject DatabaseManager::response(bool ok,
                                      const QString &message,
                                      const QJsonValue &data) const
{
    QJsonObject object;
    object.insert("ok", ok);
    object.insert("message", message);
    if (!data.isUndefined() && !data.isNull()) {
        object.insert("data", data);
    }
    return object;
}

QJsonObject DatabaseManager::userSnapshot(int userId)
{
    QJsonObject user = selectOne(
                "SELECT id,phone,nickname,avatar,balance_cents/100.0 AS balance,status,"
                "registered_at,credit_score,debt_cents/100.0 AS debt,debt_since "
                "FROM users WHERE id=:id",
                {{":id", userId}});
    if (user.isEmpty()) {
        return user;
    }

    const int score = normalizedCreditScore(user.value("credit_score").toInt());
    const double debt = user.value("debt").toDouble();
    const int limit = creditLimitForScore(score);
    const double availableCredit = qMax(0.0, limit - debt);
    QString warning;
    if (score == 0) {
        warning = "信誉分为 0，账号已封禁，请联系管理员处理欠费。";
    } else if (score <= 10) {
        warning = "信誉等级最低：余额小于等于 0 时禁止开始充电，请及时充值。";
    } else if (score <= 30) {
        warning = "信誉等级较低：可欠额度有限，欠费逾期会继续扣分。";
    }
    if (debt > 0.005) {
        const QString debtWarning = QString("当前欠费 ¥%1；超过 3 分钟未还将扣除信誉分。")
                .arg(debt, 0, 'f', 2);
        warning = warning.isEmpty() ? debtWarning : warning + " " + debtWarning;
    }

    user.insert("credit_score", score);
    user.insert("credit_level", creditLevelForScore(score));
    user.insert("credit_limit", limit);
    user.insert("available_credit", qRound(availableCredit * 100.0) / 100.0);
    user.insert("spending_power",
                qRound((qMax(0.0, user.value("balance").toDouble()) + availableCredit) * 100.0) / 100.0);
    user.insert("credit_warning", warning);
    const QString avatarPath = avatarAbsolutePath(user.value("avatar").toString());
    QFile avatarFile(avatarPath);
    if (!avatarPath.isEmpty() && avatarFile.open(QIODevice::ReadOnly)) {
        user.insert("avatar_data", QString::fromLatin1(avatarFile.readAll().toBase64()));
    }
    const QJsonObject activeCard = selectOne(
                "SELECT p.name,p.daily_minutes,COALESCE(d.used_equivalent_minutes,0) AS used_today,"
                "c.valid_to,p.charger_type FROM user_monthly_cards c "
                "JOIN monthly_card_plans p ON p.id=c.plan_id "
                "LEFT JOIN daily_card_usage d ON d.card_id=c.id AND d.usage_date=:today "
                "WHERE c.user_id=:user AND c.status='active' AND date(:today) BETWEEN date(c.valid_from) AND date(c.valid_to) "
                "ORDER BY c.valid_to LIMIT 1", {{":today", todayIso()}, {":user", userId}});
    if (!activeCard.isEmpty()) {
        user.insert("active_monthly_card", activeCard);
    }
    return user;
}

QString DatabaseManager::avatarAbsolutePath(const QString &storedPath) const
{
    if (storedPath.trimmed().isEmpty()) {
        return QString();
    }
    const QFileInfo info(storedPath);
    if (info.isAbsolute()) {
        return QString();
    }
    const QString cleaned = QDir::cleanPath(storedPath);
    if (!cleaned.startsWith("avatars/") || cleaned.contains("..")) {
        return QString();
    }
    return QDir(QFileInfo(m_databasePath).absolutePath()).filePath(cleaned);
}

bool DatabaseManager::validateAdmin(const QString &username, const QString &password)
{
    QSqlQuery query(m_database);
    query.prepare("SELECT password_hash,password_salt,password_iterations FROM admins WHERE username=:username");
    query.bindValue(":username", username.trimmed());
    if (!query.exec() || !query.next()) {
        return false;
    }
    return SecurityUtils::verifyPassword(password,
                                         query.value(1).toString(),
                                         query.value(2).toInt(),
                                         query.value(0).toString());
}

QString DatabaseManager::createSession(const QString &role, int actorId)
{
    const QString token = SecurityUtils::randomToken();
    const QDateTime now = QDateTime::currentDateTime();
    QSqlQuery query(m_database);
    query.prepare("INSERT INTO sessions(token,role,actor_id,created_at,expires_at,last_seen) "
                  "VALUES(:token,:role,:actor,:created,:expires,:seen)");
    query.bindValue(":token", token);
    query.bindValue(":role", role);
    query.bindValue(":actor", actorId);
    query.bindValue(":created", now.toString(Qt::ISODate));
    query.bindValue(":expires", now.addDays(7).toString(Qt::ISODate));
    query.bindValue(":seen", now.toString(Qt::ISODate));
    if (!query.exec()) {
        m_lastError = query.lastError().text();
        return QString();
    }
    return token;
}

QJsonObject DatabaseManager::authenticate(const QString &token)
{
    if (token.size() < 32) {
        return QJsonObject();
    }
    QJsonObject session = selectOne(
                "SELECT token,role,actor_id,expires_at FROM sessions "
                "WHERE token=:token AND revoked=0", {{":token", token}});
    if (session.isEmpty()) {
        return session;
    }
    const QDateTime expiry = QDateTime::fromString(session.value("expires_at").toString(), Qt::ISODate);
    if (!expiry.isValid() || expiry < QDateTime::currentDateTime()) {
        QSqlQuery revoke(m_database);
        revoke.prepare("UPDATE sessions SET revoked=1 WHERE token=:token");
        revoke.bindValue(":token", token);
        revoke.exec();
        return QJsonObject();
    }
    QSqlQuery touch(m_database);
    touch.prepare("UPDATE sessions SET last_seen=:seen WHERE token=:token");
    touch.bindValue(":seen", nowIso());
    touch.bindValue(":token", token);
    touch.exec();
    return session;
}

QJsonObject DatabaseManager::findIdempotentResponse(const QString &role,
                                                     int actorId,
                                                     const QString &action,
                                                     const QString &key)
{
    const QJsonObject row = selectOne(
                "SELECT response_json FROM idempotency_keys WHERE actor_role=:role "
                "AND actor_id=:actor AND action=:action AND idempotency_key=:key",
                {{":role", role}, {":actor", actorId}, {":action", action}, {":key", key}});
    if (row.isEmpty()) {
        return QJsonObject();
    }
    const QJsonDocument document = QJsonDocument::fromJson(
                row.value("response_json").toString().toUtf8());
    return document.isObject() ? document.object() : QJsonObject();
}

bool DatabaseManager::storeIdempotentResponse(const QString &role,
                                               int actorId,
                                               const QString &action,
                                               const QString &key,
                                               const QJsonObject &result)
{
    QSqlQuery query(m_database);
    query.prepare("INSERT OR IGNORE INTO idempotency_keys(actor_role,actor_id,action,idempotency_key,response_json,created_at) "
                  "VALUES(:role,:actor,:action,:key,:response,:created)");
    query.bindValue(":role", role);
    query.bindValue(":actor", actorId);
    query.bindValue(":action", action);
    query.bindValue(":key", key);
    query.bindValue(":response", QString::fromUtf8(QJsonDocument(result).toJson(QJsonDocument::Compact)));
    query.bindValue(":created", nowIso());
    return query.exec();
}

void DatabaseManager::writeAuditLog(const QString &role,
                                    int actorId,
                                    const QString &action,
                                    const QJsonObject &request,
                                    const QJsonObject &result)
{
    QSqlQuery query(m_database);
    query.prepare("INSERT INTO audit_logs(created_at,level,actor_role,actor_id,action,request_id,success,message) "
                  "VALUES(:created,:level,:role,:actor,:action,:requestId,:success,:message)");
    query.bindValue(":created", nowIso());
    query.bindValue(":level", result.value("ok").toBool() ? "info" : "warning");
    query.bindValue(":role", role.isEmpty() ? "anonymous" : role);
    query.bindValue(":actor", actorId);
    query.bindValue(":action", action.left(64));
    query.bindValue(":requestId", request.value("requestId").toVariant().toString().left(80));
    query.bindValue(":success", result.value("ok").toBool() ? 1 : 0);
    query.bindValue(":message", result.value("message").toString().left(500));
    query.exec();
}

void DatabaseManager::writeRuntimeLog(const QString &message, const QString &level)
{
    QSqlQuery query(m_database);
    query.prepare("INSERT INTO audit_logs(created_at,level,actor_role,actor_id,action,success,message) "
                  "VALUES(:created,:level,'system',0,'runtime',1,:message)");
    query.bindValue(":created", nowIso());
    query.bindValue(":level", level.left(16));
    query.bindValue(":message", message.left(500));
    query.exec();
}

QJsonObject DatabaseManager::handleRequest(const QJsonObject &request, bool trustedAdmin)
{
    const QString action = request.value("action").toString();
    QJsonObject effectiveRequest = request;
    QString actorRole = trustedAdmin ? "admin" : QString();
    int actorId = trustedAdmin ? 1 : 0;

    if (!trustedAdmin && !isPublicAction(action)) {
        const QJsonObject session = authenticate(request.value("sessionToken").toString());
        if (session.isEmpty()) {
            QJsonObject denied = response(false, "登录状态已失效，请重新登录");
            denied.insert("requestId", request.value("requestId"));
            writeAuditLog("anonymous", 0, action, request, denied);
            return denied;
        }
        actorRole = session.value("role").toString();
        actorId = session.value("actor_id").toInt();
        if (isAdminAction(action) && actorRole != "admin") {
            QJsonObject denied = response(false, "无管理员权限");
            denied.insert("requestId", request.value("requestId"));
            writeAuditLog(actorRole, actorId, action, request, denied);
            return denied;
        }
        if (!isAdminAction(action) && actorRole != "user"
                && action != "logout" && action != "feedback_messages") {
            QJsonObject denied = response(false, "无用户权限");
            denied.insert("requestId", request.value("requestId"));
            writeAuditLog(actorRole, actorId, action, request, denied);
            return denied;
        }
        if (actorRole == "user") {
            effectiveRequest.insert("userId", actorId);
        } else if (actorRole == "admin") {
            effectiveRequest.insert("adminId", actorId);
        }
    }

    QString idempotencyKey = request.value("idempotencyKey").toString().trimmed();
    if (!trustedAdmin && requiresIdempotency(action)) {
        if (idempotencyKey.size() < 8 || idempotencyKey.size() > 100) {
            QJsonObject denied = response(false, "该操作缺少有效的幂等键，请更新客户端后重试");
            denied.insert("requestId", request.value("requestId"));
            writeAuditLog(actorRole, actorId, action, request, denied);
            return denied;
        }
        QJsonObject cached = findIdempotentResponse(actorRole, actorId, action, idempotencyKey);
        if (!cached.isEmpty()) {
            cached.insert("requestId", request.value("requestId"));
            cached.insert("idempotentReplay", true);
            return cached;
        }
    }

    QJsonObject result;

    if (action == "login_user") {
        result = loginUser(effectiveRequest);
    } else if (action == "login_admin") {
        result = loginAdmin(effectiveRequest);
    } else if (action == "logout") {
        result = logout(effectiveRequest);
    } else if (action == "list_stations") {
        result = listStations(effectiveRequest);
    } else if (action == "station_detail") {
        result = stationDetail(effectiveRequest);
    } else if (action == "profile") {
        result = profile(effectiveRequest);
    } else if (action == "update_profile") {
        result = updateProfile(effectiveRequest);
    } else if (action == "recharge") {
        result = recharge(effectiveRequest);
    } else if (action == "start_charging") {
        result = startCharging(effectiveRequest);
    } else if (action == "stop_charging") {
        result = stopCharging(effectiveRequest);
    } else if (action == "active_order") {
        result = activeOrder(effectiveRequest);
    } else if (action == "list_orders") {
        result = listOrders(effectiveRequest);
    } else if (action == "dashboard") {
        result = dashboard();
    } else if (action == "admin_chargers") {
        result = listChargers(effectiveRequest);
    } else if (action == "restart_charger") {
        result = restartCharger(effectiveRequest);
    } else if (action == "admin_stations") {
        result = listAdminStations();
    } else if (action == "add_station") {
        result = addStation(effectiveRequest);
    } else if (action == "admin_users") {
        result = listUsers(effectiveRequest);
    } else if (action == "toggle_user") {
        result = toggleUser(effectiveRequest);
    } else if (action == "admin_orders") {
        result = listAllOrders();
    } else if (action == "tariffs") {
        result = listTariffs();
    } else if (action == "monthly_card_plans") {
        result = listMonthlyCardPlans(effectiveRequest);
    } else if (action == "my_monthly_cards") {
        result = listMyMonthlyCards(effectiveRequest);
    } else if (action == "admin_monthly_cards") {
        result = listAdminMonthlyCards();
    } else if (action == "buy_monthly_card") {
        result = buyMonthlyCard(effectiveRequest);
    } else if (action == "create_feedback") {
        result = createFeedback(effectiveRequest);
    } else if (action == "my_feedback") {
        result = listMyFeedback(effectiveRequest);
    } else if (action == "feedback_messages") {
        result = feedbackMessages(effectiveRequest, actorRole == "admin");
    } else if (action == "reply_feedback") {
        result = replyFeedback(effectiveRequest, false);
    } else if (action == "admin_feedback") {
        result = listAdminFeedback(effectiveRequest);
    } else if (action == "admin_reply_feedback") {
        result = replyFeedback(effectiveRequest, true);
    } else if (action == "update_feedback_status") {
        result = updateFeedbackStatus(effectiveRequest);
    } else if (action == "audit_logs") {
        result = listAuditLogs(effectiveRequest);
    } else {
        result = response(false, "未知请求：" + action);
    }

    result.insert("requestId", request.value("requestId"));
    if (!trustedAdmin && requiresIdempotency(action) && !idempotencyKey.isEmpty()) {
        storeIdempotentResponse(actorRole, actorId, action, idempotencyKey, result);
    }
    if (!isPublicAction(action) || action.startsWith("login_")) {
        writeAuditLog(actorRole, actorId, action, request, result);
    }
    return result;
}

QJsonObject DatabaseManager::loginUser(const QJsonObject &request)
{
    const QString phone = request.value("phone").toString().trimmed();
    const QRegularExpression phonePattern("^1[3-9]\\d{9}$");
    if (!phonePattern.match(phone).hasMatch()) {
        return response(false, "请输入合法的 11 位手机号");
    }

    QJsonObject user = selectOne("SELECT id FROM users WHERE phone=:phone", {{":phone", phone}});
    if (user.isEmpty()) {
        QSqlQuery insert(m_database);
        insert.prepare("INSERT INTO users(phone,nickname,balance,balance_cents,status,registered_at,credit_score) "
                       "VALUES(:phone,:nickname,100.0,10000,'normal',:registered,60)");
        insert.bindValue(":phone", phone);
        insert.bindValue(":nickname", "用户" + phone.right(4));
        insert.bindValue(":registered", nowIso());
        if (!insert.exec()) {
            return response(false, "注册失败：" + insert.lastError().text());
        }
        user = selectOne("SELECT id FROM users WHERE phone=:phone", {{":phone", phone}});
    }

    user = userSnapshot(user.value("id").toInt());
    if (user.value("credit_score").toInt() == 0
            || user.value("status").toString() == "banned") {
        return response(false, "信誉分为 0，账号已封禁");
    }
    if (user.value("status").toString() == "frozen") {
        return response(false, "账号已冻结，请联系管理员");
    }
    const QString token = createSession("user", user.value("id").toInt());
    if (token.isEmpty()) {
        return response(false, "无法创建登录会话：" + m_lastError);
    }
    user.insert("sessionToken", token);
    return response(true, "登录成功", user);
}

QJsonObject DatabaseManager::loginAdmin(const QJsonObject &request)
{
    const QString username = request.value("username").toString().trimmed();
    if (!validateAdmin(username, request.value("password").toString())) {
        return response(false, "管理员账号或密码错误");
    }
    const QJsonObject admin = selectOne("SELECT id,username FROM admins WHERE username=:username",
                                        {{":username", username}});
    const QString token = createSession("admin", admin.value("id").toInt());
    if (token.isEmpty()) {
        return response(false, "无法创建管理员会话：" + m_lastError);
    }
    QJsonObject data = admin;
    data.insert("sessionToken", token);
    return response(true, "管理员登录成功", data);
}

QJsonObject DatabaseManager::logout(const QJsonObject &request)
{
    QSqlQuery query(m_database);
    query.prepare("UPDATE sessions SET revoked=1 WHERE token=:token");
    query.bindValue(":token", request.value("sessionToken").toString());
    if (!query.exec()) {
        return response(false, "退出失败：" + query.lastError().text());
    }
    return response(true, "已安全退出");
}

QJsonObject DatabaseManager::listStations(const QJsonObject &request)
{
    const QString area = request.value("area").toString().trimmed();
    const double latitude = request.value("latitude").toDouble(39.9570);
    const double longitude = request.value("longitude").toDouble(116.3270);
    QString sql =
            "SELECT s.id,s.name,s.area,s.address,s.latitude,s.longitude,s.price_cents/100.0 AS price,"
            "COUNT(c.id) AS total_count,"
            "SUM(CASE WHEN c.status='idle' THEN 1 ELSE 0 END) AS idle_count "
            "FROM stations s LEFT JOIN chargers c ON c.station_id=s.id ";
    QVariantMap bindings;
    if (!area.isEmpty() && area != "全部区域") {
        sql += "WHERE s.area=:area ";
        bindings.insert(":area", area);
    }
    sql += "GROUP BY s.id ORDER BY s.id";

    QJsonArray rows = selectRows(sql, bindings);
    QList<QJsonObject> sorted;
    for (const QJsonValue &value : rows) {
        QJsonObject station = value.toObject();
        station.insert("distance",
                       distanceKilometers(latitude,
                                          longitude,
                                          station.value("latitude").toDouble(),
                                          station.value("longitude").toDouble()));
        sorted.append(station);
    }
    std::sort(sorted.begin(), sorted.end(), [](const QJsonObject &left, const QJsonObject &right) {
        return left.value("distance").toDouble() < right.value("distance").toDouble();
    });
    QJsonArray sortedArray;
    for (const QJsonObject &station : sorted) {
        sortedArray.append(station);
    }
    return response(true, "查询成功", sortedArray);
}

QJsonObject DatabaseManager::stationDetail(const QJsonObject &request)
{
    const int stationId = request.value("stationId").toInt();
    const QJsonArray chargers = selectRows(
                "SELECT id,code,type,power,status,charge_count,charge_minutes "
                "FROM chargers WHERE station_id=:station ORDER BY code",
                {{":station", stationId}});
    return response(true, "查询成功", chargers);
}

QJsonObject DatabaseManager::profile(const QJsonObject &request)
{
    const QJsonObject user = userSnapshot(request.value("userId").toInt());
    return user.isEmpty() ? response(false, "用户不存在") : response(true, "查询成功", user);
}

QJsonObject DatabaseManager::updateProfile(const QJsonObject &request)
{
    const QString nickname = request.value("nickname").toString().trimmed();
    if (nickname.isEmpty() || nickname.size() > 20) {
        return response(false, "昵称长度应为 1 至 20 个字符");
    }
    const int userId = request.value("userId").toInt();
    QString storedAvatar = selectOne("SELECT avatar FROM users WHERE id=:id", {{":id", userId}})
            .value("avatar").toString();
    const QString avatarData = request.value("avatarData").toString();
    if (!avatarData.isEmpty()) {
        const QByteArray bytes = QByteArray::fromBase64(avatarData.toLatin1());
        if (bytes.isEmpty() || bytes.size() > 2 * 1024 * 1024) {
            return response(false, "头像文件无效或超过 2MB");
        }
        QBuffer imageBuffer;
        imageBuffer.setData(bytes);
        imageBuffer.open(QIODevice::ReadOnly);
        QImageReader reader(&imageBuffer);
        reader.setAutoTransform(true);
        const QSize originalSize = reader.size();
        if (!reader.canRead() || !originalSize.isValid()
                || originalSize.width() > 4096 || originalSize.height() > 4096
                || static_cast<qint64>(originalSize.width()) * originalSize.height() > 16000000) {
            return response(false, "头像不是可识别的图片");
        }
        QImage image = reader.read();
        if (image.isNull()) {
            return response(false, "头像解码失败");
        }
        image = image.scaled(256, 256, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        const QString relativePath = QString("avatars/u%1.png").arg(userId);
        const QString absolutePath = avatarAbsolutePath(relativePath);
        QDir().mkpath(QFileInfo(absolutePath).absolutePath());
        QSaveFile file(absolutePath);
        if (!file.open(QIODevice::WriteOnly) || !image.save(&file, "PNG") || !file.commit()) {
            return response(false, "头像保存失败");
        }
        storedAvatar = relativePath;
    }
    QSqlQuery query(m_database);
    query.prepare("UPDATE users SET nickname=:nickname,avatar=:avatar WHERE id=:id");
    query.bindValue(":nickname", nickname);
    query.bindValue(":avatar", storedAvatar);
    query.bindValue(":id", userId);
    if (!query.exec() || query.numRowsAffected() != 1) {
        return response(false, "保存失败：" + query.lastError().text());
    }
    return profile(request);
}

QJsonObject DatabaseManager::recharge(const QJsonObject &request)
{
    const double amount = request.value("amount").toDouble();
    if (!qIsFinite(amount) || amount <= 0 || amount > 10000) {
        return response(false, "充值金额应大于 0 且不超过 10000 元");
    }
    const qint64 amountCents = BusinessRules::centsFromAmount(amount);
    const int userId = request.value("userId").toInt();

    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动充值事务", transaction));
    }
    const QJsonObject user = selectOne(
                "SELECT balance_cents,debt_cents FROM users WHERE id=:id", {{":id", userId}});
    if (user.isEmpty()) {
        transaction.rollback();
        return response(false, "用户不存在");
    }

    const qint64 currentDebt = user.value("debt_cents").toVariant().toLongLong();
    const qint64 debtPayment = qMin(amountCents, currentDebt);
    const qint64 balanceAddition = amountCents - debtPayment;
    const qint64 newDebt = currentDebt - debtPayment;
    const QJsonArray unpaidOrders = selectRows(
                "SELECT id,outstanding_cents FROM orders "
                "WHERE user_id=:user AND status='unpaid' AND outstanding_cents>0 ORDER BY id",
                {{":user", userId}});

    qint64 remainingPayment = debtPayment;
    for (const QJsonValue &value : unpaidOrders) {
        if (remainingPayment <= 0) {
            break;
        }
        const QJsonObject unpaidOrder = value.toObject();
        const int orderId = unpaidOrder.value("id").toInt();
        const qint64 outstanding = unpaidOrder.value("outstanding_cents").toVariant().toLongLong();
        const qint64 applied = qMin(remainingPayment, outstanding);
        QSqlQuery updateOrder(m_database);
        updateOrder.prepare(
                    "UPDATE orders SET paid_amount_cents=paid_amount_cents+:applied,"
                    "outstanding_cents=MAX(0,outstanding_cents-:applied),"
                    "status=CASE WHEN outstanding_cents-:applied<=0 THEN 'completed' ELSE 'unpaid' END "
                    "WHERE id=:id");
        updateOrder.bindValue(":applied", applied);
        updateOrder.bindValue(":id", orderId);
        if (!updateOrder.exec()) {
            transaction.rollback();
            return response(false, transactionFailure(
                                "偿还欠费订单失败：" + updateOrder.lastError().text(), transaction));
        }
        remainingPayment -= applied;
    }

    QSqlQuery updateUser(m_database);
    updateUser.prepare(
                "UPDATE users SET balance_cents=balance_cents+:balance,debt_cents=:debt,"
                "debt_since=CASE WHEN :debt=0 THEN '' ELSE debt_since END,"
                "credit_penalty_points=CASE WHEN :debt=0 THEN 0 ELSE credit_penalty_points END "
                "WHERE id=:id");
    updateUser.bindValue(":balance", balanceAddition);
    updateUser.bindValue(":debt", newDebt);
    updateUser.bindValue(":id", userId);
    if (!updateUser.exec() || updateUser.numRowsAffected() != 1) {
        transaction.rollback();
        return response(false, transactionFailure("充值失败：" + updateUser.lastError().text(), transaction));
    }
    if (!transaction.commit()) {
        return response(false, transactionFailure("提交充值事务失败", transaction));
    }

    const QJsonObject updated = userSnapshot(userId);
    QString message = QString("充值成功，到账余额 ¥%1")
            .arg(BusinessRules::amountFromCents(balanceAddition), 0, 'f', 2);
    if (debtPayment > 0) {
        message = QString("充值成功，其中 ¥%1 已用于偿还欠费，余额到账 ¥%2")
                .arg(BusinessRules::amountFromCents(debtPayment), 0, 'f', 2)
                .arg(BusinessRules::amountFromCents(balanceAddition), 0, 'f', 2);
    }
    return response(true, message, updated);
}

QJsonObject DatabaseManager::calculateBilling(int userId,
                                              const QString &chargerType,
                                              double powerKw,
                                              qint64 basePriceCents,
                                              const QDateTime &startedAt,
                                              int minutes,
                                              bool allowMonthlyCard,
                                              const QJsonArray &tariffSnapshot)
{
    const QJsonArray tariffRows = tariffSnapshot.isEmpty() ? selectRows(
                "SELECT id,name,start_minute,end_minute,multiplier_percent,card_multiplier "
                "FROM tariff_periods WHERE active=1 ORDER BY start_minute") : tariffSnapshot;
    const QDate endDate = startedAt.addSecs(qMax(1, minutes) * 60).date();
    const QJsonArray cards = allowMonthlyCard ? selectRows(
                "SELECT c.id,p.daily_minutes,p.charger_type,c.valid_from,c.valid_to "
                "FROM user_monthly_cards c JOIN monthly_card_plans p ON p.id=c.plan_id "
                "WHERE c.user_id=:user AND c.status='active' "
                "AND date(c.valid_from)<=date(:endDate) AND date(c.valid_to)>=date(:startDate) "
                "ORDER BY c.valid_to,c.id",
                {{":user", userId},
                 {":startDate", startedAt.date().toString(Qt::ISODate)},
                 {":endDate", endDate.toString(Qt::ISODate)}}) : QJsonArray();

    QMap<QString, qint64> existingUsage;
    for (const QJsonValue &cardValue : cards) {
        const int cardId = cardValue.toObject().value("id").toInt();
        const QJsonArray usages = selectRows(
                    "SELECT usage_date,used_equivalent_minutes FROM daily_card_usage "
                    "WHERE card_id=:card AND date(usage_date) BETWEEN date(:startDate) AND date(:endDate)",
                    {{":card", cardId},
                     {":startDate", startedAt.date().toString(Qt::ISODate)},
                     {":endDate", endDate.toString(Qt::ISODate)}});
        for (const QJsonValue &usageValue : usages) {
            const QJsonObject usage = usageValue.toObject();
            existingUsage.insert(QString("%1|%2").arg(cardId).arg(usage.value("usage_date").toString()),
                                 usage.value("used_equivalent_minutes").toVariant().toLongLong());
        }
    }

    QMap<QString, qint64> pendingUsage;
    QMap<QString, QJsonObject> breakdown;
    QMap<QString, QJsonObject> pricingBreakdown;
    qint64 grossFeeCents = 0;
    qint64 feeCents = 0;
    qint64 cardDiscountCents = 0;
    int cardCoveredMinutes = 0;

    for (int minuteIndex = 0; minuteIndex < qMax(1, minutes); ++minuteIndex) {
        const QDateTime moment = startedAt.addSecs(static_cast<qint64>(minuteIndex) * 60);
        QJsonObject tariff;
        const int minuteOfDay = BusinessRules::minuteOfDay(moment);
        for (const QJsonValue &value : tariffRows) {
            const QJsonObject candidate = value.toObject();
            BusinessRules::TariffRule rule;
            rule.startMinute = candidate.value("start_minute").toInt();
            rule.endMinute = candidate.value("end_minute").toInt();
            if (BusinessRules::tariffContainsMinute(rule, minuteOfDay)) {
                tariff = candidate;
                break;
            }
        }
        if (tariff.isEmpty()) {
            tariff = QJsonObject{{"name", "标准"}, {"multiplier_percent", 100}, {"card_multiplier", 1}};
        }
        const qint64 minuteFee = BusinessRules::minuteFeeCents(
                    powerKw, basePriceCents, tariff.value("multiplier_percent").toInt(100));
        grossFeeCents += minuteFee;

        bool cardCovered = false;
        const QString usageDate = moment.date().toString(Qt::ISODate);
        const int equivalentMinutes = qMax(1, tariff.value("card_multiplier").toInt(1));
        for (const QJsonValue &cardValue : cards) {
            const QJsonObject card = cardValue.toObject();
            const QString applicableType = card.value("charger_type").toString();
            if (applicableType != "全部" && applicableType != chargerType) {
                continue;
            }
            if (moment.date() < QDate::fromString(card.value("valid_from").toString(), Qt::ISODate)
                    || moment.date() > QDate::fromString(card.value("valid_to").toString(), Qt::ISODate)) {
                continue;
            }
            const int cardId = card.value("id").toInt();
            const QString usageKey = QString("%1|%2").arg(cardId).arg(usageDate);
            const qint64 alreadyUsed = existingUsage.value(usageKey) + pendingUsage.value(usageKey);
            if (alreadyUsed + equivalentMinutes > card.value("daily_minutes").toInt()) {
                continue;
            }

            pendingUsage[usageKey] += equivalentMinutes;
            const QString breakdownKey = QString("%1|%2|%3")
                    .arg(cardId).arg(usageDate, tariff.value("name").toString());
            QJsonObject row = breakdown.value(breakdownKey);
            row.insert("cardId", cardId);
            row.insert("usageDate", usageDate);
            row.insert("tariffName", tariff.value("name").toString());
            row.insert("actualMinutes", row.value("actualMinutes").toInt() + 1);
            row.insert("equivalentMinutes", row.value("equivalentMinutes").toInt() + equivalentMinutes);
            row.insert("coveredCents", static_cast<double>(
                           row.value("coveredCents").toVariant().toLongLong() + minuteFee));
            breakdown.insert(breakdownKey, row);
            cardCovered = true;
            ++cardCoveredMinutes;
            cardDiscountCents += minuteFee;
            break;
        }
        if (!cardCovered) {
            feeCents += minuteFee;
        }
        const QString pricingKey = usageDate + "|" + tariff.value("name").toString();
        QJsonObject pricing = pricingBreakdown.value(pricingKey);
        pricing.insert("usageDate", usageDate);
        pricing.insert("tariffName", tariff.value("name").toString());
        pricing.insert("actualMinutes", pricing.value("actualMinutes").toInt() + 1);
        pricing.insert("grossCents", static_cast<double>(
                           pricing.value("grossCents").toVariant().toLongLong() + minuteFee));
        pricing.insert("cardCoveredCents", static_cast<double>(
                           pricing.value("cardCoveredCents").toVariant().toLongLong()
                           + (cardCovered ? minuteFee : 0)));
        pricing.insert("payableCents", static_cast<double>(
                           pricing.value("payableCents").toVariant().toLongLong()
                           + (cardCovered ? 0 : minuteFee)));
        pricingBreakdown.insert(pricingKey, pricing);
    }

    QJsonArray usageRows;
    for (auto iterator = breakdown.constBegin(); iterator != breakdown.constEnd(); ++iterator) {
        usageRows.append(iterator.value());
    }
    QJsonArray pricingRows;
    for (auto iterator = pricingBreakdown.constBegin(); iterator != pricingBreakdown.constEnd(); ++iterator) {
        pricingRows.append(iterator.value());
    }
    QJsonObject result;
    result.insert("grossFeeCents", static_cast<double>(grossFeeCents));
    result.insert("feeCents", static_cast<double>(feeCents));
    result.insert("cardDiscountCents", static_cast<double>(cardDiscountCents));
    result.insert("cardCoveredMinutes", cardCoveredMinutes);
    result.insert("usageRows", usageRows);
    result.insert("pricingRows", pricingRows);
    return result;
}

bool DatabaseManager::applyMonthlyCardUsage(int orderId, const QJsonArray &usageRows)
{
    for (const QJsonValue &value : usageRows) {
        const QJsonObject row = value.toObject();
        QSqlQuery usage(m_database);
        usage.prepare("INSERT INTO daily_card_usage(card_id,usage_date,used_equivalent_minutes) "
                      "VALUES(:card,:date,:minutes) ON CONFLICT(card_id,usage_date) DO UPDATE SET "
                      "used_equivalent_minutes=used_equivalent_minutes+excluded.used_equivalent_minutes");
        usage.bindValue(":card", row.value("cardId").toInt());
        usage.bindValue(":date", row.value("usageDate").toString());
        usage.bindValue(":minutes", row.value("equivalentMinutes").toInt());
        if (!usage.exec()) {
            m_lastError = usage.lastError().text();
            return false;
        }
        QSqlQuery detail(m_database);
        detail.prepare("INSERT INTO order_card_details(order_id,card_id,usage_date,tariff_name,actual_minutes,equivalent_minutes,covered_cents) "
                       "VALUES(:order,:card,:date,:tariff,:actual,:equivalent,:covered)");
        detail.bindValue(":order", orderId);
        detail.bindValue(":card", row.value("cardId").toInt());
        detail.bindValue(":date", row.value("usageDate").toString());
        detail.bindValue(":tariff", row.value("tariffName").toString());
        detail.bindValue(":actual", row.value("actualMinutes").toInt());
        detail.bindValue(":equivalent", row.value("equivalentMinutes").toInt());
        detail.bindValue(":covered", row.value("coveredCents").toVariant().toLongLong());
        if (!detail.exec()) {
            m_lastError = detail.lastError().text();
            return false;
        }
    }
    return true;
}

bool DatabaseManager::applyPricingDetails(int orderId, const QJsonArray &pricingRows)
{
    for (const QJsonValue &value : pricingRows) {
        const QJsonObject row = value.toObject();
        QSqlQuery query(m_database);
        query.prepare("INSERT INTO order_tariff_details(order_id,usage_date,tariff_name,actual_minutes,gross_cents,card_covered_cents,payable_cents) "
                      "VALUES(:order,:date,:tariff,:minutes,:gross,:card,:payable)");
        query.bindValue(":order", orderId);
        query.bindValue(":date", row.value("usageDate").toString());
        query.bindValue(":tariff", row.value("tariffName").toString());
        query.bindValue(":minutes", row.value("actualMinutes").toInt());
        query.bindValue(":gross", row.value("grossCents").toVariant().toLongLong());
        query.bindValue(":card", row.value("cardCoveredCents").toVariant().toLongLong());
        query.bindValue(":payable", row.value("payableCents").toVariant().toLongLong());
        if (!query.exec()) {
            m_lastError = query.lastError().text();
            return false;
        }
    }
    return true;
}

bool DatabaseManager::hasUsableMonthlyCard(int userId, const QString &chargerType)
{
    const QJsonObject billing = calculateBilling(userId, chargerType, 7.0, 100,
                                                 QDateTime::currentDateTime(), 1, true);
    return billing.value("cardCoveredMinutes").toInt() > 0;
}

QJsonObject DatabaseManager::startCharging(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    const int chargerId = request.value("chargerId").toInt();
    if (userId <= 0 || chargerId <= 0) {
        return response(false, "用户或电桩参数无效");
    }

    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动充电事务", transaction));
    }
    const QJsonObject user = selectOne(
                "SELECT status,balance_cents,credit_score,debt_cents FROM users WHERE id=:id",
                {{":id", userId}});
    if (user.isEmpty()) {
        transaction.rollback();
        return response(false, "用户不存在");
    }
    const int creditScore = normalizedCreditScore(user.value("credit_score").toInt());
    if (creditScore == 0 || user.value("status").toString() == "banned") {
        transaction.rollback();
        return response(false, "信誉分为 0，账号已封禁");
    }
    if (user.value("status").toString() != "normal") {
        transaction.rollback();
        return response(false, "账号不可用");
    }
    if (!selectOne("SELECT id FROM orders WHERE user_id=:user AND status='charging'",
                   {{":user", userId}}).isEmpty()) {
        transaction.rollback();
        return response(false, "您有未完成的充电订单，请先结算");
    }
    const QJsonObject charger = selectOne(
                "SELECT c.status,c.power,c.type,s.price_cents FROM chargers c "
                "JOIN stations s ON s.id=c.station_id WHERE c.id=:id",
                {{":id", chargerId}});
    if (charger.value("status").toString() != "idle") {
        transaction.rollback();
        return response(false, "所选电桩当前不可用");
    }
    const qint64 balanceCents = user.value("balance_cents").toVariant().toLongLong();
    const qint64 debtCents = user.value("debt_cents").toVariant().toLongLong();
    const qint64 availableBudget = balanceCents
            + qMax<qint64>(0, BusinessRules::creditLimitCents(creditScore) - debtCents);
    const QDateTime startedAt = QDateTime::currentDateTime();
    const QJsonObject firstMinute = calculateBilling(
                userId,
                charger.value("type").toString(),
                charger.value("power").toDouble(),
                charger.value("price_cents").toVariant().toLongLong(),
                startedAt,
                1,
                true);
    const qint64 minimumFee = firstMinute.value("feeCents").toVariant().toLongLong();
    if (creditScore <= 10 && balanceCents <= 0 && minimumFee > 0) {
        transaction.rollback();
        return response(false, "信誉等级最低且余额不足；当前月卡额度也不可用");
    }
    if (availableBudget < minimumFee) {
        transaction.rollback();
        return response(false,
                        QString("余额与可用信誉额度不足，至少需要 ¥%1")
                        .arg(BusinessRules::amountFromCents(minimumFee), 0, 'f', 2));
    }

    QSqlQuery update(m_database);
    update.prepare("UPDATE chargers SET status='in_use' WHERE id=:id AND status='idle'");
    update.bindValue(":id", chargerId);
    if (!update.exec() || update.numRowsAffected() != 1) {
        transaction.rollback();
        return response(false, transactionFailure("电桩已被其他请求占用", transaction));
    }

    const QJsonArray tariffSnapshot = selectRows(
                "SELECT id,name,start_minute,end_minute,multiplier_percent,card_multiplier "
                "FROM tariff_periods WHERE active=1 ORDER BY start_minute");
    QSqlQuery order(m_database);
    order.prepare("INSERT INTO orders(user_id,charger_id,status,started_at,base_price_cents,charger_type,power_kw,tariff_snapshot) "
                  "VALUES(:user,:charger,'charging',:started,:price,:type,:power,:tariffs)");
    order.bindValue(":user", userId);
    order.bindValue(":charger", chargerId);
    order.bindValue(":started", startedAt.toString(Qt::ISODate));
    order.bindValue(":price", charger.value("price_cents").toVariant().toLongLong());
    order.bindValue(":type", charger.value("type").toString());
    order.bindValue(":power", charger.value("power").toDouble());
    order.bindValue(":tariffs", QString::fromUtf8(
                        QJsonDocument(tariffSnapshot).toJson(QJsonDocument::Compact)));
    if (!order.exec()) {
        transaction.rollback();
        return response(false, transactionFailure(
                            "创建充电订单失败（同一用户或电桩已有活动订单）：" + order.lastError().text(),
                            transaction));
    }
    const int orderId = order.lastInsertId().toInt();
    if (!transaction.commit()) {
        return response(false, transactionFailure("提交充电事务失败", transaction));
    }
    QJsonObject data;
    data.insert("orderId", orderId);
    data.insert("startedAt", startedAt.toString(Qt::ISODate));
    data.insert("availableBudget", BusinessRules::amountFromCents(availableBudget));
    data.insert("firstMinuteCardCovered", minimumFee == 0);
    return response(true, minimumFee == 0 ? "充电已开始，本分钟由月卡抵扣" : "充电已开始", data);
}

QJsonObject DatabaseManager::stopCharging(const QJsonObject &request)
{
    return settleChargingOrder(request.value("orderId").toInt(),
                               false,
                               request.value("userId").toInt());
}

QJsonObject DatabaseManager::settleChargingOrder(int orderId,
                                                 bool automaticallyStopped,
                                                 int expectedUserId)
{
    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动结算事务", transaction));
    }
    QJsonObject order = selectOne(
                "SELECT o.id,o.user_id,o.charger_id,o.started_at,u.balance_cents,u.debt_cents,"
                "u.debt_since,u.credit_penalty_points,u.credit_score,u.status,"
                "CASE WHEN o.power_kw>0 THEN o.power_kw ELSE c.power END AS power_kw,"
                "CASE WHEN o.base_price_cents>0 THEN o.base_price_cents ELSE s.price_cents END AS base_price_cents,"
                "CASE WHEN o.charger_type!='' THEN o.charger_type ELSE c.type END AS charger_type,"
                "o.tariff_snapshot "
                "FROM orders o JOIN users u ON u.id=o.user_id "
                "JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id "
                "WHERE o.id=:id AND o.status='charging'",
                {{":id", orderId}});
    if (order.isEmpty()) {
        transaction.rollback();
        return response(false, "没有找到进行中的订单");
    }
    if (expectedUserId > 0 && order.value("user_id").toInt() != expectedUserId) {
        transaction.rollback();
        return response(false, "不能结束其他用户的充电订单");
    }

    const QDateTime start = QDateTime::fromString(order.value("started_at").toString(), Qt::ISODate);
    const int seconds = qMax(1, static_cast<int>(start.secsTo(QDateTime::currentDateTime())));
    const int minutes = qMax(1, (seconds + 59) / 60);
    const double energy = order.value("power_kw").toDouble() * minutes / 60.0 * 0.85;
    const QJsonArray tariffSnapshot = jsonArrayFromString(
                order.value("tariff_snapshot").toString());
    const QJsonObject billing = calculateBilling(
                order.value("user_id").toInt(),
                order.value("charger_type").toString(),
                order.value("power_kw").toDouble(),
                order.value("base_price_cents").toVariant().toLongLong(),
                start,
                minutes,
                true,
                tariffSnapshot);
    const qint64 grossFeeCents = billing.value("grossFeeCents").toVariant().toLongLong();
    const qint64 feeCents = billing.value("feeCents").toVariant().toLongLong();
    const qint64 cardDiscountCents = billing.value("cardDiscountCents").toVariant().toLongLong();
    const qint64 balanceCents = order.value("balance_cents").toVariant().toLongLong();
    const qint64 paidAmountCents = qMin(balanceCents, feeCents);
    const qint64 outstandingCents = feeCents - paidAmountCents;
    const qint64 previousDebtCents = order.value("debt_cents").toVariant().toLongLong();
    const qint64 newDebtCents = previousDebtCents + outstandingCents;
    const bool fullyPaid = outstandingCents == 0;
    const int currentCredit = normalizedCreditScore(order.value("credit_score").toInt());
    bool creditRewarded = false;
    int newCredit = currentCredit;
    QString debtSince = order.value("debt_since").toString();
    int penaltyPoints = order.value("credit_penalty_points").toInt();
    if (previousDebtCents == 0 && outstandingCents > 0) {
        debtSince = nowIso();
        penaltyPoints = 0;
    }

    QSqlQuery finish(m_database);
    finish.prepare("UPDATE orders SET status=:status,ended_at=:ended,minutes=:minutes,"
                   "energy=:energy,gross_fee_cents=:gross,fee_cents=:fee,"
                   "paid_amount_cents=:paid,outstanding_cents=:outstanding,"
                   "card_discount_cents=:cardDiscount,"
                   "auto_stopped=:auto WHERE id=:id AND status='charging'");
    finish.bindValue(":status", fullyPaid ? "completed" : "unpaid");
    finish.bindValue(":ended", nowIso());
    finish.bindValue(":minutes", minutes);
    finish.bindValue(":energy", energy);
    finish.bindValue(":gross", grossFeeCents);
    finish.bindValue(":fee", feeCents);
    finish.bindValue(":paid", paidAmountCents);
    finish.bindValue(":outstanding", outstandingCents);
    finish.bindValue(":cardDiscount", cardDiscountCents);
    finish.bindValue(":auto", automaticallyStopped ? 1 : 0);
    finish.bindValue(":id", orderId);

    QSqlQuery updateCharger(m_database);
    updateCharger.prepare("UPDATE chargers SET status='idle',charge_count=charge_count+1,"
                          "charge_minutes=charge_minutes+:minutes WHERE id=:id AND status='in_use'");
    updateCharger.bindValue(":minutes", minutes);
    updateCharger.bindValue(":id", order.value("charger_id").toInt());

    if (fullyPaid && minutes >= 10 && currentCredit > 0
            && order.value("status").toString() != "banned") {
        QSqlQuery reward(m_database);
        reward.prepare("INSERT OR IGNORE INTO credit_events(user_id,event_date,event_type,points,order_id,created_at) "
                       "VALUES(:user,:date,'completed_order',1,:order,:created)");
        reward.bindValue(":user", order.value("user_id").toInt());
        reward.bindValue(":date", todayIso());
        reward.bindValue(":order", orderId);
        reward.bindValue(":created", nowIso());
        if (!reward.exec()) {
            transaction.rollback();
            return response(false, transactionFailure("信誉奖励写入失败：" + reward.lastError().text(), transaction));
        }
        creditRewarded = reward.numRowsAffected() == 1;
        if (creditRewarded) {
            newCredit = qMin(100, currentCredit + 1);
        }
    }

    QSqlQuery updateUser(m_database);
    updateUser.prepare("UPDATE users SET balance_cents=:balance,debt_cents=:debt,debt_since=:debtSince,"
                       "credit_penalty_points=:penalty,credit_score=:credit WHERE id=:id");
    updateUser.bindValue(":balance", balanceCents - paidAmountCents);
    updateUser.bindValue(":debt", newDebtCents);
    updateUser.bindValue(":debtSince", debtSince);
    updateUser.bindValue(":penalty", penaltyPoints);
    updateUser.bindValue(":credit", newCredit);
    updateUser.bindValue(":id", order.value("user_id").toInt());

    if (!finish.exec() || finish.numRowsAffected() != 1) {
        transaction.rollback();
        return response(false, transactionFailure("订单状态更新失败：" + finish.lastError().text(), transaction));
    }
    if (!applyMonthlyCardUsage(orderId, billing.value("usageRows").toArray())) {
        transaction.rollback();
        return response(false, transactionFailure("月卡额度结算失败：" + m_lastError, transaction));
    }
    if (!applyPricingDetails(orderId, billing.value("pricingRows").toArray())) {
        transaction.rollback();
        return response(false, transactionFailure("分时计费明细保存失败：" + m_lastError, transaction));
    }
    if (!updateCharger.exec() || updateCharger.numRowsAffected() != 1 || !updateUser.exec()) {
        const QString sqlError = !updateCharger.lastError().text().isEmpty()
                ? updateCharger.lastError().text() : updateUser.lastError().text();
        transaction.rollback();
        return response(false, transactionFailure("订单关联数据结算失败：" + sqlError, transaction));
    }
    if (!transaction.commit()) {
        return response(false, transactionFailure("提交订单结算事务失败", transaction));
    }

    QJsonObject data;
    data.insert("minutes", minutes);
    data.insert("energy", energy);
    data.insert("grossFee", BusinessRules::amountFromCents(grossFeeCents));
    data.insert("cardDiscount", BusinessRules::amountFromCents(cardDiscountCents));
    data.insert("cardCoveredMinutes", billing.value("cardCoveredMinutes"));
    data.insert("fee", BusinessRules::amountFromCents(feeCents));
    data.insert("paidAmount", BusinessRules::amountFromCents(paidAmountCents));
    data.insert("outstanding", BusinessRules::amountFromCents(outstandingCents));
    data.insert("creditScore", newCredit);
    data.insert("creditRewarded", creditRewarded);
    data.insert("autoStopped", automaticallyStopped);

    QString message;
    if (automaticallyStopped && fullyPaid) {
        message = "可用额度即将用尽，系统已自动停止充电并完成结算";
    } else if (automaticallyStopped) {
        message = QString("可用额度即将用尽，系统已自动停止充电；本单欠费 ¥%1")
                .arg(BusinessRules::amountFromCents(outstandingCents), 0, 'f', 2);
    } else if (fullyPaid) {
        message = creditRewarded
                ? "充电已安全停止并完成结算，信誉分 +1"
                : "充电已安全停止并完成结算";
    } else {
        message = QString("充电已安全停止；本单欠费 ¥%1，请在 3 分钟内充值偿还")
                .arg(BusinessRules::amountFromCents(outstandingCents), 0, 'f', 2);
    }
    if (cardDiscountCents > 0) {
        message += QString("；月卡已抵扣 ¥%1").arg(
                    BusinessRules::amountFromCents(cardDiscountCents), 0, 'f', 2);
    }
    return response(true, message, data);
}

QJsonObject DatabaseManager::activeOrder(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    QJsonObject order = selectOne(
                "SELECT o.id,o.started_at,c.code,"
                "CASE WHEN o.power_kw>0 THEN o.power_kw ELSE c.power END AS power_kw,"
                "CASE WHEN o.charger_type!='' THEN o.charger_type ELSE c.type END AS charger_type,"
                "CASE WHEN o.base_price_cents>0 THEN o.base_price_cents ELSE s.price_cents END AS base_price_cents,"
                "o.tariff_snapshot,s.name AS station_name,u.balance_cents,u.debt_cents,u.credit_score "
                "FROM orders o JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id "
                "JOIN users u ON u.id=o.user_id "
                "WHERE o.user_id=:user AND o.status='charging'",
                {{":user", userId}});
    QJsonObject data;
    if (!order.isEmpty()) {
        const QDateTime start = QDateTime::fromString(order.value("started_at").toString(), Qt::ISODate);
        const int seconds = qMax(1, static_cast<int>(start.secsTo(QDateTime::currentDateTime())));
        const int minutes = qMax(1, (seconds + 59) / 60);
        const QJsonObject billing = calculateBilling(
                    userId,
                    order.value("charger_type").toString(),
                    order.value("power_kw").toDouble(),
                    order.value("base_price_cents").toVariant().toLongLong(),
                    start,
                    minutes,
                    true,
                    jsonArrayFromString(order.value("tariff_snapshot").toString()));
        const qint64 estimatedFeeCents = billing.value("feeCents").toVariant().toLongLong();
        const qint64 budgetCents = order.value("balance_cents").toVariant().toLongLong()
                + qMax<qint64>(0, BusinessRules::creditLimitCents(order.value("credit_score").toInt())
                               - order.value("debt_cents").toVariant().toLongLong());
        order.insert("estimated_fee", BusinessRules::amountFromCents(estimatedFeeCents));
        order.insert("gross_estimated_fee", BusinessRules::amountFromCents(
                         billing.value("grossFeeCents").toVariant().toLongLong()));
        order.insert("card_discount", BusinessRules::amountFromCents(
                         billing.value("cardDiscountCents").toVariant().toLongLong()));
        order.insert("card_covered_minutes", billing.value("cardCoveredMinutes"));
        order.insert("spending_budget", BusinessRules::amountFromCents(budgetCents));
        order.insert("remaining_budget", BusinessRules::amountFromCents(qMax<qint64>(0, budgetCents - estimatedFeeCents)));
        data.insert("active", true);
        data.insert("order", order);
        return response(true, "查询成功", data);
    }

    data.insert("active", false);
    const QJsonObject recentAutoStop = selectOne(
                "SELECT id,fee_cents/100.0 AS fee,outstanding_cents/100.0 AS outstanding "
                "FROM orders WHERE user_id=:user AND auto_stopped=1 "
                "AND datetime(ended_at)>=datetime('now','localtime','-12 seconds') "
                "ORDER BY id DESC LIMIT 1",
                {{":user", userId}});
    if (!recentAutoStop.isEmpty()) {
        data.insert("auto_stop_order_id", recentAutoStop.value("id"));
        data.insert("notice",
                    QString("信誉额度即将超限，系统已自动结束订单 #%1，费用 ¥%2，欠费 ¥%3")
                    .arg(recentAutoStop.value("id").toInt())
                    .arg(recentAutoStop.value("fee").toDouble(), 0, 'f', 2)
                    .arg(recentAutoStop.value("outstanding").toDouble(), 0, 'f', 2));
    }
    return response(true, "当前无充电订单", data);
}

QJsonObject DatabaseManager::listOrders(const QJsonObject &request)
{
    const QJsonArray rows = selectRows(
                "SELECT o.id,s.name AS station,c.code,o.status,o.started_at,o.ended_at,"
                "o.minutes,ROUND(o.energy,2) AS energy,o.gross_fee_cents/100.0 AS gross_fee,"
                "o.card_discount_cents/100.0 AS card_discount,o.fee_cents/100.0 AS fee,"
                "o.paid_amount_cents/100.0 AS paid_amount,o.outstanding_cents/100.0 AS outstanding,"
                "o.auto_stopped "
                "FROM orders o JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id WHERE o.user_id=:user "
                "ORDER BY o.id DESC LIMIT 100",
                {{":user", request.value("userId").toInt()}});
    return response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::dashboard() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    QJsonObject data;
    data.insert("metrics", self->selectOne(
                    "SELECT "
                    "COALESCE(SUM(CASE WHEN date(ended_at)=date('now','localtime') THEN paid_amount_cents END),0)/100.0 AS today_revenue,"
                    "COALESCE(SUM(CASE WHEN strftime('%Y-%m',ended_at)=strftime('%Y-%m','now','localtime') THEN paid_amount_cents END),0)/100.0 AS month_revenue,"
                    "COALESCE(SUM(paid_amount_cents),0)/100.0 AS total_revenue,"
                    "SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS total_orders "
                    "FROM orders WHERE status!='charging'"));
    data.insert("chargerStatus", self->selectRows(
                    "SELECT status,COUNT(*) AS count FROM chargers GROUP BY status ORDER BY status"));
    data.insert("revenueTrend", self->selectRows(
                    "WITH RECURSIVE days(day) AS ("
                    "SELECT date('now','localtime','-6 day') UNION ALL "
                    "SELECT date(day,'+1 day') FROM days WHERE day<date('now','localtime')) "
                    "SELECT day,COALESCE(SUM(o.paid_amount_cents),0)/100.0 AS revenue "
                    "FROM days LEFT JOIN orders o ON date(o.ended_at)=day AND o.status!='charging' "
                    "GROUP BY day ORDER BY day"));
    return self->response(true, "查询成功", data);
}

QJsonObject DatabaseManager::listChargers(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    QString sql = "SELECT c.id,c.code,s.name AS station,c.type,c.power,c.status,"
                  "c.charge_count,c.charge_minutes,c.last_restart "
                  "FROM chargers c JOIN stations s ON s.id=c.station_id ";
    QVariantMap bindings;
    if (request.value("stationId").toInt() > 0) {
        sql += "WHERE s.id=:station ";
        bindings.insert(":station", request.value("stationId").toInt());
    }
    sql += "ORDER BY c.code";
    return self->response(true, "查询成功", self->selectRows(sql, bindings));
}

QJsonObject DatabaseManager::restartCharger(const QJsonObject &request)
{
    const int chargerId = request.value("chargerId").toInt();
    const QJsonObject charger = selectOne("SELECT status FROM chargers WHERE id=:id", {{":id", chargerId}});
    if (charger.isEmpty()) {
        return response(false, "电桩不存在");
    }
    if (charger.value("status").toString() == "in_use"
            || !selectOne("SELECT id FROM orders WHERE charger_id=:id AND status='charging'",
                          {{":id", chargerId}}).isEmpty()) {
        return response(false, "电桩正在充电，禁止普通远程重启；请先安全结束订单");
    }
    QSqlQuery query(m_database);
    query.prepare("UPDATE chargers SET status='idle',last_restart=:time WHERE id=:id AND status!='in_use'");
    query.bindValue(":time", nowIso());
    query.bindValue(":id", chargerId);
    if (!query.exec() || query.numRowsAffected() != 1) {
        return response(false, "远程重启失败");
    }
    return response(true, "远程重启指令已执行");
}

QJsonObject DatabaseManager::listAdminStations() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT s.id,s.name,s.area,s.address,s.latitude,s.longitude,s.price_cents/100.0 AS price,"
                "COUNT(c.id) AS total_count,"
                "ROUND(100.0*SUM(CASE WHEN c.status!='fault' THEN 1 ELSE 0 END)/COUNT(c.id),1) AS online_rate "
                "FROM stations s LEFT JOIN chargers c ON c.station_id=s.id "
                "GROUP BY s.id ORDER BY s.id");
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::addStation(const QJsonObject &request)
{
    const QString name = request.value("name").toString().trimmed();
    const QString area = request.value("area").toString().trimmed();
    const QString address = request.value("address").toString().trimmed();
    const int chargerCount = request.value("chargerCount").toInt();
    if (name.isEmpty() || area.isEmpty() || address.isEmpty()
            || chargerCount < 1 || chargerCount > 50) {
        return response(false, "电站信息不完整或电桩数量无效");
    }

    const double requestedPrice = request.value("price").toDouble();
    if (!qIsFinite(requestedPrice) || requestedPrice <= 0 || requestedPrice > 100) {
        return response(false, "电价必须大于 0");
    }
    const qint64 priceCents = BusinessRules::centsFromAmount(requestedPrice);
    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动新增电站事务", transaction));
    }
    QSqlQuery station(m_database);
    station.prepare("INSERT INTO stations(name,area,address,latitude,longitude,price,price_cents,created_at) "
                    "VALUES(:name,:area,:address,:latitude,:longitude,:price,:priceCents,:created)");
    station.bindValue(":name", name);
    station.bindValue(":area", area);
    station.bindValue(":address", address);
    station.bindValue(":latitude", request.value("latitude").toDouble());
    station.bindValue(":longitude", request.value("longitude").toDouble());
    station.bindValue(":price", requestedPrice);
    station.bindValue(":priceCents", priceCents);
    station.bindValue(":created", nowIso());
    if (!station.exec()) {
        transaction.rollback();
        return response(false, transactionFailure("新增电站失败：" + station.lastError().text(), transaction));
    }
    const int stationId = station.lastInsertId().toInt();
    for (int index = 1; index <= chargerCount; ++index) {
        QSqlQuery charger(m_database);
        charger.prepare("INSERT INTO chargers(station_id,code,type,power,status) "
                        "VALUES(:station,:code,:type,:power,'idle')");
        charger.bindValue(":station", stationId);
        charger.bindValue(":code",
                          QString("S%1-C%2")
                          .arg(stationId, 2, 10, QChar('0'))
                          .arg(index, 2, 10, QChar('0')));
        charger.bindValue(":type", index <= qCeil(chargerCount * 0.7) ? "快充" : "慢充");
        charger.bindValue(":power", index <= qCeil(chargerCount * 0.7) ? 120.0 : 7.0);
        if (!charger.exec()) {
            transaction.rollback();
            return response(false, transactionFailure("新增电桩失败：" + charger.lastError().text(), transaction));
        }
    }
    if (!transaction.commit()) {
        return response(false, transactionFailure("提交新增电站事务失败", transaction));
    }
    return response(true, "电站及电桩新增成功");
}

QJsonObject DatabaseManager::listUsers(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QString keyword = request.value("keyword").toString().trimmed();
    const QJsonArray rows = self->selectRows(
                "SELECT id,phone,nickname,balance_cents/100.0 AS balance,credit_score,"
                "CASE WHEN credit_score=0 THEN '封禁' WHEN credit_score<=10 THEN '最低' "
                "WHEN credit_score<=30 THEN '较低' WHEN credit_score<=60 THEN '一般' "
                "WHEN credit_score<=89 THEN '良好' ELSE '优秀' END AS credit_level,"
                "debt_cents/100.0 AS debt,CASE WHEN avatar='' THEN '否' ELSE '是' END AS has_avatar,"
                "CASE WHEN credit_score<=10 THEN 0 WHEN credit_score<=30 THEN 10 "
                "WHEN credit_score<=60 THEN 30 WHEN credit_score<=89 THEN 80 ELSE 200 END AS credit_limit,"
                "registered_at,status "
                "FROM users WHERE phone LIKE :keyword ESCAPE '\\' OR nickname LIKE :keyword ESCAPE '\\' ORDER BY id DESC",
                {{":keyword", "%" + SecurityUtils::escapeLikePattern(keyword) + "%"}});
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::toggleUser(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    const QJsonObject user = selectOne("SELECT status,credit_score FROM users WHERE id=:id",
                                       {{":id", userId}});
    if (user.isEmpty()) {
        return response(false, "用户不存在");
    }
    if (user.value("status").toString() == "banned"
            || user.value("credit_score").toInt() == 0) {
        return response(false, "信誉分为 0 的封禁账号不能直接解冻");
    }
    const QString target = user.value("status").toString() == "normal" ? "frozen" : "normal";
    QSqlQuery query(m_database);
    query.prepare("UPDATE users SET status=:status WHERE id=:id");
    query.bindValue(":status", target);
    query.bindValue(":id", userId);
    if (!query.exec()) {
        return response(false, "用户状态修改失败");
    }
    return response(true, target == "normal" ? "用户已解冻" : "用户已冻结");
}

QJsonObject DatabaseManager::listAllOrders() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT o.id,u.phone,s.name AS station,c.code,o.status,o.started_at,o.ended_at,"
                "o.minutes,ROUND(o.energy,2) AS energy,o.gross_fee_cents/100.0 AS gross_fee,"
                "o.card_discount_cents/100.0 AS card_discount,o.fee_cents/100.0 AS fee,"
                "o.paid_amount_cents/100.0 AS paid_amount,o.outstanding_cents/100.0 AS outstanding,"
                "o.auto_stopped "
                "FROM orders o JOIN users u ON u.id=o.user_id "
                "JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id ORDER BY o.id DESC LIMIT 200");
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::listTariffs() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT id,name,start_minute,end_minute,multiplier_percent,card_multiplier "
                "FROM tariff_periods WHERE active=1 ORDER BY start_minute");
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::listMonthlyCardPlans(const QJsonObject &request) const
{
    Q_UNUSED(request)
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT id,name,price_cents/100.0 AS price,daily_minutes,valid_days,charger_type,status "
                "FROM monthly_card_plans WHERE status='active' ORDER BY price_cents,id");
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::listMyMonthlyCards(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT c.id,p.name,p.daily_minutes,p.charger_type,c.purchased_at,c.valid_from,c.valid_to,"
                "CASE WHEN date(c.valid_to)<date(:today) THEN 'expired' ELSE c.status END AS status,"
                "COALESCE(d.used_equivalent_minutes,0) AS used_today,"
                "MAX(0,p.daily_minutes-COALESCE(d.used_equivalent_minutes,0)) AS remaining_today "
                "FROM user_monthly_cards c JOIN monthly_card_plans p ON p.id=c.plan_id "
                "LEFT JOIN daily_card_usage d ON d.card_id=c.id AND d.usage_date=:today "
                "WHERE c.user_id=:user ORDER BY c.id DESC",
                {{":today", todayIso()}, {":user", request.value("userId").toInt()}});
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::listAdminMonthlyCards() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT c.id,u.phone,u.nickname,p.name,p.charger_type,c.purchased_at,c.valid_from,c.valid_to,"
                "CASE WHEN date(c.valid_to)<date(:today) THEN 'expired' ELSE c.status END AS status,"
                "COALESCE(d.used_equivalent_minutes,0) AS used_today,p.daily_minutes,"
                "MAX(0,p.daily_minutes-COALESCE(d.used_equivalent_minutes,0)) AS remaining_today "
                "FROM user_monthly_cards c JOIN users u ON u.id=c.user_id "
                "JOIN monthly_card_plans p ON p.id=c.plan_id "
                "LEFT JOIN daily_card_usage d ON d.card_id=c.id AND d.usage_date=:today "
                "ORDER BY c.id DESC LIMIT 500", {{":today", todayIso()}});
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::buyMonthlyCard(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    const int planId = request.value("planId").toInt();
    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动购卡事务", transaction));
    }
    const QJsonObject plan = selectOne(
                "SELECT id,name,price_cents,daily_minutes,valid_days,charger_type FROM monthly_card_plans "
                "WHERE id=:id AND status='active'", {{":id", planId}});
    const QJsonObject user = selectOne(
                "SELECT balance_cents,status,credit_score FROM users WHERE id=:id", {{":id", userId}});
    if (plan.isEmpty() || user.isEmpty()) {
        transaction.rollback();
        return response(false, "用户或月卡套餐不存在");
    }
    if (user.value("status").toString() != "normal" || user.value("credit_score").toInt() <= 0) {
        transaction.rollback();
        return response(false, "账号当前不可购买月卡");
    }
    if (!selectOne("SELECT id FROM user_monthly_cards WHERE user_id=:user AND status='active' "
                   "AND date(valid_to)>=date(:today) LIMIT 1",
                   {{":user", userId}, {":today", todayIso()}}).isEmpty()) {
        transaction.rollback();
        return response(false, "已有尚未到期的月卡，到期后才能购买新卡");
    }
    const qint64 priceCents = plan.value("price_cents").toVariant().toLongLong();
    if (user.value("balance_cents").toVariant().toLongLong() < priceCents) {
        transaction.rollback();
        return response(false, "钱包余额不足；购买月卡不能使用信誉欠费额度");
    }
    QSqlQuery deduct(m_database);
    deduct.prepare("UPDATE users SET balance_cents=balance_cents-:price "
                   "WHERE id=:user AND balance_cents>=:price");
    deduct.bindValue(":price", priceCents);
    deduct.bindValue(":user", userId);
    if (!deduct.exec() || deduct.numRowsAffected() != 1) {
        transaction.rollback();
        return response(false, transactionFailure("扣款失败：" + deduct.lastError().text(), transaction));
    }
    const QDate validFrom = QDate::currentDate();
    const QDate validTo = validFrom.addDays(plan.value("valid_days").toInt() - 1);
    QSqlQuery card(m_database);
    card.prepare("INSERT INTO user_monthly_cards(user_id,plan_id,purchased_at,valid_from,valid_to,status) "
                 "VALUES(:user,:plan,:purchased,:from,:to,'active')");
    card.bindValue(":user", userId);
    card.bindValue(":plan", planId);
    card.bindValue(":purchased", nowIso());
    card.bindValue(":from", validFrom.toString(Qt::ISODate));
    card.bindValue(":to", validTo.toString(Qt::ISODate));
    if (!card.exec()) {
        transaction.rollback();
        return response(false, transactionFailure("月卡创建失败：" + card.lastError().text(), transaction));
    }
    if (!transaction.commit()) {
        return response(false, transactionFailure("提交购卡事务失败", transaction));
    }
    QJsonObject data;
    data.insert("cardId", card.lastInsertId().toInt());
    data.insert("planName", plan.value("name"));
    data.insert("validFrom", validFrom.toString(Qt::ISODate));
    data.insert("validTo", validTo.toString(Qt::ISODate));
    data.insert("dailyMinutes", plan.value("daily_minutes"));
    data.insert("user", userSnapshot(userId));
    return response(true, "月卡购买成功；每日额度当天有效，高峰期按 2 倍分钟消耗", data);
}

QJsonObject DatabaseManager::createFeedback(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    const QString category = request.value("category").toString().trimmed().left(20);
    const QString title = request.value("title").toString().trimmed().left(80);
    const QString content = request.value("content").toString().trimmed();
    if (category.isEmpty() || title.isEmpty() || content.isEmpty() || content.size() > 2000) {
        return response(false, "请完整填写反馈分类、标题和 1 至 2000 字内容");
    }
    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动反馈事务", transaction));
    }
    QSqlQuery feedbackQuery(m_database);
    feedbackQuery.prepare("INSERT INTO feedback(user_id,category,title,status,created_at,updated_at) "
                          "VALUES(:user,:category,:title,'open',:created,:updated)");
    feedbackQuery.bindValue(":user", userId);
    feedbackQuery.bindValue(":category", category);
    feedbackQuery.bindValue(":title", title);
    feedbackQuery.bindValue(":created", nowIso());
    feedbackQuery.bindValue(":updated", nowIso());
    if (!feedbackQuery.exec()) {
        transaction.rollback();
        return response(false, transactionFailure("反馈创建失败：" + feedbackQuery.lastError().text(), transaction));
    }
    const int feedbackId = feedbackQuery.lastInsertId().toInt();
    QSqlQuery message(m_database);
    message.prepare("INSERT INTO feedback_messages(feedback_id,sender_role,sender_id,content,created_at) "
                    "VALUES(:feedback,'user',:user,:content,:created)");
    message.bindValue(":feedback", feedbackId);
    message.bindValue(":user", userId);
    message.bindValue(":content", content);
    message.bindValue(":created", nowIso());
    if (!message.exec()) {
        transaction.rollback();
        return response(false, transactionFailure("反馈内容保存失败：" + message.lastError().text(), transaction));
    }
    if (!transaction.commit()) {
        return response(false, transactionFailure("提交反馈事务失败", transaction));
    }
    return response(true, "反馈已提交，管理员可以在客服中心查看并回复",
                    QJsonObject{{"feedbackId", feedbackId}});
}

QJsonObject DatabaseManager::listMyFeedback(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    return self->response(true, "查询成功", self->selectRows(
                "SELECT f.id,f.category,f.title,f.status,f.created_at,f.updated_at,"
                "(SELECT content FROM feedback_messages m WHERE m.feedback_id=f.id ORDER BY m.id DESC LIMIT 1) AS latest_message "
                "FROM feedback f WHERE f.user_id=:user ORDER BY f.updated_at DESC,f.id DESC",
                {{":user", request.value("userId").toInt()}}));
}

QJsonObject DatabaseManager::feedbackMessages(const QJsonObject &request, bool adminView) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const int feedbackId = request.value("feedbackId").toInt();
    QString ownerClause;
    QVariantMap bindings{{":feedback", feedbackId}};
    if (!adminView) {
        ownerClause = " AND f.user_id=:user";
        bindings.insert(":user", request.value("userId").toInt());
    }
    const QJsonObject ticket = self->selectOne(
                "SELECT f.id,f.category,f.title,f.status,f.created_at,f.updated_at,u.phone,u.nickname "
                "FROM feedback f JOIN users u ON u.id=f.user_id WHERE f.id=:feedback" + ownerClause,
                bindings);
    if (ticket.isEmpty()) {
        return self->response(false, "反馈不存在或无权查看");
    }
    QJsonObject data;
    data.insert("ticket", ticket);
    data.insert("messages", self->selectRows(
                    "SELECT id,sender_role,sender_id,content,created_at FROM feedback_messages "
                    "WHERE feedback_id=:feedback ORDER BY id", {{":feedback", feedbackId}}));
    return self->response(true, "查询成功", data);
}

QJsonObject DatabaseManager::replyFeedback(const QJsonObject &request, bool adminReply)
{
    const int feedbackId = request.value("feedbackId").toInt();
    const int senderId = adminReply
            ? request.value("adminId").toInt(1)
            : request.value("userId").toInt();
    const QString content = request.value("content").toString().trimmed();
    if (content.isEmpty() || content.size() > 2000) {
        return response(false, "回复内容应为 1 至 2000 字");
    }
    QString ownerSql = "SELECT id,status FROM feedback WHERE id=:feedback";
    QVariantMap bindings{{":feedback", feedbackId}};
    if (!adminReply) {
        ownerSql += " AND user_id=:user";
        bindings.insert(":user", senderId);
    }
    const QJsonObject ticket = selectOne(ownerSql, bindings);
    if (ticket.isEmpty()) {
        return response(false, "反馈不存在或无权回复");
    }
    if (ticket.value("status").toString() == "closed") {
        return response(false, "反馈已关闭，不能继续回复");
    }
    DatabaseTransaction transaction(m_database);
    if (!transaction.begin()) {
        return response(false, transactionFailure("无法启动回复事务", transaction));
    }
    QSqlQuery message(m_database);
    message.prepare("INSERT INTO feedback_messages(feedback_id,sender_role,sender_id,content,created_at) "
                    "VALUES(:feedback,:role,:sender,:content,:created)");
    message.bindValue(":feedback", feedbackId);
    message.bindValue(":role", adminReply ? "admin" : "user");
    message.bindValue(":sender", senderId);
    message.bindValue(":content", content);
    message.bindValue(":created", nowIso());
    if (!message.exec()) {
        transaction.rollback();
        return response(false, transactionFailure("回复保存失败：" + message.lastError().text(), transaction));
    }
    QSqlQuery touch(m_database);
    touch.prepare("UPDATE feedback SET status=:status,updated_at=:updated WHERE id=:id");
    touch.bindValue(":status", adminReply ? "answered" : "open");
    touch.bindValue(":updated", nowIso());
    touch.bindValue(":id", feedbackId);
    if (!touch.exec() || !transaction.commit()) {
        transaction.rollback();
        return response(false, transactionFailure("反馈状态更新失败：" + touch.lastError().text(), transaction));
    }
    return response(true, adminReply ? "管理员回复已发送" : "补充回复已发送");
}

QJsonObject DatabaseManager::listAdminFeedback(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QString keyword = SecurityUtils::escapeLikePattern(request.value("keyword").toString().trimmed());
    return self->response(true, "查询成功", self->selectRows(
                "SELECT f.id,u.phone,u.nickname,f.category,f.title,f.status,f.created_at,f.updated_at,"
                "(SELECT content FROM feedback_messages m WHERE m.feedback_id=f.id ORDER BY m.id DESC LIMIT 1) AS latest_message "
                "FROM feedback f JOIN users u ON u.id=f.user_id "
                "WHERE u.phone LIKE :keyword ESCAPE '\\' OR u.nickname LIKE :keyword ESCAPE '\\' "
                "OR f.title LIKE :keyword ESCAPE '\\' ORDER BY f.updated_at DESC,f.id DESC LIMIT 300",
                {{":keyword", "%" + keyword + "%"}}));
}

QJsonObject DatabaseManager::updateFeedbackStatus(const QJsonObject &request)
{
    const QString status = request.value("status").toString();
    if (status != "open" && status != "answered" && status != "closed") {
        return response(false, "不支持的反馈状态");
    }
    QSqlQuery query(m_database);
    query.prepare("UPDATE feedback SET status=:status,updated_at=:updated WHERE id=:id");
    query.bindValue(":status", status);
    query.bindValue(":updated", nowIso());
    query.bindValue(":id", request.value("feedbackId").toInt());
    if (!query.exec() || query.numRowsAffected() != 1) {
        return response(false, "反馈状态更新失败");
    }
    return response(true, "反馈状态已更新");
}

QJsonObject DatabaseManager::listAuditLogs(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const int limit = qBound(20, request.value("limit").toInt(200), 500);
    return self->response(true, "查询成功", self->selectRows(
                QString("SELECT id,created_at,level,actor_role,actor_id,action,request_id,success,message "
                        "FROM audit_logs ORDER BY id DESC LIMIT %1").arg(limit)));
}

QStringList DatabaseManager::runCreditMaintenance()
{
    QStringList messages;
    const QDateTime current = QDateTime::currentDateTime();

    const QJsonArray debtors = selectRows(
                "SELECT id,phone,credit_score,debt_cents,debt_since,credit_penalty_points "
                "FROM users WHERE debt_cents>0 AND credit_score>0");
    for (const QJsonValue &value : debtors) {
        const QJsonObject user = value.toObject();
        const int userId = user.value("id").toInt();
        QDateTime debtSince = QDateTime::fromString(user.value("debt_since").toString(), Qt::ISODate);
        if (!debtSince.isValid()) {
            QSqlQuery initializeDebtTime(m_database);
            initializeDebtTime.prepare("UPDATE users SET debt_since=:time,credit_penalty_points=0 WHERE id=:id");
            initializeDebtTime.bindValue(":time", nowIso());
            initializeDebtTime.bindValue(":id", userId);
            initializeDebtTime.exec();
            continue;
        }

        const qint64 overdueSeconds = debtSince.secsTo(current);
        const int overduePeriods = overdueSeconds >= 180
                ? static_cast<int>(overdueSeconds / 180) : 0;
        const int targetPenaltyPoints = overduePeriods > 0 ? overduePeriods + 1 : 0;
        const int appliedPenaltyPoints = user.value("credit_penalty_points").toInt();
        const int additionalPenalty = targetPenaltyPoints - appliedPenaltyPoints;
        if (additionalPenalty <= 0) {
            continue;
        }

        const int oldCredit = normalizedCreditScore(user.value("credit_score").toInt());
        const int newCredit = qMax(0, oldCredit - additionalPenalty);
        QSqlQuery update(m_database);
        update.prepare("UPDATE users SET credit_score=:score,credit_penalty_points=:penalty,"
                       "status=CASE WHEN :scoreForStatus=0 THEN 'banned' ELSE status END WHERE id=:id");
        update.bindValue(":score", newCredit);
        update.bindValue(":scoreForStatus", newCredit);
        update.bindValue(":penalty", targetPenaltyPoints);
        update.bindValue(":id", userId);
        if (update.exec()) {
            messages.append(QString("用户 %1 欠费逾期，信誉分 %2 → %3")
                            .arg(user.value("phone").toString())
                            .arg(oldCredit)
                            .arg(newCredit));
        }
    }

    const QJsonArray activeOrders = selectRows(
                "SELECT o.id,o.user_id,o.started_at,u.phone,u.balance_cents,u.debt_cents,u.credit_score,u.status,"
                "CASE WHEN o.power_kw>0 THEN o.power_kw ELSE c.power END AS power_kw,"
                "CASE WHEN o.base_price_cents>0 THEN o.base_price_cents ELSE s.price_cents END AS base_price_cents,"
                "CASE WHEN o.charger_type!='' THEN o.charger_type ELSE c.type END AS charger_type,"
                "o.tariff_snapshot "
                "FROM orders o JOIN users u ON u.id=o.user_id "
                "JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id WHERE o.status='charging'");
    for (const QJsonValue &value : activeOrders) {
        const QJsonObject order = value.toObject();
        const QDateTime start = QDateTime::fromString(order.value("started_at").toString(), Qt::ISODate);
        if (!start.isValid()) {
            continue;
        }
        const int seconds = qMax(1, static_cast<int>(start.secsTo(current)));
        const int minutes = qMax(1, (seconds + 59) / 60);
        const QJsonObject currentBilling = calculateBilling(
                    order.value("user_id").toInt(),
                    order.value("charger_type").toString(),
                    order.value("power_kw").toDouble(),
                    order.value("base_price_cents").toVariant().toLongLong(),
                    start,
                    minutes,
                    true,
                    jsonArrayFromString(order.value("tariff_snapshot").toString()));
        const QJsonObject nextBilling = calculateBilling(
                    order.value("user_id").toInt(),
                    order.value("charger_type").toString(),
                    order.value("power_kw").toDouble(),
                    order.value("base_price_cents").toVariant().toLongLong(),
                    start,
                    minutes + 1,
                    true,
                    jsonArrayFromString(order.value("tariff_snapshot").toString()));
        const qint64 currentFee = currentBilling.value("feeCents").toVariant().toLongLong();
        const qint64 nextMinuteFee = nextBilling.value("feeCents").toVariant().toLongLong();
        const qint64 spendingBudget = order.value("balance_cents").toVariant().toLongLong()
                + qMax<qint64>(0, BusinessRules::creditLimitCents(order.value("credit_score").toInt())
                               - order.value("debt_cents").toVariant().toLongLong());
        const bool accountBanned = order.value("credit_score").toInt() <= 0
                || order.value("status").toString() == "banned";
        if (!accountBanned && currentFee < spendingBudget
                && nextMinuteFee <= spendingBudget) {
            continue;
        }

        const QJsonObject result = settleChargingOrder(order.value("id").toInt(), true);
        if (result.value("ok").toBool()) {
            messages.append(QString("用户 %1 的订单 #%2 达到信誉额度边界，已自动停桩")
                            .arg(order.value("phone").toString())
                            .arg(order.value("id").toInt()));
        }
    }
    return messages;
}
