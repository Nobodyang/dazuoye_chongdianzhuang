#ifndef ADMIN_EXTENSIONS_WIDGET_H
#define ADMIN_EXTENSIONS_WIDGET_H

#include <QWidget>
#include <QStringList>

class DatabaseManager;
class QComboBox;
class QPlainTextEdit;
class QPushButton;
class QTableWidget;

class AdminExtensionsWidget : public QWidget
{
public:
    explicit AdminExtensionsWidget(DatabaseManager *database, QWidget *parent = nullptr);

    void refreshAll();

private:
    void refreshFeedback();
    void refreshMessages();
    void refreshAudit();
    void refreshTariffs();
    void refreshPlans();
    void refreshMemberCards();
    void fillTable(QTableWidget *table,
                   const class QJsonArray &rows,
                   const QStringList &keys,
                   const QStringList &headers);
    int selectedFeedbackId() const;

    DatabaseManager *m_database;
    QTableWidget *m_feedbackTable;
    QTableWidget *m_messageTable;
    QPlainTextEdit *m_replyEdit;
    QComboBox *m_statusCombo;
    QTableWidget *m_auditTable;
    QTableWidget *m_tariffTable;
    QTableWidget *m_planTable;
    QTableWidget *m_memberCardTable;
};

#endif // ADMIN_EXTENSIONS_WIDGET_H
