#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "add_station_dialog.h"
#include "admin_extensions_widget.h"
#include "tcp_server_worker.h"

#include <QBarCategoryAxis>
#include <QChart>
#include <QChartView>
#include <QDateTime>
#include <QHeaderView>
#include <QLineSeries>
#include <QLegend>
#include <QMessageBox>
#include <QMetaObject>
#include <QPainter>
#include <QTableWidget>
#include <QValueAxis>
#include <QtGlobal>

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
QT_CHARTS_USE_NAMESPACE
#endif

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_tcpWorker(new TcpServerWorker)
    , m_extensions(nullptr)
{
    ui->setupUi(this);
    m_extensions = new AdminExtensionsWidget(&m_database, ui->tabWidget);
    ui->tabWidget->addTab(m_extensions, "客服 / 审计 / 计费");
    configureTables();
    ui->stackedWidget->setCurrentWidget(ui->loginPage);
    ui->passwordEdit->setEchoMode(QLineEdit::Password);
    ui->usernameEdit->setText("admin");
    ui->passwordEdit->setText("123456");

    m_tcpWorker->moveToThread(&m_serverThread);
    connect(this, &MainWindow::startServer,
            m_tcpWorker, &TcpServerWorker::start);
    connect(this, &MainWindow::stopServer,
            m_tcpWorker, &TcpServerWorker::stop);
    connect(this, &MainWindow::responseReady,
            m_tcpWorker, &TcpServerWorker::sendResponse);
    connect(m_tcpWorker, &TcpServerWorker::requestReceived,
            this, &MainWindow::handleClientRequest,
            Qt::QueuedConnection);
    connect(m_tcpWorker, &TcpServerWorker::logMessage,
            this, &MainWindow::appendServerLog,
            Qt::QueuedConnection);
    connect(m_tcpWorker, &TcpServerWorker::listeningChanged,
            this, &MainWindow::updateListeningState,
            Qt::QueuedConnection);
    connect(&m_serverThread, &QThread::finished,
            m_tcpWorker, &QObject::deleteLater);
    connect(&m_creditTimer, &QTimer::timeout,
            this, &MainWindow::processCreditPolicies);
}

MainWindow::~MainWindow()
{
    m_creditTimer.stop();
    if (m_serverThread.isRunning()) {
        QMetaObject::invokeMethod(m_tcpWorker,
                                  "stop",
                                  Qt::BlockingQueuedConnection);
    }
    m_serverThread.quit();
    m_serverThread.wait(3000);
    delete ui;
}

bool MainWindow::initialize()
{
    if (!m_database.open()) {
        appendServerLog("数据库打开失败：" + m_database.lastError());
        return false;
    }
    ui->databasePathLabel->setText("数据库：" + m_database.databasePath());
    m_creditTimer.start(1000);
    m_serverThread.start();
    emit startServer(9999);
    return true;
}

void MainWindow::configureTables()
{
    const QList<QTableWidget *> tables = {
        ui->chargerTable,
        ui->stationTable,
        ui->stationChargerTable,
        ui->userTable,
        ui->orderTable
    };
    for (QTableWidget *table : tables) {
        table->setAlternatingRowColors(true);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->horizontalHeader()->setStretchLastSection(true);
        table->verticalHeader()->setVisible(false);
    }
}

void MainWindow::on_loginButton_clicked()
{
    if (!m_database.validateAdmin(ui->usernameEdit->text(), ui->passwordEdit->text())) {
        ui->loginHintLabel->setText("账号或密码错误");
        return;
    }
    ui->loginHintLabel->clear();
    ui->stackedWidget->setCurrentWidget(ui->adminPage);
    loadAllData();
    appendServerLog("管理员登录成功");
}

void MainWindow::on_logoutButton_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->loginPage);
    ui->passwordEdit->clear();
    appendServerLog("管理员已退出");
}

void MainWindow::on_refreshButton_clicked()
{
    loadAllData();
    statusBar()->showMessage("数据已刷新", 2500);
}

void MainWindow::loadAllData()
{
    loadDashboard();
    loadChargers();
    loadStations();
    loadUsers(ui->userSearchEdit->text());
    loadOrders();
    m_extensions->refreshAll();
}

void MainWindow::loadDashboard()
{
    const QJsonObject response = m_database.handleRequest({{"action", "dashboard"}}, true);
    const QJsonObject data = response.value("data").toObject();
    const QJsonObject metrics = data.value("metrics").toObject();
    ui->todayRevenueLabel->setText(QString("¥ %1").arg(metrics.value("today_revenue").toDouble(), 0, 'f', 2));
    ui->monthRevenueLabel->setText(QString("¥ %1").arg(metrics.value("month_revenue").toDouble(), 0, 'f', 2));
    ui->totalRevenueLabel->setText(QString("¥ %1").arg(metrics.value("total_revenue").toDouble(), 0, 'f', 2));
    ui->orderCountLabel->setText(QString::number(metrics.value("total_orders").toInt()));

    int idleCount = 0;
    int inUseCount = 0;
    int faultCount = 0;
    for (const QJsonValue &value : data.value("chargerStatus").toArray()) {
        const QJsonObject row = value.toObject();
        const QString status = row.value("status").toString();
        if (status == "idle") {
            idleCount = row.value("count").toInt();
        } else if (status == "in_use") {
            inUseCount = row.value("count").toInt();
        } else if (status == "fault") {
            faultCount = row.value("count").toInt();
        }
    }
    ui->chargerSummaryLabel->setText(
                QString("空闲 %1    在用 %2    故障 %3").arg(idleCount).arg(inUseCount).arg(faultCount));

    QLayoutItem *item = nullptr;
    while ((item = ui->chartHostLayout->takeAt(0)) != nullptr) {
        if (item->widget() != nullptr) {
            item->widget()->deleteLater();
        }
        delete item;
    }

    QLineSeries *series = new QLineSeries;
    series->setName("营收");
    QStringList categories;
    int pointIndex = 0;
    double maximum = 10.0;
    for (const QJsonValue &value : data.value("revenueTrend").toArray()) {
        const QJsonObject row = value.toObject();
        const double revenue = row.value("revenue").toDouble();
        series->append(pointIndex++, revenue);
        categories.append(row.value("day").toString().right(5));
        maximum = qMax(maximum, revenue * 1.2);
    }

    QChart *chart = new QChart;
    chart->addSeries(series);
    chart->setTitle("近 7 日营收趋势");
    chart->legend()->hide();
    QBarCategoryAxis *axisX = new QBarCategoryAxis;
    axisX->append(categories);
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(0, maximum);
    axisY->setLabelFormat("%.0f");
    axisY->setTitleText("元");
    chart->addAxis(axisX, Qt::AlignBottom);
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisX);
    series->attachAxis(axisY);
    chart->setAnimationOptions(QChart::SeriesAnimations);

    QChartView *chartView = new QChartView(chart, ui->chartHost);
    chartView->setRenderHint(QPainter::Antialiasing);
    ui->chartHostLayout->addWidget(chartView);
}

void MainWindow::fillTable(QTableWidget *table,
                           const QJsonArray &rows,
                           const QStringList &keys,
                           const QStringList &headers)
{
    table->clear();
    table->setColumnCount(keys.size());
    table->setHorizontalHeaderLabels(headers);
    table->setRowCount(rows.size());

    for (int rowIndex = 0; rowIndex < rows.size(); ++rowIndex) {
        const QJsonObject row = rows.at(rowIndex).toObject();
        for (int columnIndex = 0; columnIndex < keys.size(); ++columnIndex) {
            const QJsonValue value = row.value(keys.at(columnIndex));
            QString text;
            if (value.isDouble()) {
                const QString key = keys.at(columnIndex);
                const bool decimalValue = key.contains("price") || key == "fee"
                        || key == "energy" || key == "balance" || key == "debt"
                        || key == "paid_amount" || key == "outstanding"
                        || key == "gross_fee" || key == "card_discount";
                text = QString::number(value.toDouble(), 'f',
                                       decimalValue ? 2 : 0);
            } else {
                text = value.toVariant().toString();
            }
            QTableWidgetItem *item = new QTableWidgetItem(text);
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, row.value("id").toInt());
            }
            table->setItem(rowIndex, columnIndex, item);
        }
    }
    table->resizeColumnsToContents();
}

void MainWindow::loadChargers(int stationId)
{
    QJsonObject request{{"action", "admin_chargers"}};
    if (stationId > 0) {
        request.insert("stationId", stationId);
    }
    const QJsonArray rows = m_database.handleRequest(request, true).value("data").toArray();
    QTableWidget *target = stationId > 0 ? ui->stationChargerTable : ui->chargerTable;
    fillTable(target, rows,
              {"id", "code", "station", "type", "power", "status", "charge_count", "charge_minutes", "last_restart"},
              {"ID", "电桩编号", "所属电站", "类型", "功率(kW)", "状态", "充电次数", "累计分钟", "最近重启"});
}

void MainWindow::loadStations()
{
    const QJsonArray rows = m_database.handleRequest({{"action", "admin_stations"}}, true)
            .value("data").toArray();
    fillTable(ui->stationTable, rows,
              {"id", "name", "area", "address", "latitude", "longitude", "price", "total_count", "online_rate"},
              {"ID", "电站名称", "区域", "详细地址", "纬度", "经度", "电价", "电桩数", "在线率(%)"});
}

void MainWindow::loadUsers(const QString &keyword)
{
    const QJsonArray rows = m_database.handleRequest(
                {{"action", "admin_users"}, {"keyword", keyword}}, true).value("data").toArray();
    fillTable(ui->userTable, rows,
              {"id", "phone", "nickname", "balance", "credit_score", "credit_level",
               "credit_limit", "debt", "has_avatar", "registered_at", "status"},
              {"ID", "手机号", "昵称", "余额", "信誉分", "等级",
               "可欠额度", "欠费", "头像", "注册时间", "状态"});
}

void MainWindow::loadOrders()
{
    const QJsonArray rows = m_database.handleRequest({{"action", "admin_orders"}}, true)
            .value("data").toArray();
    fillTable(ui->orderTable, rows,
              {"id", "phone", "station", "code", "status", "started_at", "ended_at",
               "minutes", "energy", "gross_fee", "card_discount", "fee", "paid_amount", "outstanding", "auto_stopped"},
              {"ID", "用户", "电站", "电桩", "状态", "开始时间", "结束时间",
               "分钟", "电量", "原价", "月卡抵扣", "应付", "实付", "欠费", "自动停桩"});
}

int MainWindow::selectedId(QTableWidget *table) const
{
    const QList<QTableWidgetItem *> items = table->selectedItems();
    if (items.isEmpty()) {
        return 0;
    }
    const int row = items.first()->row();
    return table->item(row, 0)->data(Qt::UserRole).toInt();
}

void MainWindow::on_restartButton_clicked()
{
    const int chargerId = selectedId(ui->chargerTable);
    if (chargerId <= 0) {
        QMessageBox::information(this, tr("请选择电桩"), tr("请先在表格中选择需要远程重启的电桩。"));
        return;
    }
    const QJsonObject result = m_database.handleRequest(
                {{"action", "restart_charger"}, {"chargerId", chargerId}}, true);
    QMessageBox::information(this, tr("远程重启"), result.value("message").toString());
    appendServerLog(QString("管理员对电桩 ID=%1 执行远程重启").arg(chargerId));
    loadChargers();
    loadDashboard();
}

void MainWindow::on_addStationButton_clicked()
{
    AddStationDialog dialog(this);
    if (dialog.exec() != QDialog::Accepted) {
        return;
    }
    QJsonObject request = dialog.stationData();
    request.insert("action", "add_station");
    const QJsonObject result = m_database.handleRequest(request, true);
    QMessageBox::information(this, tr("新增电站"), result.value("message").toString());
    if (result.value("ok").toBool()) {
        appendServerLog("管理员新增充电站：" + request.value("name").toString());
        loadStations();
        loadChargers();
        loadDashboard();
    }
}

void MainWindow::on_toggleUserButton_clicked()
{
    const int userId = selectedId(ui->userTable);
    if (userId <= 0) {
        QMessageBox::information(this, tr("请选择用户"), tr("请先在表格中选择用户。"));
        return;
    }
    const QJsonObject result = m_database.handleRequest(
                {{"action", "toggle_user"}, {"userId", userId}}, true);
    QMessageBox::information(this, tr("用户状态"), result.value("message").toString());
    appendServerLog(QString("管理员修改用户 ID=%1 状态").arg(userId));
    loadUsers(ui->userSearchEdit->text());
}

void MainWindow::on_userSearchEdit_textChanged(const QString &text)
{
    if (ui->stackedWidget->currentWidget() == ui->adminPage) {
        loadUsers(text);
    }
}

void MainWindow::on_stationTable_itemSelectionChanged()
{
    const int stationId = selectedId(ui->stationTable);
    if (stationId > 0) {
        loadChargers(stationId);
    }
}

void MainWindow::handleClientRequest(qintptr clientId, const QJsonObject &request)
{
    const QString action = request.value("action").toString();
    appendServerLog(QString("收到请求 [%1] requestId=%2")
                    .arg(action)
                    .arg(request.value("requestId").toVariant().toString()));
    const QJsonObject response = m_database.handleRequest(request);
    emit responseReady(clientId, response);

    if (action == "start_charging" || action == "stop_charging"
            || action == "recharge" || action == "update_profile"
            || action == "buy_monthly_card" || action == "create_feedback"
            || action == "reply_feedback" || action == "admin_reply_feedback"
            || action == "update_feedback_status") {
        loadAllData();
    }
}

void MainWindow::appendServerLog(const QString &message)
{
    if (ui == nullptr) {
        return;
    }
    ui->logTextEdit->append(QString("[%1] %2")
                            .arg(QDateTime::currentDateTime().toString("HH:mm:ss"), message));
    if (!m_database.databasePath().isEmpty()) {
        m_database.writeRuntimeLog(message);
    }
}

void MainWindow::updateListeningState(bool listening, quint16 port)
{
    ui->serverStatusLabel->setText(listening
                                   ? QString("服务状态：运行中（端口 %1）").arg(port)
                                   : "服务状态：未监听");
    ui->serverStatusLabel->setStyleSheet(listening
                                         ? "color:#16803c;font-weight:600;"
                                         : "color:#c43b3b;font-weight:600;");
}

void MainWindow::processCreditPolicies()
{
    const QStringList messages = m_database.runCreditMaintenance();
    if (messages.isEmpty()) {
        return;
    }
    for (const QString &message : messages) {
        appendServerLog(message);
    }
    if (ui->stackedWidget->currentWidget() == ui->adminPage) {
        loadAllData();
    }
}
