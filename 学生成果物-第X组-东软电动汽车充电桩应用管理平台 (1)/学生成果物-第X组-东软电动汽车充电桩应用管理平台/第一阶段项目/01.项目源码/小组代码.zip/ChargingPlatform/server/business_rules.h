#ifndef BUSINESS_RULES_H
#define BUSINESS_RULES_H

#include <QDateTime>
#include <QString>
#include <QtGlobal>

namespace BusinessRules {

struct TariffRule
{
    int id = 0;
    QString name;
    int startMinute = 0;
    int endMinute = 1440;
    int multiplierPercent = 100;
    int cardMultiplier = 1;
};

int normalizedCreditScore(int score);
qint64 creditLimitCents(int score);
QString creditLevel(int score);
qint64 centsFromAmount(double amount);
double amountFromCents(qint64 cents);
qint64 minuteFeeCents(double powerKw,
                      qint64 basePriceCentsPerKwh,
                      int multiplierPercent);
int minuteOfDay(const QDateTime &time);
bool tariffContainsMinute(const TariffRule &rule, int minute);

} // namespace BusinessRules

#endif // BUSINESS_RULES_H
