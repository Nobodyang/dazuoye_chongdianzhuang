QT += core gui widgets network sql charts

CONFIG += c++14
TEMPLATE = app
TARGET = charging_server

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    admin_extensions_widget.cpp \
    database_manager.cpp \
    database_transaction.cpp \
    business_rules.cpp \
    security_utils.cpp \
    tcp_server_worker.cpp \
    add_station_dialog.cpp

HEADERS += \
    mainwindow.h \
    admin_extensions_widget.h \
    database_manager.h \
    database_transaction.h \
    business_rules.h \
    security_utils.h \
    tcp_server_worker.h \
    add_station_dialog.h

FORMS += \
    mainwindow.ui \
    add_station_dialog.ui

RESOURCES += ../shared/shared.qrc

DESTDIR = ../bin
OBJECTS_DIR = ../build/server/obj
MOC_DIR = ../build/server/moc
RCC_DIR = ../build/server/rcc
UI_DIR = ../build/server/ui
