#include "security_utils.h"

#include <QCryptographicHash>
#include <QPasswordDigestor>
#include <QRandomGenerator>

#include <cstring>

namespace SecurityUtils {

QByteArray randomBytes(int length)
{
    QByteArray bytes;
    bytes.resize(qMax(0, length));
    int offset = 0;
    while (offset < bytes.size()) {
        const quint32 value = QRandomGenerator::system()->generate();
        const int count = qMin(static_cast<int>(sizeof(value)), bytes.size() - offset);
        std::memcpy(bytes.data() + offset, &value, static_cast<size_t>(count));
        offset += count;
    }
    return bytes;
}

QString randomToken(int byteLength)
{
    return QString::fromLatin1(randomBytes(byteLength).toHex());
}

QString passwordHash(const QString &password,
                     const QString &saltHex,
                     int iterations)
{
    const QByteArray salt = QByteArray::fromHex(saltHex.toLatin1());
    const QByteArray derived = QPasswordDigestor::deriveKeyPbkdf2(
                QCryptographicHash::Sha256,
                password.toUtf8(),
                salt,
                qMax(10000, iterations),
                32);
    return QString::fromLatin1(derived.toHex());
}

bool verifyPassword(const QString &password,
                    const QString &saltHex,
                    int iterations,
                    const QString &expectedHashHex)
{
    const QByteArray actual = passwordHash(password, saltHex, iterations).toLatin1();
    const QByteArray expected = expectedHashHex.toLatin1();
    if (actual.size() != expected.size() || actual.isEmpty()) {
        return false;
    }
    unsigned char difference = 0;
    for (int index = 0; index < actual.size(); ++index) {
        difference |= static_cast<unsigned char>(actual.at(index))
                ^ static_cast<unsigned char>(expected.at(index));
    }
    return difference == 0;
}

QString escapeLikePattern(const QString &text)
{
    QString escaped = text;
    escaped.replace("\\", "\\\\");
    escaped.replace("%", "\\%");
    escaped.replace("_", "\\_");
    return escaped;
}

} // namespace SecurityUtils
