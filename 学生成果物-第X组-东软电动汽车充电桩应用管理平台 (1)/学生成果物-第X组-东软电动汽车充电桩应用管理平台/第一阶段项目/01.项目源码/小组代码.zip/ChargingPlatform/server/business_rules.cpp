#include "business_rules.h"

#include <QtMath>

namespace BusinessRules {

int normalizedCreditScore(int score)
{
    return qBound(0, score, 100);
}

qint64 creditLimitCents(int score)
{
    const int normalized = normalizedCreditScore(score);
    if (normalized <= 10) {
        return 0;
    }
    if (normalized <= 30) {
        return 1000;
    }
    if (normalized <= 60) {
        return 3000;
    }
    if (normalized <= 89) {
        return 8000;
    }
    return 20000;
}

QString creditLevel(int score)
{
    const int normalized = normalizedCreditScore(score);
    if (normalized == 0) {
        return "封禁";
    }
    if (normalized <= 10) {
        return "最低";
    }
    if (normalized <= 30) {
        return "较低";
    }
    if (normalized <= 60) {
        return "一般";
    }
    if (normalized <= 89) {
        return "良好";
    }
    return "优秀";
}

qint64 centsFromAmount(double amount)
{
    return qRound64(amount * 100.0);
}

double amountFromCents(qint64 cents)
{
    return static_cast<double>(cents) / 100.0;
}

qint64 minuteFeeCents(double powerKw,
                      qint64 basePriceCentsPerKwh,
                      int multiplierPercent)
{
    const double energyKwh = powerKw / 60.0 * 0.85;
    return qMax<qint64>(1, qRound64(energyKwh
                                   * static_cast<double>(basePriceCentsPerKwh)
                                   * qMax(0, multiplierPercent) / 100.0));
}

int minuteOfDay(const QDateTime &time)
{
    return time.time().hour() * 60 + time.time().minute();
}

bool tariffContainsMinute(const TariffRule &rule, int minute)
{
    if (rule.startMinute <= rule.endMinute) {
        return minute >= rule.startMinute && minute < rule.endMinute;
    }
    return minute >= rule.startMinute || minute < rule.endMinute;
}

} // namespace BusinessRules
