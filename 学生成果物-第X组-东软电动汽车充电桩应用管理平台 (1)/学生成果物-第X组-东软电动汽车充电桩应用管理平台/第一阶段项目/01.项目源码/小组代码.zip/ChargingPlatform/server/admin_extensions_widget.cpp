#include "admin_extensions_widget.h"

#include "database_manager.h"

#include <QComboBox>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QJsonArray>
#include <QJsonObject>
#include <QLabel>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSplitter>
#include <QTabWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>

AdminExtensionsWidget::AdminExtensionsWidget(DatabaseManager *database, QWidget *parent)
    : QWidget(parent)
    , m_database(database)
    , m_feedbackTable(new QTableWidget(this))
    , m_messageTable(new QTableWidget(this))
    , m_replyEdit(new QPlainTextEdit(this))
    , m_statusCombo(new QComboBox(this))
    , m_auditTable(new QTableWidget(this))
    , m_tariffTable(new QTableWidget(this))
    , m_planTable(new QTableWidget(this))
    , m_memberCardTable(new QTableWidget(this))
{
    QVBoxLayout *root = new QVBoxLayout(this);
    QTabWidget *tabs = new QTabWidget(this);
    root->addWidget(tabs);

    QWidget *feedbackPage = new QWidget(tabs);
    QVBoxLayout *feedbackLayout = new QVBoxLayout(feedbackPage);
    QSplitter *feedbackSplitter = new QSplitter(Qt::Vertical, feedbackPage);
    feedbackSplitter->addWidget(m_feedbackTable);
    feedbackSplitter->addWidget(m_messageTable);
    feedbackLayout->addWidget(feedbackSplitter, 1);
    m_replyEdit->setPlaceholderText("输入客服回复（最多 2000 字）");
    m_replyEdit->setMaximumHeight(90);
    feedbackLayout->addWidget(m_replyEdit);
    QHBoxLayout *feedbackTools = new QHBoxLayout;
    m_statusCombo->addItem("待处理", "open");
    m_statusCombo->addItem("已回复", "answered");
    m_statusCombo->addItem("已关闭", "closed");
    QPushButton *replyButton = new QPushButton("发送回复", feedbackPage);
    QPushButton *statusButton = new QPushButton("更新状态", feedbackPage);
    QPushButton *feedbackRefresh = new QPushButton("刷新", feedbackPage);
    feedbackTools->addWidget(new QLabel("工单状态：", feedbackPage));
    feedbackTools->addWidget(m_statusCombo);
    feedbackTools->addStretch();
    feedbackTools->addWidget(replyButton);
    feedbackTools->addWidget(statusButton);
    feedbackTools->addWidget(feedbackRefresh);
    feedbackLayout->addLayout(feedbackTools);
    tabs->addTab(feedbackPage, "客服反馈");

    QWidget *auditPage = new QWidget(tabs);
    QVBoxLayout *auditLayout = new QVBoxLayout(auditPage);
    QPushButton *auditRefresh = new QPushButton("刷新持久审计日志", auditPage);
    auditLayout->addWidget(auditRefresh, 0, Qt::AlignRight);
    auditLayout->addWidget(m_auditTable);
    tabs->addTab(auditPage, "审计日志");

    QWidget *rulesPage = new QWidget(tabs);
    QVBoxLayout *rulesLayout = new QVBoxLayout(rulesPage);
    rulesLayout->addWidget(new QLabel("峰谷分时计费（倍率基于站点基础电价；高峰月卡分钟双倍消耗）", rulesPage));
    rulesLayout->addWidget(m_tariffTable);
    rulesLayout->addWidget(new QLabel("月卡套餐", rulesPage));
    rulesLayout->addWidget(m_planTable);
    rulesLayout->addWidget(new QLabel("用户月卡与今日用量", rulesPage));
    rulesLayout->addWidget(m_memberCardTable);
    tabs->addTab(rulesPage, "计费与月卡");

    for (QTableWidget *table : {m_feedbackTable, m_messageTable, m_auditTable,
                                m_tariffTable, m_planTable, m_memberCardTable}) {
        table->setAlternatingRowColors(true);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->horizontalHeader()->setStretchLastSection(true);
        table->verticalHeader()->setVisible(false);
    }

    connect(m_feedbackTable, &QTableWidget::itemSelectionChanged,
            this, &AdminExtensionsWidget::refreshMessages);
    connect(feedbackRefresh, &QPushButton::clicked,
            this, &AdminExtensionsWidget::refreshFeedback);
    connect(auditRefresh, &QPushButton::clicked,
            this, &AdminExtensionsWidget::refreshAudit);
    connect(replyButton, &QPushButton::clicked, this, [this]() {
        const int feedbackId = selectedFeedbackId();
        if (feedbackId <= 0 || m_replyEdit->toPlainText().trimmed().isEmpty()) {
            QMessageBox::information(this, "客服回复", "请先选择工单并输入回复内容。");
            return;
        }
        const QJsonObject result = m_database->handleRequest(
                    {{"action", "admin_reply_feedback"},
                     {"feedbackId", feedbackId},
                     {"content", m_replyEdit->toPlainText().trimmed()}}, true);
        QMessageBox::information(this, "客服回复", result.value("message").toString());
        if (result.value("ok").toBool()) {
            m_replyEdit->clear();
            refreshFeedback();
            refreshMessages();
        }
    });
    connect(statusButton, &QPushButton::clicked, this, [this]() {
        const int feedbackId = selectedFeedbackId();
        if (feedbackId <= 0) {
            QMessageBox::information(this, "工单状态", "请先选择工单。");
            return;
        }
        const QJsonObject result = m_database->handleRequest(
                    {{"action", "update_feedback_status"},
                     {"feedbackId", feedbackId},
                     {"status", m_statusCombo->currentData().toString()}}, true);
        QMessageBox::information(this, "工单状态", result.value("message").toString());
        refreshFeedback();
    });
}

void AdminExtensionsWidget::fillTable(QTableWidget *table,
                                      const QJsonArray &rows,
                                      const QStringList &keys,
                                      const QStringList &headers)
{
    table->clear();
    table->setColumnCount(keys.size());
    table->setHorizontalHeaderLabels(headers);
    table->setRowCount(rows.size());
    for (int rowIndex = 0; rowIndex < rows.size(); ++rowIndex) {
        const QJsonObject row = rows.at(rowIndex).toObject();
        for (int columnIndex = 0; columnIndex < keys.size(); ++columnIndex) {
            const QString key = keys.at(columnIndex);
            QString text = row.value(key).toVariant().toString();
            if (key == "price") {
                text = QString::number(row.value(key).toDouble(), 'f', 2);
            }
            QTableWidgetItem *item = new QTableWidgetItem(text);
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, row.value("id").toInt());
            }
            table->setItem(rowIndex, columnIndex, item);
        }
    }
    table->resizeColumnsToContents();
}

int AdminExtensionsWidget::selectedFeedbackId() const
{
    const int row = m_feedbackTable->currentRow();
    return row >= 0 && m_feedbackTable->item(row, 0)
            ? m_feedbackTable->item(row, 0)->data(Qt::UserRole).toInt() : 0;
}

void AdminExtensionsWidget::refreshFeedback()
{
    const QJsonArray rows = m_database->handleRequest({{"action", "admin_feedback"}}, true)
            .value("data").toArray();
    fillTable(m_feedbackTable, rows,
              {"id", "phone", "nickname", "category", "title", "status", "updated_at", "latest_message"},
              {"ID", "手机号", "昵称", "分类", "标题", "状态", "更新时间", "最新消息"});
}

void AdminExtensionsWidget::refreshMessages()
{
    const int feedbackId = selectedFeedbackId();
    if (feedbackId <= 0) {
        m_messageTable->clear();
        return;
    }
    const QJsonObject result = m_database->handleRequest(
                {{"action", "feedback_messages"}, {"feedbackId", feedbackId}}, true);
    fillTable(m_messageTable, result.value("data").toObject().value("messages").toArray(),
              {"id", "sender_role", "content", "created_at"},
              {"ID", "发送方", "内容", "时间"});
}

void AdminExtensionsWidget::refreshAudit()
{
    const QJsonArray rows = m_database->handleRequest(
                {{"action", "audit_logs"}, {"limit", 300}}, true).value("data").toArray();
    fillTable(m_auditTable, rows,
              {"id", "created_at", "level", "actor_role", "actor_id", "action", "request_id", "success", "message"},
              {"ID", "时间", "级别", "角色", "主体ID", "动作", "请求ID", "成功", "消息"});
}

void AdminExtensionsWidget::refreshTariffs()
{
    const QJsonArray rows = m_database->handleRequest({{"action", "tariffs"}}, true)
            .value("data").toArray();
    fillTable(m_tariffTable, rows,
              {"id", "name", "start_minute", "end_minute", "multiplier_percent", "card_multiplier"},
              {"ID", "时段", "开始分钟", "结束分钟", "电价倍率(%)", "月卡倍率"});
}

void AdminExtensionsWidget::refreshPlans()
{
    const QJsonArray rows = m_database->handleRequest({{"action", "monthly_card_plans"}}, true)
            .value("data").toArray();
    fillTable(m_planTable, rows,
              {"id", "name", "price", "daily_minutes", "valid_days", "charger_type"},
              {"ID", "套餐", "价格", "每日分钟", "有效天数", "适用电桩"});
}

void AdminExtensionsWidget::refreshMemberCards()
{
    const QJsonArray rows = m_database->handleRequest({{"action", "admin_monthly_cards"}}, true)
            .value("data").toArray();
    fillTable(m_memberCardTable, rows,
              {"id", "phone", "nickname", "name", "charger_type", "valid_from", "valid_to",
               "used_today", "remaining_today", "status"},
              {"ID", "手机号", "昵称", "套餐", "适用电桩", "生效日", "到期日",
               "今日已用", "今日剩余", "状态"});
}

void AdminExtensionsWidget::refreshAll()
{
    refreshFeedback();
    refreshAudit();
    refreshTariffs();
    refreshPlans();
    refreshMemberCards();
}
