#ifndef DATABASE_TRANSACTION_H
#define DATABASE_TRANSACTION_H

#include <QSqlDatabase>
#include <QString>

class DatabaseTransaction
{
public:
    explicit DatabaseTransaction(QSqlDatabase database);
    ~DatabaseTransaction();

    bool begin();
    bool commit();
    bool rollback();
    bool isActive() const;
    QString error() const;
    QString rollbackError() const;

private:
    QSqlDatabase m_database;
    bool m_active;
    QString m_error;
    QString m_rollbackError;
};

#endif // DATABASE_TRANSACTION_H
