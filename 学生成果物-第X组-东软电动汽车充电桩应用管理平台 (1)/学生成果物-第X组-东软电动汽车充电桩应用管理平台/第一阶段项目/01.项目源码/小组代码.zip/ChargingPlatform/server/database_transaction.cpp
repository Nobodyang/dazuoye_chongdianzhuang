#include "database_transaction.h"

#include <QSqlError>
#include <QSqlQuery>

DatabaseTransaction::DatabaseTransaction(QSqlDatabase database)
    : m_database(database)
    , m_active(false)
{
}

DatabaseTransaction::~DatabaseTransaction()
{
    if (m_active) {
        rollback();
    }
}

bool DatabaseTransaction::begin()
{
    QSqlQuery query(m_database);
    m_active = query.exec("BEGIN IMMEDIATE");
    if (!m_active) {
        m_error = query.lastError().text();
    }
    return m_active;
}

bool DatabaseTransaction::commit()
{
    if (!m_active) {
        m_error = "没有活动事务";
        return false;
    }
    QSqlQuery query(m_database);
    if (!query.exec("COMMIT")) {
        m_error = query.lastError().text();
        rollback();
        return false;
    }
    m_active = false;
    return true;
}

bool DatabaseTransaction::rollback()
{
    if (!m_active) {
        return true;
    }
    QSqlQuery query(m_database);
    if (!query.exec("ROLLBACK")) {
        m_rollbackError = query.lastError().text();
        return false;
    }
    m_active = false;
    return true;
}

bool DatabaseTransaction::isActive() const
{
    return m_active;
}

QString DatabaseTransaction::error() const
{
    return m_error;
}

QString DatabaseTransaction::rollbackError() const
{
    return m_rollbackError;
}
