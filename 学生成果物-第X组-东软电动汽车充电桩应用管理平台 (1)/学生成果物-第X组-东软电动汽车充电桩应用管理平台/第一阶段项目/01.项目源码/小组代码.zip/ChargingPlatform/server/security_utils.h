#ifndef SECURITY_UTILS_H
#define SECURITY_UTILS_H

#include <QByteArray>
#include <QString>

namespace SecurityUtils {

QByteArray randomBytes(int length);
QString randomToken(int byteLength = 32);
QString passwordHash(const QString &password,
                     const QString &saltHex,
                     int iterations);
bool verifyPassword(const QString &password,
                    const QString &saltHex,
                    int iterations,
                    const QString &expectedHashHex);
QString escapeLikePattern(const QString &text);

} // namespace SecurityUtils

#endif // SECURITY_UTILS_H
