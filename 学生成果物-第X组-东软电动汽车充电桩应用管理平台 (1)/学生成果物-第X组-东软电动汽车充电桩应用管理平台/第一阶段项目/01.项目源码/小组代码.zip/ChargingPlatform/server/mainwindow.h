#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "database_manager.h"

#include <QJsonArray>
#include <QJsonObject>
#include <QMainWindow>
#include <QStringList>
#include <QThread>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class TcpServerWorker;
class AdminExtensionsWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    bool initialize();

signals:
    void startServer(quint16 port);
    void stopServer();
    void responseReady(qintptr clientId, const QJsonObject &response);

private slots:
    void on_loginButton_clicked();
    void on_logoutButton_clicked();
    void on_refreshButton_clicked();
    void on_restartButton_clicked();
    void on_addStationButton_clicked();
    void on_toggleUserButton_clicked();
    void on_userSearchEdit_textChanged(const QString &text);
    void on_stationTable_itemSelectionChanged();
    void handleClientRequest(qintptr clientId, const QJsonObject &request);
    void appendServerLog(const QString &message);
    void updateListeningState(bool listening, quint16 port);
    void processCreditPolicies();

private:
    void configureTables();
    void loadAllData();
    void loadDashboard();
    void loadChargers(int stationId = 0);
    void loadStations();
    void loadUsers(const QString &keyword = QString());
    void loadOrders();
    void fillTable(class QTableWidget *table,
                   const QJsonArray &rows,
                   const QStringList &keys,
                   const QStringList &headers);
    int selectedId(class QTableWidget *table) const;

    Ui::MainWindow *ui;
    DatabaseManager m_database;
    QThread m_serverThread;
    QTimer m_creditTimer;
    TcpServerWorker *m_tcpWorker;
    AdminExtensionsWidget *m_extensions;
};

#endif // MAINWINDOW_H
