# GitHub 多人协作约定

## 分支

- `main`：随时可演示，只接受通过验收的合并请求。
- `develop`：阶段集成分支。
- `feature/<模块>-<姓名>`：个人功能，例如 `feature/month-card-liming`。
- `fix/<问题>-<姓名>`：缺陷修复。

不要多人直接修改同一个大文件。V1.2 已把密码/令牌、事务、业务规则、管理扩展页和用户扩展页拆成独立模块。涉及协议或数据库的改动先在 `docs/` 和 `database/` 提交设计，再修改双方代码。

## 每日流程

```bash
git switch develop
git pull --rebase origin develop
git switch -c feature/feedback-yourname
# 编码、构建、测试
git add <明确的文件>
git commit -m "feat(feedback): add user ticket reply"
git push -u origin feature/feedback-yourname
```

从 GitHub 创建合并请求到 `develop`。至少一位非作者复核；CI 构建通过；协议、数据库、客户端与服务端变更保持同一合并请求或按明确顺序合并。

## 冲突热点与所有权

| 路径 | 主要责任 |
|---|---|
| `server/database_manager.*` | 服务端/数据库负责人 |
| `server/business_rules.*` | 计费与信誉负责人 |
| `server/security_utils.*` | 安全负责人 |
| `client/mainwindow.*` | 用户端负责人 |
| `analytics/` | 大数据负责人 |
| `docs/protocol.md` | 双方共同评审 |

`.github/CODEOWNERS` 中的示例账号必须由组长替换成真实 GitHub 用户名后再启用强制评审。

## 提交前检查

```bash
./scripts/build.sh
python3 -m py_compile scripts/acceptance_test.py analytics/generate_dashboard.py
python3 scripts/acceptance_test.py --db data/v12-acceptance.db
git status --short
```

严禁提交运行数据库、头像、构建目录、`.env`、证书、个人 Qt Creator 配置和拖拽缓存。不要在 SQL 或截图中公开真实用户手机号。
