# TCP JSON 协议（V1.2）

客户端与服务器使用 UTF-8 JSON Lines：一行一个 JSON 对象。请求与响应通过 `requestId` 对应。

## 公共字段

```json
{
  "action": "profile",
  "requestId": 1001,
  "sessionToken": "登录后返回的随机令牌",
  "idempotencyKey": "写操作使用的 UUID"
}
```

- `sessionToken`：除登录、电站公开查询、时段和月卡套餐查询外必须携带；默认有效期 7 天，可退出或过期撤销。
- `idempotencyKey`：充值、开/停充电、购卡、资料写入和反馈写入必须携带。相同账号、动作和幂等键的重试返回首次结果，不重复扣款或写入。
- 用户身份永远来自会话。服务器覆盖请求中的 `userId`，所以不能通过修改 JSON 查看或操作他人数据。
- 响应至少包含 `ok`、`message`、`requestId`；幂等重放额外包含 `idempotentReplay: true`。

## 登录

| action | 主要请求字段 | 返回数据 |
|---|---|---|
| `login_user` | `phone` | 用户资料、信誉、月卡摘要、`sessionToken` |
| `login_admin` | `username`, `password` | 管理员 ID、用户名、`sessionToken` |
| `logout` | 无 | 撤销当前令牌 |

手机号登录是课程演示模式；生产环境应接入短信验证码或密码/多因素认证。

## 用户接口

| action | 主要字段 | 说明 |
|---|---|---|
| `list_stations` | `area`, `latitude`, `longitude` | 电站与空闲数 |
| `station_detail` | `stationId` | 电桩明细 |
| `profile` | 无 | 当前会话用户资料与头像 Base64 |
| `update_profile` | `nickname`, `avatarData` | JPEG/PNG 等图片，原始数据不超过 2MB |
| `recharge` | `amount` | 模拟充值，优先偿还欠费 |
| `start_charging` | `chargerId` | 原子开单 |
| `active_order` | 无 | 实时原价、月卡抵扣、应付与额度余量 |
| `stop_charging` | `orderId` | 仅订单所有者可停止 |
| `list_orders` | 无 | 最近 100 条订单 |
| `tariffs` | 无 | 当前峰谷规则 |
| `monthly_card_plans` | 无 | 可购套餐 |
| `my_monthly_cards` | 无 | 月卡及今日等效分钟 |
| `buy_monthly_card` | `planId` | 钱包购卡 |
| `create_feedback` | `category`, `title`, `content` | 新建客服反馈 |
| `my_feedback` | 无 | 我的反馈 |
| `feedback_messages` | `feedbackId` | 对话详情 |
| `reply_feedback` | `feedbackId`, `content` | 用户补充 |

## 管理接口

管理员接口包括 `dashboard`、`admin_chargers`、`restart_charger`、`admin_stations`、`add_station`、`admin_users`、`toggle_user`、`admin_orders`、`admin_feedback`、`admin_reply_feedback`、`update_feedback_status` 和 `audit_logs`。远程调用需要管理员会话；服务端本机 UI 通过受信入口调用。

审计日志不保存密码、令牌或头像内容，只记录主体、动作、请求编号、结果和简短消息。
