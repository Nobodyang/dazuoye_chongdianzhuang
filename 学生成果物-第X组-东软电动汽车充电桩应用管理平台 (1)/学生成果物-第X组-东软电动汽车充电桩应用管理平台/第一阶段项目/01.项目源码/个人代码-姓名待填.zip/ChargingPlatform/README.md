# 东软电动汽车充电桩应用管理平台 V1.2

本工程包含 Qt 用户端、Qt 管理服务器、SQLite 数据库、TCP 通信、信誉风控、峰谷分时计费、月卡、头像、客服反馈、持久审计日志，以及第二阶段 Python 数据分析与 ECharts 大屏。

## 环境与构建

推荐 Ubuntu 22.04/24.04、Qt 5.15，安装依赖：

```bash
sudo apt update
sudo apt --fix-broken install
sudo apt install build-essential qtcreator qtbase5-dev qt5-qmake \
  libqt5sql5-sqlite libqt5charts5-dev python3
```

注意包名是 `libqt5sql5-sqlite`（`sql` 中是小写字母 `l`），检查命令是：

```bash
dpkg -l | grep -E 'libqt5sql5-sqlite|libqt5charts5-dev'
qmake --version
```

命令行构建与运行：

```bash
cd ~/ChargingPlatform
./scripts/build.sh
./build/bin/charging_server
./build/bin/charging_client
```

也可以用 Qt Creator 打开 `ChargingPlatform.pro`。先运行服务端，再运行一个或多个客户端；默认地址 `127.0.0.1:9999`。

演示账号：管理员 `admin / 123456`；用户输入任意合法 11 位手机号，首次登录自动注册。管理员密码在首次建库时通过 PBKDF2-SHA256 加随机盐存储，不再保存明文。

## 数据库位置

默认数据库位于：

```text
~/.local/share/NeusoftTraining/ChargingServer/charging_platform.db
```

服务端“服务器日志”页会显示实际路径。团队测试建议显式指定独立数据库：

```bash
export CHARGING_DB_PATH="$PWD/data/charging_platform.db"
./build/bin/charging_server
```

头像保存在数据库同级的 `avatars/` 目录；审计日志保存在数据库的 `audit_logs` 表。`data/`、头像和运行日志都不应提交到 Git。

## V1.2 核心规则

- 金额以整数“分”为唯一结算单位，兼容字段仅供旧分析程序读取。
- 同一用户、同一电桩最多各有一个 `charging` 订单；应用事务与 SQLite 部分唯一索引双重保证。
- 用户操作按会话令牌鉴权，服务器以会话身份覆盖客户端 `userId`；财务和状态写操作带幂等键。
- 订单使用开单时的站点基础价和时段规则快照，按每分钟所在时段计算峰谷价格。
- 月卡每天重置，未用分钟不结转；高峰期 1 分钟消耗 2 个等效分钟。
- 结算顺序：月卡抵扣 → 钱包余额 → 信誉额度欠费 → 达到额度边界自动停桩。
- 0 分封号；0～10 分用户在钱包与适用月卡均不可用时不能启动充电。
- 订单实付且实际充电不少于 10 分钟时可加 1 分，同一用户每天最多奖励一次，避免刷分。
- 欠费满 3 分钟扣 2 分，之后每 3 分钟扣 1 分；测试周期可在代码中恢复为正式周期。
- 在用电桩拒绝普通远程重启，必须先安全结束关联订单。

完整规则见 `docs/business-rules.md`，接口见 `docs/protocol.md`，多人协作见 `docs/team-workflow.md`。

## 验收测试

请使用独立测试库，避免修改演示数据：

```bash
cd ~/ChargingPlatform
export CHARGING_DB_PATH="$PWD/data/v12-acceptance.db"
./build/bin/charging_server
```

另开终端：

```bash
cd ~/ChargingPlatform
python3 scripts/acceptance_test.py --db data/v12-acceptance.db
```

脚本覆盖粘包/拆包、会话越权、并发开单、充值幂等、在用电桩重启保护、整数金额、信誉欠费、峰谷规则、月卡和客服闭环。

## 第二阶段大屏

```bash
cd ~/ChargingPlatform/analytics
python3 generate_dashboard.py --db ../data/charging_platform.db
python3 -m http.server 8080 --directory dashboard
```

浏览器访问 `http://127.0.0.1:8080`。

## 目录

```text
ChargingPlatform/
├── client/       Qt 用户端
├── server/       Qt 管理服务器、鉴权、事务和业务规则
├── shared/       公共主题资源
├── analytics/    数据分析与 ECharts 大屏
├── database/     数据库结构与迁移说明
├── config/       可共享的业务规则示例
├── docs/         协议、规则和协作说明
├── scripts/      构建与验收脚本
└── .github/      CI、代码所有者与 PR 模板
```
