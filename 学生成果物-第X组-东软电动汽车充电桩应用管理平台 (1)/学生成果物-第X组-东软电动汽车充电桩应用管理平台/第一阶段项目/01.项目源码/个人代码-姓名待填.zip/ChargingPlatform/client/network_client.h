#ifndef NETWORK_CLIENT_H
#define NETWORK_CLIENT_H

#include <QJsonObject>
#include <QObject>
#include <QTcpSocket>

class NetworkClient : public QObject
{
    Q_OBJECT

public:
    explicit NetworkClient(QObject *parent = nullptr);

    void connectToServer(const QString &host, quint16 port);
    qint64 sendRequest(const QString &action, const QJsonObject &payload = QJsonObject());
    bool isConnected() const;
    void setSessionToken(const QString &token);
    void clearSessionToken();

signals:
    void connectedChanged(bool connected);
    void responseReceived(const QJsonObject &response);
    void networkError(const QString &message);

private slots:
    void readData();
    void socketConnected();
    void socketDisconnected();
    void socketError(QAbstractSocket::SocketError error);

private:
    QTcpSocket m_socket;
    QByteArray m_buffer;
    qint64 m_nextRequestId;
    QString m_sessionToken;
};

#endif // NETWORK_CLIENT_H
