#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "network_client.h"

#include <QDateTime>
#include <QHash>
#include <QJsonArray>
#include <QJsonObject>
#include <QMainWindow>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MemberSupportWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_connectButton_clicked();
    void on_loginButton_clicked();
    void on_logoutButton_clicked();
    void on_refreshStationsButton_clicked();
    void on_stationTable_itemSelectionChanged();
    void on_navigationButton_clicked();
    void on_startChargeButton_clicked();
    void on_stopChargeButton_clicked();
    void on_saveProfileButton_clicked();
    void on_chooseAvatarButton_clicked();
    void on_rechargeButton_clicked();
    void on_refreshOrdersButton_clicked();
    void handleConnectionChanged(bool connected);
    void handleNetworkError(const QString &message);
    void handleResponse(const QJsonObject &response);
    void updateChargingClock();
    void pollAccountStatus();

private:
    qint64 send(const QString &action, const QJsonObject &payload = QJsonObject());
    void refreshAfterLogin();
    void requestStations();
    void requestProfile();
    void requestActiveOrder();
    void requestOrders();
    void fillStationTable(const QJsonArray &stations);
    void fillChargerTable(const QJsonArray &chargers);
    void fillOrderTable(const QJsonArray &orders);
    void applyUserProfile(const QJsonObject &user);
    int selectedId(class QTableWidget *table) const;
    QJsonObject selectedStation() const;
    void setLoggedIn(bool loggedIn);

    Ui::MainWindow *ui;
    NetworkClient m_network;
    QHash<qint64, QString> m_pendingActions;
    QJsonArray m_stations;
    int m_userId;
    int m_activeOrderId;
    int m_lastAutoStopOrderId;
    QDateTime m_activeStartedAt;
    QTimer m_chargingTimer;
    QTimer m_statusTimer;
    QString m_avatarPath;
    QString m_avatarData;
    MemberSupportWidget *m_memberSupport;
};

#endif // MAINWINDOW_H
