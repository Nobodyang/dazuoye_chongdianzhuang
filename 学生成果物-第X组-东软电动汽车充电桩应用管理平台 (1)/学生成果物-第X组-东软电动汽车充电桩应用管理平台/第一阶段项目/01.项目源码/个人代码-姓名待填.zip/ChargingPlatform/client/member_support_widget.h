#ifndef MEMBER_SUPPORT_WIDGET_H
#define MEMBER_SUPPORT_WIDGET_H

#include <QHash>
#include <QJsonObject>
#include <QStringList>
#include <QWidget>

class NetworkClient;
class QComboBox;
class QJsonArray;
class QLineEdit;
class QPlainTextEdit;
class QTableWidget;

class MemberSupportWidget : public QWidget
{
public:
    explicit MemberSupportWidget(NetworkClient *network, QWidget *parent = nullptr);

    void setUserId(int userId);
    void clearUser();
    void refreshAll();

private:
    qint64 send(const QString &action, const QJsonObject &payload = QJsonObject());
    void handleResponse(const QJsonObject &response);
    void fillTable(QTableWidget *table,
                   const QJsonArray &rows,
                   const QStringList &keys,
                   const QStringList &headers);
    int selectedId(QTableWidget *table) const;
    void refreshMessages();

    NetworkClient *m_network;
    int m_userId;
    QHash<qint64, QString> m_pending;
    QTableWidget *m_tariffTable;
    QTableWidget *m_planTable;
    QTableWidget *m_cardTable;
    QComboBox *m_categoryCombo;
    QLineEdit *m_titleEdit;
    QPlainTextEdit *m_contentEdit;
    QTableWidget *m_feedbackTable;
    QTableWidget *m_messageTable;
    QPlainTextEdit *m_replyEdit;
};

#endif // MEMBER_SUPPORT_WIDGET_H
