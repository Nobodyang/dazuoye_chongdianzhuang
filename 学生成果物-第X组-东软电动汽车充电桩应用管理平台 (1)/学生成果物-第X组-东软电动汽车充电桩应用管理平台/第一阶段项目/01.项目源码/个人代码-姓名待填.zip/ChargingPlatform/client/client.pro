QT += core gui widgets network

CONFIG += c++14
TEMPLATE = app
TARGET = charging_client

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    member_support_widget.cpp \
    network_client.cpp

HEADERS += \
    mainwindow.h \
    member_support_widget.h \
    network_client.h

FORMS += mainwindow.ui

RESOURCES += ../shared/shared.qrc

DESTDIR = ../bin
OBJECTS_DIR = ../build/client/obj
MOC_DIR = ../build/client/moc
RCC_DIR = ../build/client/rcc
UI_DIR = ../build/client/ui
