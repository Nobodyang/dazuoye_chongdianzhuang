#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "member_support_widget.h"

#include <QDesktopServices>
#include <QBuffer>
#include <QFile>
#include <QFileDialog>
#include <QHeaderView>
#include <QImage>
#include <QImageReader>
#include <QMessageBox>
#include <QPixmap>
#include <QStringList>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QUrl>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_network(this)
    , m_userId(0)
    , m_activeOrderId(0)
    , m_lastAutoStopOrderId(0)
    , m_memberSupport(nullptr)
{
    ui->setupUi(this);
    m_memberSupport = new MemberSupportWidget(&m_network, ui->tabWidget);
    ui->tabWidget->addTab(m_memberSupport, "月卡 / 客服");
    setLoggedIn(false);
    ui->serverHostEdit->setText("127.0.0.1");
    ui->serverPortSpin->setValue(9999);
    ui->phoneEdit->setText("13800138000");
    ui->areaCombo->addItems({"全部区域", "海淀区", "西城区", "朝阳区"});
    ui->latitudeSpin->setValue(39.9570);
    ui->longitudeSpin->setValue(116.3270);
    ui->rechargeAmountSpin->setValue(50.0);

    const QList<QTableWidget *> tables = {
        ui->stationTable,
        ui->chargerTable,
        ui->orderTable
    };
    for (QTableWidget *table : tables) {
        table->setAlternatingRowColors(true);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->horizontalHeader()->setStretchLastSection(true);
        table->verticalHeader()->setVisible(false);
    }

    connect(&m_network, &NetworkClient::connectedChanged,
            this, &MainWindow::handleConnectionChanged);
    connect(&m_network, &NetworkClient::networkError,
            this, &MainWindow::handleNetworkError);
    connect(&m_network, &NetworkClient::responseReceived,
            this, &MainWindow::handleResponse);
    connect(&m_chargingTimer, &QTimer::timeout,
            this, &MainWindow::updateChargingClock);
    m_chargingTimer.start(1000);
    connect(&m_statusTimer, &QTimer::timeout,
            this, &MainWindow::pollAccountStatus);
    m_statusTimer.setInterval(3000);

    QTimer::singleShot(250, this, &MainWindow::on_connectButton_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setLoggedIn(bool loggedIn)
{
    ui->stackedWidget->setCurrentWidget(loggedIn ? ui->homePage : ui->loginPage);
    if (loggedIn) {
        m_statusTimer.start();
    } else {
        m_statusTimer.stop();
    }
    if (!loggedIn) {
        m_network.clearSessionToken();
        m_userId = 0;
        m_activeOrderId = 0;
        m_activeStartedAt = QDateTime();
        m_lastAutoStopOrderId = 0;
        if (m_memberSupport != nullptr) {
            m_memberSupport->clearUser();
        }
    }
}

void MainWindow::on_connectButton_clicked()
{
    ui->connectionLabel->setText("正在连接服务器...");
    m_network.connectToServer(ui->serverHostEdit->text(),
                              static_cast<quint16>(ui->serverPortSpin->value()));
}

void MainWindow::handleConnectionChanged(bool connected)
{
    ui->connectionLabel->setText(connected ? "服务器已连接" : "服务器未连接");
    ui->connectionLabel->setStyleSheet(connected
                                       ? "color:#16803c;font-weight:600;"
                                       : "color:#c43b3b;font-weight:600;");
    ui->loginButton->setEnabled(connected);
    statusBar()->showMessage(connected ? "网络连接成功" : "网络连接已断开", 3000);
}

void MainWindow::handleNetworkError(const QString &message)
{
    ui->connectionLabel->setText("连接错误：" + message);
    ui->connectionLabel->setStyleSheet("color:#c43b3b;");
    statusBar()->showMessage(message, 5000);
}

qint64 MainWindow::send(const QString &action, const QJsonObject &payload)
{
    const qint64 requestId = m_network.sendRequest(action, payload);
    if (requestId > 0) {
        m_pendingActions.insert(requestId, action);
    }
    return requestId;
}

void MainWindow::on_loginButton_clicked()
{
    const QString phone = ui->phoneEdit->text().trimmed();
    if (phone.size() != 11) {
        ui->loginHintLabel->setText("请输入 11 位手机号");
        return;
    }
    ui->loginHintLabel->setText("正在登录...");
    send("login_user", {{"phone", phone}});
}

void MainWindow::on_logoutButton_clicked()
{
    if (m_userId > 0 && m_network.isConnected()) {
        send("logout");
    }
    m_network.clearSessionToken();
    setLoggedIn(false);
    ui->loginHintLabel->setText("已退出登录");
}

void MainWindow::refreshAfterLogin()
{
    requestProfile();
    requestStations();
    requestActiveOrder();
    requestOrders();
}

void MainWindow::requestStations()
{
    send("list_stations",
         {{"area", ui->areaCombo->currentText()},
          {"latitude", ui->latitudeSpin->value()},
          {"longitude", ui->longitudeSpin->value()}});
}

void MainWindow::requestProfile()
{
    if (m_userId > 0) {
        send("profile", {{"userId", m_userId}});
    }
}

void MainWindow::requestActiveOrder()
{
    if (m_userId > 0) {
        send("active_order", {{"userId", m_userId}});
    }
}

void MainWindow::requestOrders()
{
    if (m_userId > 0) {
        send("list_orders", {{"userId", m_userId}});
    }
}

void MainWindow::pollAccountStatus()
{
    if (m_userId <= 0 || !m_network.isConnected()) {
        return;
    }
    requestActiveOrder();
    requestProfile();
}

void MainWindow::applyUserProfile(const QJsonObject &user)
{
    const int score = user.value("credit_score").toInt();
    const QString level = user.value("credit_level").toString();
    const double debt = user.value("debt").toDouble();
    const double creditLimit = user.value("credit_limit").toDouble();
    const double availableCredit = user.value("available_credit").toDouble();
    const double spendingPower = user.value("spending_power").toDouble();

    ui->welcomeLabel->setText("你好，" + user.value("nickname").toString());
    ui->phoneValueLabel->setText(user.value("phone").toString());
    ui->balanceValueLabel->setText(
                QString("¥ %1").arg(user.value("balance").toDouble(), 0, 'f', 2));
    ui->creditHeaderLabel->setText(QString("信誉：%1 分（%2）").arg(score).arg(level));
    ui->creditScoreValueLabel->setText(QString::number(score));
    ui->creditLevelValueLabel->setText(level);
    ui->creditLimitValueLabel->setText(
                QString("¥ %1（剩余 ¥%2）").arg(creditLimit, 0, 'f', 2).arg(availableCredit, 0, 'f', 2));
    ui->debtValueLabel->setText(QString("¥ %1").arg(debt, 0, 'f', 2));
    ui->nicknameEdit->setText(user.value("nickname").toString());
    m_avatarPath = user.value("avatar").toString();
    m_avatarData = user.value("avatar_data").toString();
    QImage avatarImage;
    if (!m_avatarData.isEmpty()
            && avatarImage.loadFromData(QByteArray::fromBase64(m_avatarData.toLatin1()))) {
        ui->avatarPathLabel->setFixedSize(72, 72);
        ui->avatarPathLabel->setPixmap(QPixmap::fromImage(avatarImage).scaled(
                                           68, 68, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        ui->avatarPathLabel->setToolTip(m_avatarPath);
    } else {
        ui->avatarPathLabel->setPixmap(QPixmap());
        ui->avatarPathLabel->setMinimumWidth(160);
        ui->avatarPathLabel->setText("默认头像");
    }

    const QJsonObject activeCard = user.value("active_monthly_card").toObject();
    if (!activeCard.isEmpty()) {
        ui->rechargeHint->setText(
                    QString("月卡：%1｜今日已用 %2/%3 等效分钟｜有效至 %4")
                    .arg(activeCard.value("name").toString())
                    .arg(activeCard.value("used_today").toInt())
                    .arg(activeCard.value("daily_minutes").toInt())
                    .arg(activeCard.value("valid_to").toString()));
    } else {
        ui->rechargeHint->setText("课程演示功能，不会发起真实支付。");
    }

    const QString warning = user.value("credit_warning").toString();
    ui->creditWarningLabel->setText(warning.isEmpty() ? "信誉状态正常；按时结算可增加信誉分。" : warning);
    const QString color = score <= 10 ? "#c43b3b" : (score <= 30 ? "#c47a00" : "#16803c");
    ui->creditHeaderLabel->setStyleSheet("font-weight:600;color:" + color + ";");
    ui->creditWarningLabel->setStyleSheet("font-weight:600;color:" + color + ";");
    if (m_activeOrderId <= 0) {
        ui->creditChargeLabel->setText(
                    QString("本次可用总额度：¥%1（余额 + 剩余信誉额度）")
                    .arg(spendingPower, 0, 'f', 2));
    }

    if (score == 0 || user.value("status").toString() == "banned") {
        QMessageBox::critical(this, tr("账号已封禁"),
                              tr("信誉分已降至 0，账号已封禁，请联系管理员。"));
        setLoggedIn(false);
    }
}

void MainWindow::on_refreshStationsButton_clicked()
{
    requestStations();
}

void MainWindow::fillStationTable(const QJsonArray &stations)
{
    m_stations = stations;
    ui->stationTable->clear();
    ui->stationTable->setColumnCount(6);
    ui->stationTable->setHorizontalHeaderLabels(
                {"电站名称", "区域", "价格(元/度)", "空闲/总数", "距离(km)", "地址"});
    ui->stationTable->setRowCount(stations.size());
    for (int rowIndex = 0; rowIndex < stations.size(); ++rowIndex) {
        const QJsonObject station = stations.at(rowIndex).toObject();
        const QStringList values = {
            station.value("name").toString(),
            station.value("area").toString(),
            QString::number(station.value("price").toDouble(), 'f', 2),
            QString("%1/%2").arg(station.value("idle_count").toInt())
            .arg(station.value("total_count").toInt()),
            QString::number(station.value("distance").toDouble(), 'f', 2),
            station.value("address").toString()
        };
        for (int columnIndex = 0; columnIndex < values.size(); ++columnIndex) {
            QTableWidgetItem *item = new QTableWidgetItem(values.at(columnIndex));
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, station.value("id").toInt());
            }
            ui->stationTable->setItem(rowIndex, columnIndex, item);
        }
    }
    ui->stationTable->resizeColumnsToContents();
    if (!stations.isEmpty()) {
        ui->stationTable->selectRow(0);
    }
}

void MainWindow::fillChargerTable(const QJsonArray &chargers)
{
    ui->chargerTable->clear();
    ui->chargerTable->setColumnCount(6);
    ui->chargerTable->setHorizontalHeaderLabels(
                {"电桩编号", "类型", "功率(kW)", "状态", "累计次数", "累计分钟"});
    ui->chargerTable->setRowCount(chargers.size());
    for (int rowIndex = 0; rowIndex < chargers.size(); ++rowIndex) {
        const QJsonObject charger = chargers.at(rowIndex).toObject();
        const QStringList values = {
            charger.value("code").toString(),
            charger.value("type").toString(),
            QString::number(charger.value("power").toDouble(), 'f', 0),
            charger.value("status").toString(),
            QString::number(charger.value("charge_count").toInt()),
            QString::number(charger.value("charge_minutes").toInt())
        };
        for (int columnIndex = 0; columnIndex < values.size(); ++columnIndex) {
            QTableWidgetItem *item = new QTableWidgetItem(values.at(columnIndex));
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, charger.value("id").toInt());
            }
            ui->chargerTable->setItem(rowIndex, columnIndex, item);
        }
    }
    ui->chargerTable->resizeColumnsToContents();
}

void MainWindow::fillOrderTable(const QJsonArray &orders)
{
    ui->orderTable->clear();
    ui->orderTable->setColumnCount(14);
    ui->orderTable->setHorizontalHeaderLabels(
                {"订单", "电站", "电桩", "状态", "开始时间", "结束时间", "分钟",
                 "电量", "原价", "月卡抵扣", "应付", "实付", "欠费", "自动停桩"});
    ui->orderTable->setRowCount(orders.size());
    const QStringList keys = {"id", "station", "code", "status", "started_at", "ended_at",
                              "minutes", "energy", "gross_fee", "card_discount", "fee",
                              "paid_amount", "outstanding", "auto_stopped"};
    for (int rowIndex = 0; rowIndex < orders.size(); ++rowIndex) {
        const QJsonObject order = orders.at(rowIndex).toObject();
        for (int columnIndex = 0; columnIndex < keys.size(); ++columnIndex) {
            const QString key = keys.at(columnIndex);
            QString text = order.value(key).toVariant().toString();
            if (key == "energy" || key == "gross_fee" || key == "card_discount"
                    || key == "fee" || key == "paid_amount" || key == "outstanding") {
                text = QString::number(order.value(key).toDouble(), 'f', 2);
            } else if (key == "status") {
                const QString status = order.value(key).toString();
                text = status == "charging" ? "充电中"
                     : status == "completed" ? "已完成"
                     : status == "unpaid" ? "待支付" : status;
            } else if (key == "auto_stopped") {
                text = order.value(key).toInt() == 1 ? "是" : "否";
            }
            ui->orderTable->setItem(rowIndex, columnIndex, new QTableWidgetItem(text));
        }
    }
    ui->orderTable->resizeColumnsToContents();
}

int MainWindow::selectedId(QTableWidget *table) const
{
    const QList<QTableWidgetItem *> items = table->selectedItems();
    if (items.isEmpty()) {
        return 0;
    }
    const int row = items.first()->row();
    return table->item(row, 0)->data(Qt::UserRole).toInt();
}

QJsonObject MainWindow::selectedStation() const
{
    const int stationId = selectedId(ui->stationTable);
    for (const QJsonValue &value : m_stations) {
        const QJsonObject station = value.toObject();
        if (station.value("id").toInt() == stationId) {
            return station;
        }
    }
    return QJsonObject();
}

void MainWindow::on_stationTable_itemSelectionChanged()
{
    const int stationId = selectedId(ui->stationTable);
    if (stationId > 0) {
        send("station_detail", {{"stationId", stationId}});
        const QJsonObject station = selectedStation();
        ui->selectedStationLabel->setText(
                    QString("当前电站：%1（%2 元/度）")
                    .arg(station.value("name").toString())
                    .arg(station.value("price").toDouble(), 0, 'f', 2));
    }
}

void MainWindow::on_navigationButton_clicked()
{
    const QJsonObject station = selectedStation();
    if (station.isEmpty()) {
        QMessageBox::information(this, tr("请选择电站"), tr("请先选择一个充电站。"));
        return;
    }
    const QString url = QString(
                "https://apis.map.qq.com/uri/v1/routeplan?type=drive&"
                "from=当前位置&fromcoord=%1,%2&to=%3&tocoord=%4,%5&policy=0&referer=ChargingPlatform")
            .arg(ui->latitudeSpin->value(), 0, 'f', 6)
            .arg(ui->longitudeSpin->value(), 0, 'f', 6)
            .arg(QString::fromUtf8(QUrl::toPercentEncoding(station.value("name").toString())))
            .arg(station.value("latitude").toDouble(), 0, 'f', 6)
            .arg(station.value("longitude").toDouble(), 0, 'f', 6);
    QDesktopServices::openUrl(QUrl(url));
}

void MainWindow::on_startChargeButton_clicked()
{
    if (m_activeOrderId > 0) {
        QMessageBox::warning(this, tr("存在未结算订单"), tr("您有未完成的充电订单，请先结算。"));
        return;
    }
    const int chargerId = selectedId(ui->chargerTable);
    if (chargerId <= 0) {
        QMessageBox::information(this, tr("请选择电桩"), tr("请先选择一个空闲电桩。"));
        return;
    }
    if (QMessageBox::question(this,
                              tr("开始充电"),
                              tr("确认使用所选电桩开始充电吗？")) != QMessageBox::Yes) {
        return;
    }
    send("start_charging", {{"userId", m_userId}, {"chargerId", chargerId}});
}

void MainWindow::on_stopChargeButton_clicked()
{
    if (m_activeOrderId <= 0) {
        QMessageBox::information(this, tr("没有充电任务"), tr("当前没有进行中的充电订单。"));
        return;
    }
    if (QMessageBox::question(this,
                              tr("结束充电"),
                              tr("确认结束充电并从钱包结算吗？")) != QMessageBox::Yes) {
        return;
    }
    send("stop_charging", {{"orderId", m_activeOrderId}});
}

void MainWindow::on_saveProfileButton_clicked()
{
    send("update_profile",
         {{"userId", m_userId},
          {"nickname", ui->nicknameEdit->text().trimmed()},
          {"avatarData", m_avatarData}});
}

void MainWindow::on_chooseAvatarButton_clicked()
{
    const QString path = QFileDialog::getOpenFileName(
                this, tr("选择头像"), QString(), tr("图片文件 (*.png *.jpg *.jpeg *.bmp)"));
    if (!path.isEmpty()) {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly) || file.size() > 2 * 1024 * 1024) {
            QMessageBox::warning(this, tr("头像无效"), tr("请选择不超过 2MB 的图片。"));
            return;
        }
        const QByteArray bytes = file.readAll();
        QBuffer buffer;
        buffer.setData(bytes);
        buffer.open(QIODevice::ReadOnly);
        QImageReader reader(&buffer);
        reader.setAutoTransform(true);
        const QSize imageSize = reader.size();
        if (!reader.canRead() || !imageSize.isValid() || imageSize.width() > 4096
                || imageSize.height() > 4096
                || static_cast<qint64>(imageSize.width()) * imageSize.height() > 16000000) {
            QMessageBox::warning(this, tr("头像无效"), tr("无法识别该图片。"));
            return;
        }
        const QImage image = reader.read();
        if (image.isNull()) {
            QMessageBox::warning(this, tr("头像无效"), tr("图片解码失败。"));
            return;
        }
        m_avatarPath = path;
        m_avatarData = QString::fromLatin1(bytes.toBase64());
        ui->avatarPathLabel->setFixedSize(72, 72);
        ui->avatarPathLabel->setText(QString());
        ui->avatarPathLabel->setPixmap(QPixmap::fromImage(image).scaled(
                                           68, 68, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        ui->avatarPathLabel->setToolTip(path);
    }
}

void MainWindow::on_rechargeButton_clicked()
{
    send("recharge",
         {{"userId", m_userId}, {"amount", ui->rechargeAmountSpin->value()}});
}

void MainWindow::on_refreshOrdersButton_clicked()
{
    requestOrders();
}

void MainWindow::handleResponse(const QJsonObject &response)
{
    const qint64 requestId = response.value("requestId").toVariant().toLongLong();
    const QString action = m_pendingActions.take(requestId);
    const bool ok = response.value("ok").toBool();
    const QString message = response.value("message").toString();

    if (!ok) {
        if (message.contains("登录状态已失效")) {
            m_network.clearSessionToken();
            setLoggedIn(false);
            ui->loginHintLabel->setText(message);
            return;
        }
        if (action == "login_user") {
            ui->loginHintLabel->setText(message);
        } else {
            QMessageBox::warning(this, tr("操作失败"), message);
        }
        return;
    }

    if (action == "login_user") {
        const QJsonObject user = response.value("data").toObject();
        m_network.setSessionToken(user.value("sessionToken").toString());
        m_userId = user.value("id").toInt();
        m_memberSupport->setUserId(m_userId);
        setLoggedIn(true);
        applyUserProfile(user);
        refreshAfterLogin();
    } else if (action == "list_stations") {
        fillStationTable(response.value("data").toArray());
        statusBar()->showMessage(QString("已找到 %1 个充电站").arg(m_stations.size()), 3000);
    } else if (action == "station_detail") {
        fillChargerTable(response.value("data").toArray());
    } else if (action == "profile"
               || action == "update_profile"
               || action == "recharge") {
        const QJsonObject user = response.value("data").toObject();
        applyUserProfile(user);
        if (action != "profile") {
            QMessageBox::information(this, tr("操作成功"), message);
        }
    } else if (action == "active_order") {
        const QJsonObject data = response.value("data").toObject();
        const bool active = data.value("active").toBool();
        if (!active) {
            m_activeOrderId = 0;
            m_activeStartedAt = QDateTime();
            ui->chargeStatusLabel->setText("当前没有进行中的充电订单");
            ui->stopChargeButton->setEnabled(false);
            ui->startChargeButton->setEnabled(true);
            const int autoStopOrderId = data.value("auto_stop_order_id").toInt();
            if (autoStopOrderId > 0 && autoStopOrderId != m_lastAutoStopOrderId) {
                m_lastAutoStopOrderId = autoStopOrderId;
                QMessageBox::warning(this, tr("系统自动停桩"), data.value("notice").toString());
                requestProfile();
                requestStations();
                requestOrders();
            }
        } else {
            const QJsonObject order = data.value("order").toObject();
            m_activeOrderId = order.value("id").toInt();
            m_activeStartedAt = QDateTime::fromString(order.value("started_at").toString(), Qt::ISODate);
            ui->chargeStatusLabel->setText(
                        QString("充电中：%1 / %2")
                        .arg(order.value("station_name").toString(), order.value("code").toString()));
            ui->creditChargeLabel->setText(
                        QString("原价 ¥%1｜月卡抵扣 ¥%2｜预计应付 ¥%3｜额度剩余 ¥%4")
                        .arg(order.value("gross_estimated_fee").toDouble(), 0, 'f', 2)
                        .arg(order.value("card_discount").toDouble(), 0, 'f', 2)
                        .arg(order.value("estimated_fee").toDouble(), 0, 'f', 2)
                        .arg(order.value("remaining_budget").toDouble(), 0, 'f', 2));
            ui->stopChargeButton->setEnabled(true);
            ui->startChargeButton->setEnabled(false);
            ui->tabWidget->setCurrentWidget(ui->chargeTab);
        }
        updateChargingClock();
    } else if (action == "start_charging") {
        const QJsonObject data = response.value("data").toObject();
        m_activeOrderId = data.value("orderId").toInt();
        m_activeStartedAt = QDateTime::fromString(data.value("startedAt").toString(), Qt::ISODate);
        QMessageBox::information(this, tr("充电开始"), message);
        requestActiveOrder();
        requestStations();
        requestOrders();
    } else if (action == "stop_charging") {
        const QJsonObject data = response.value("data").toObject();
        QMessageBox::information(
                    this,
                    tr("充电已停止"),
                    QString("%1\n充电 %2 分钟，电量 %3 kWh\n原价 ¥%4，月卡抵扣 ¥%5，应付 ¥%6\n实付 ¥%7，欠费 ¥%8")
                    .arg(message)
                    .arg(data.value("minutes").toInt())
                    .arg(data.value("energy").toDouble(), 0, 'f', 2)
                    .arg(data.value("grossFee").toDouble(), 0, 'f', 2)
                    .arg(data.value("cardDiscount").toDouble(), 0, 'f', 2)
                    .arg(data.value("fee").toDouble(), 0, 'f', 2)
                    .arg(data.value("paidAmount").toDouble(), 0, 'f', 2)
                    .arg(data.value("outstanding").toDouble(), 0, 'f', 2));
        m_activeOrderId = 0;
        m_activeStartedAt = QDateTime();
        requestActiveOrder();
        requestProfile();
        requestStations();
        requestOrders();
    } else if (action == "list_orders") {
        fillOrderTable(response.value("data").toArray());
    }
}

void MainWindow::updateChargingClock()
{
    if (m_activeOrderId <= 0 || !m_activeStartedAt.isValid()) {
        ui->elapsedValueLabel->setText("--:--:--");
        return;
    }
    const qint64 seconds = qMax<qint64>(0, m_activeStartedAt.secsTo(QDateTime::currentDateTime()));
    ui->elapsedValueLabel->setText(
                QString("%1:%2:%3")
                .arg(seconds / 3600, 2, 10, QChar('0'))
                .arg((seconds % 3600) / 60, 2, 10, QChar('0'))
                .arg(seconds % 60, 2, 10, QChar('0')));
}
