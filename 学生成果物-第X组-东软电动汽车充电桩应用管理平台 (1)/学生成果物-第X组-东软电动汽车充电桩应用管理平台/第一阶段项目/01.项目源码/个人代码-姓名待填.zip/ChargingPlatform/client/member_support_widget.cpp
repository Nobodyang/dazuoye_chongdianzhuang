#include "member_support_widget.h"

#include "network_client.h"

#include <QComboBox>
#include <QFormLayout>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QJsonArray>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSplitter>
#include <QTabWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>

MemberSupportWidget::MemberSupportWidget(NetworkClient *network, QWidget *parent)
    : QWidget(parent)
    , m_network(network)
    , m_userId(0)
    , m_tariffTable(new QTableWidget(this))
    , m_planTable(new QTableWidget(this))
    , m_cardTable(new QTableWidget(this))
    , m_categoryCombo(new QComboBox(this))
    , m_titleEdit(new QLineEdit(this))
    , m_contentEdit(new QPlainTextEdit(this))
    , m_feedbackTable(new QTableWidget(this))
    , m_messageTable(new QTableWidget(this))
    , m_replyEdit(new QPlainTextEdit(this))
{
    QVBoxLayout *root = new QVBoxLayout(this);
    QTabWidget *tabs = new QTabWidget(this);
    root->addWidget(tabs);

    QWidget *cardPage = new QWidget(tabs);
    QVBoxLayout *cardLayout = new QVBoxLayout(cardPage);
    cardLayout->addWidget(new QLabel("分时电价：站点基础价 × 时段倍率；高峰期月卡分钟按 2 倍消耗。", cardPage));
    cardLayout->addWidget(m_tariffTable);
    cardLayout->addWidget(new QLabel("可购月卡（只能用钱包余额购买）", cardPage));
    cardLayout->addWidget(m_planTable);
    QHBoxLayout *cardTools = new QHBoxLayout;
    QPushButton *buyButton = new QPushButton("购买所选月卡", cardPage);
    QPushButton *cardRefresh = new QPushButton("刷新", cardPage);
    cardTools->addStretch();
    cardTools->addWidget(buyButton);
    cardTools->addWidget(cardRefresh);
    cardLayout->addLayout(cardTools);
    cardLayout->addWidget(new QLabel("我的月卡（每日剩余时长不会跨天累计）", cardPage));
    cardLayout->addWidget(m_cardTable);
    tabs->addTab(cardPage, "分时计费与月卡");

    QWidget *feedbackPage = new QWidget(tabs);
    QVBoxLayout *feedbackLayout = new QVBoxLayout(feedbackPage);
    QFormLayout *feedbackForm = new QFormLayout;
    m_categoryCombo->addItems({"充电异常", "计费问题", "月卡问题", "账号问题", "其他"});
    feedbackForm->addRow("分类", m_categoryCombo);
    feedbackForm->addRow("标题", m_titleEdit);
    m_contentEdit->setPlaceholderText("请描述问题、发生时间、电站或订单编号（最多 2000 字）");
    m_contentEdit->setMaximumHeight(100);
    feedbackForm->addRow("问题描述", m_contentEdit);
    feedbackLayout->addLayout(feedbackForm);
    QPushButton *submitButton = new QPushButton("提交客服反馈", feedbackPage);
    feedbackLayout->addWidget(submitButton, 0, Qt::AlignRight);
    QSplitter *feedbackSplitter = new QSplitter(Qt::Vertical, feedbackPage);
    feedbackSplitter->addWidget(m_feedbackTable);
    feedbackSplitter->addWidget(m_messageTable);
    feedbackLayout->addWidget(feedbackSplitter, 1);
    QHBoxLayout *replyLayout = new QHBoxLayout;
    m_replyEdit->setPlaceholderText("对所选反馈补充说明");
    m_replyEdit->setMaximumHeight(70);
    QPushButton *replyButton = new QPushButton("发送补充", feedbackPage);
    QPushButton *feedbackRefresh = new QPushButton("刷新", feedbackPage);
    replyLayout->addWidget(m_replyEdit, 1);
    replyLayout->addWidget(replyButton);
    replyLayout->addWidget(feedbackRefresh);
    feedbackLayout->addLayout(replyLayout);
    tabs->addTab(feedbackPage, "客服反馈");

    for (QTableWidget *table : {m_tariffTable, m_planTable, m_cardTable,
                                m_feedbackTable, m_messageTable}) {
        table->setAlternatingRowColors(true);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->horizontalHeader()->setStretchLastSection(true);
        table->verticalHeader()->setVisible(false);
    }

    connect(m_network, &NetworkClient::responseReceived,
            this, &MemberSupportWidget::handleResponse);
    connect(cardRefresh, &QPushButton::clicked, this, &MemberSupportWidget::refreshAll);
    connect(feedbackRefresh, &QPushButton::clicked, this, &MemberSupportWidget::refreshAll);
    connect(m_feedbackTable, &QTableWidget::itemSelectionChanged,
            this, &MemberSupportWidget::refreshMessages);
    connect(buyButton, &QPushButton::clicked, this, [this]() {
        const int planId = selectedId(m_planTable);
        if (planId <= 0) {
            QMessageBox::information(this, "购买月卡", "请先选择一个月卡套餐。");
            return;
        }
        if (QMessageBox::question(this, "购买月卡", "确认使用钱包余额购买所选月卡吗？")
                == QMessageBox::Yes) {
            send("buy_monthly_card", {{"userId", m_userId}, {"planId", planId}});
        }
    });
    connect(submitButton, &QPushButton::clicked, this, [this]() {
        send("create_feedback", {{"userId", m_userId},
                                  {"category", m_categoryCombo->currentText()},
                                  {"title", m_titleEdit->text().trimmed()},
                                  {"content", m_contentEdit->toPlainText().trimmed()}});
    });
    connect(replyButton, &QPushButton::clicked, this, [this]() {
        const int feedbackId = selectedId(m_feedbackTable);
        if (feedbackId <= 0 || m_replyEdit->toPlainText().trimmed().isEmpty()) {
            QMessageBox::information(this, "补充反馈", "请先选择反馈并输入内容。");
            return;
        }
        send("reply_feedback", {{"userId", m_userId}, {"feedbackId", feedbackId},
                                 {"content", m_replyEdit->toPlainText().trimmed()}});
    });
}

qint64 MemberSupportWidget::send(const QString &action, const QJsonObject &payload)
{
    if (m_userId <= 0 && action != "tariffs" && action != "monthly_card_plans") {
        return -1;
    }
    const qint64 requestId = m_network->sendRequest(action, payload);
    if (requestId > 0) {
        m_pending.insert(requestId, action);
    }
    return requestId;
}

void MemberSupportWidget::setUserId(int userId)
{
    m_userId = userId;
    refreshAll();
}

void MemberSupportWidget::clearUser()
{
    m_userId = 0;
    m_pending.clear();
    for (QTableWidget *table : {m_cardTable, m_feedbackTable, m_messageTable}) {
        table->clear();
        table->setRowCount(0);
    }
}

void MemberSupportWidget::refreshAll()
{
    if (!m_network->isConnected()) {
        return;
    }
    send("tariffs");
    send("monthly_card_plans");
    if (m_userId > 0) {
        send("my_monthly_cards", {{"userId", m_userId}});
        send("my_feedback", {{"userId", m_userId}});
    }
}

void MemberSupportWidget::fillTable(QTableWidget *table,
                                    const QJsonArray &rows,
                                    const QStringList &keys,
                                    const QStringList &headers)
{
    table->clear();
    table->setColumnCount(keys.size());
    table->setHorizontalHeaderLabels(headers);
    table->setRowCount(rows.size());
    for (int rowIndex = 0; rowIndex < rows.size(); ++rowIndex) {
        const QJsonObject row = rows.at(rowIndex).toObject();
        for (int columnIndex = 0; columnIndex < keys.size(); ++columnIndex) {
            const QString key = keys.at(columnIndex);
            QString text = row.value(key).toVariant().toString();
            if (key == "price") {
                text = QString::number(row.value(key).toDouble(), 'f', 2);
            }
            QTableWidgetItem *item = new QTableWidgetItem(text);
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, row.value("id").toInt());
            }
            table->setItem(rowIndex, columnIndex, item);
        }
    }
    table->resizeColumnsToContents();
}

int MemberSupportWidget::selectedId(QTableWidget *table) const
{
    const int row = table->currentRow();
    return row >= 0 && table->item(row, 0)
            ? table->item(row, 0)->data(Qt::UserRole).toInt() : 0;
}

void MemberSupportWidget::refreshMessages()
{
    const int feedbackId = selectedId(m_feedbackTable);
    if (feedbackId > 0) {
        send("feedback_messages", {{"userId", m_userId}, {"feedbackId", feedbackId}});
    }
}

void MemberSupportWidget::handleResponse(const QJsonObject &response)
{
    const qint64 requestId = response.value("requestId").toVariant().toLongLong();
    const QString action = m_pending.take(requestId);
    if (action.isEmpty()) {
        return;
    }
    if (!response.value("ok").toBool()) {
        QMessageBox::warning(this, "操作失败", response.value("message").toString());
        return;
    }
    const QJsonValue data = response.value("data");
    if (action == "tariffs") {
        fillTable(m_tariffTable, data.toArray(),
                  {"id", "name", "start_minute", "end_minute", "multiplier_percent", "card_multiplier"},
                  {"ID", "时段", "开始分钟", "结束分钟", "电价倍率(%)", "月卡倍率"});
    } else if (action == "monthly_card_plans") {
        fillTable(m_planTable, data.toArray(),
                  {"id", "name", "price", "daily_minutes", "valid_days", "charger_type"},
                  {"ID", "套餐", "价格", "每日分钟", "天数", "适用电桩"});
    } else if (action == "my_monthly_cards") {
        fillTable(m_cardTable, data.toArray(),
                  {"id", "name", "charger_type", "valid_from", "valid_to", "used_today", "remaining_today", "status"},
                  {"ID", "套餐", "适用电桩", "生效日", "到期日", "今日已用", "今日剩余", "状态"});
    } else if (action == "my_feedback") {
        fillTable(m_feedbackTable, data.toArray(),
                  {"id", "category", "title", "status", "updated_at", "latest_message"},
                  {"ID", "分类", "标题", "状态", "更新时间", "最新消息"});
    } else if (action == "feedback_messages") {
        fillTable(m_messageTable, data.toObject().value("messages").toArray(),
                  {"id", "sender_role", "content", "created_at"},
                  {"ID", "发送方", "内容", "时间"});
    } else if (action == "buy_monthly_card") {
        QMessageBox::information(this, "购买成功", response.value("message").toString());
        refreshAll();
    } else if (action == "create_feedback") {
        QMessageBox::information(this, "提交成功", response.value("message").toString());
        m_titleEdit->clear();
        m_contentEdit->clear();
        refreshAll();
    } else if (action == "reply_feedback") {
        QMessageBox::information(this, "回复成功", response.value("message").toString());
        m_replyEdit->clear();
        refreshAll();
    }
}
