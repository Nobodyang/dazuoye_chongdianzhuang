# 数据库说明

数据库由 `DatabaseManager::open()` 自动创建和迁移；不要手工对正在运行的正式库执行结构脚本。

V1.2 迁移会：

1. 新增整数金额列并从旧 REAL 列回填。
2. 把已有管理员明文密码转换为 PBKDF2-SHA256 随机盐哈希，并清空明文字段。
3. 清理历史重复活动订单，按用户和电桩各保留最早一条，再建立两个部分唯一索引。
4. 建立会话、幂等键、峰谷规则、月卡、客服、审计和信誉事件表。
5. 为旧分析程序建立整数金额到 REAL 兼容列的同步触发器。

迁移前请停止客户端并备份数据库及同级 `avatars/` 目录：

```bash
cp data/charging_platform.db data/charging_platform.before-v12.db
cp -a data/avatars data/avatars.before-v12 2>/dev/null || true
```

服务端成功启动后，可在管理员“客服 / 审计 / 计费”页确认审计日志和业务规则。

只读排查可使用以下视图：`v_user_accounts`、`v_order_settlements`、`v_monthly_card_usage`、`v_feedback_overview`。例如：

```bash
sqlite3 data/charging_platform.db ".headers on" ".mode column" \
  "SELECT * FROM v_order_settlements ORDER BY id DESC LIMIT 10;"
```
