import sys
import sqlite3
import tempfile
import unittest
from pathlib import Path
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'analytics'))
from watch_dashboard import sample
from generate_dashboard import create_demo_database
from forecast_pipeline import load_series

class SamplingTests(unittest.TestCase):
    def test_full_hour_duplicate_and_offline(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'test.db'
            with sqlite3.connect(path) as c:
                c.executescript("CREATE TABLE stations(id INTEGER); INSERT INTO stations VALUES(1);"
                  "CREATE TABLE chargers(station_id INTEGER,status TEXT,power REAL);"
                  "INSERT INTO chargers VALUES(1,'in_use',100);"
                  "CREATE TABLE hourly_load(station_id,timestamp,load_kw,available_count,weather,is_holiday);"
                  "CREATE TABLE server_heartbeat(id INTEGER PRIMARY KEY,updated_at TEXT);")
            start=datetime(2026,9,7,10,tzinfo=ZoneInfo('Asia/Shanghai'))
            for minute in range(61):
                now=start+timedelta(minutes=minute)
                with sqlite3.connect(path) as c:
                    c.execute('INSERT OR REPLACE INTO server_heartbeat VALUES(1,?)',(now.isoformat(),))
                sample(path,now)
                sample(path,now)
            with sqlite3.connect(path) as c:
                self.assertEqual(c.execute('SELECT COUNT(*),MAX(load_kw) FROM hourly_load').fetchone(),(1,85.0))
                before=c.execute('SELECT COUNT(*) FROM operational_load_samples').fetchone()
            sample(path,start+timedelta(hours=4))
            with sqlite3.connect(path) as c:
                self.assertEqual(before,c.execute('SELECT COUNT(*) FROM operational_load_samples').fetchone())

    def test_gap_uses_old_complete_segment(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'test.db'
            create_demo_database(path)
            with sqlite3.connect(path) as c:
                old=load_series(c)[0][-1]
                for sid in range(1,5):
                    c.execute('INSERT INTO hourly_load(station_id,timestamp,load_kw) VALUES(?,?,?)',
                              (sid,(old+timedelta(hours=5)).isoformat(),42))
                self.assertEqual(load_series(c,True)[0][-1],old)
                with self.assertRaises(ValueError):
                    load_series(c)

if __name__=='__main__':
    unittest.main()
