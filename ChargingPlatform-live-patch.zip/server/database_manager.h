#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include <QJsonArray>
#include <QJsonObject>
#include <QDateTime>
#include <QSqlDatabase>
#include <QString>
#include <QStringList>
#include <QVariantMap>

class DatabaseManager
{
public:
    DatabaseManager();
    ~DatabaseManager();

    bool open();
    bool updateHeartbeat();
    QString databasePath() const;
    QString lastError() const;

    bool validateAdmin(const QString &username, const QString &password);
    QJsonObject handleRequest(const QJsonObject &request, bool trustedAdmin = false);
    QStringList runCreditMaintenance();
    void writeRuntimeLog(const QString &message, const QString &level = "info");

private:
    bool createTables();
    bool migrateSchema();
    bool columnExists(const QString &table, const QString &column);
    bool addColumnIfMissing(const QString &table,
                            const QString &column,
                            const QString &definition);
    bool seedData();
    bool execute(const QString &sql);
    QJsonArray selectRows(const QString &sql, const QVariantMap &bindings = QVariantMap());
    QJsonObject selectOne(const QString &sql, const QVariantMap &bindings = QVariantMap());
    QJsonObject response(bool ok,
                         const QString &message,
                         const QJsonValue &data = QJsonValue()) const;
    QJsonObject userSnapshot(int userId);
    QJsonObject settleChargingOrder(int orderId,
                                    bool automaticallyStopped,
                                    int expectedUserId = 0,
                                    const QString &autoStopReason = QString());
    QJsonObject calculateBilling(int userId,
                                 const QString &chargerType,
                                 double powerKw,
                                 qint64 basePriceCents,
                                 const QDateTime &startedAt,
                                 int minutes,
                                 bool allowMonthlyCard,
                                 const QJsonArray &tariffSnapshot = QJsonArray());
    bool applyMonthlyCardUsage(int orderId, const QJsonArray &usageRows);
    bool applyPricingDetails(int orderId, const QJsonArray &pricingRows);
    bool hasUsableMonthlyCard(int userId, const QString &chargerType);
    QString createSession(const QString &role, int actorId);
    QJsonObject authenticate(const QString &token);
    QJsonObject findIdempotentResponse(const QString &role,
                                       int actorId,
                                       const QString &action,
                                       const QString &key);
    bool storeIdempotentResponse(const QString &role,
                                 int actorId,
                                 const QString &action,
                                 const QString &key,
                                 const QJsonObject &result);
    void writeAuditLog(const QString &role,
                       int actorId,
                       const QString &action,
                       const QJsonObject &request,
                       const QJsonObject &result);
    QString avatarAbsolutePath(const QString &storedPath) const;

    QJsonObject loginUser(const QJsonObject &request);
    QJsonObject loginAdmin(const QJsonObject &request);
    QJsonObject logout(const QJsonObject &request);
    QJsonObject listStations(const QJsonObject &request);
    QJsonObject stationDetail(const QJsonObject &request);
    QJsonObject profile(const QJsonObject &request);
    QJsonObject updateProfile(const QJsonObject &request);
    QJsonObject recharge(const QJsonObject &request);
    QJsonObject startCharging(const QJsonObject &request);
    QJsonObject stopCharging(const QJsonObject &request);
    QJsonObject activeOrder(const QJsonObject &request);
    QJsonObject listOrders(const QJsonObject &request);
    QJsonObject dashboard() const;
    QJsonObject listChargers(const QJsonObject &request) const;
    QJsonObject restartCharger(const QJsonObject &request);
    QJsonObject listAdminStations() const;
    QJsonObject addStation(const QJsonObject &request);
    QJsonObject listUsers(const QJsonObject &request) const;
    QJsonObject toggleUser(const QJsonObject &request);
    QJsonObject listAllOrders() const;
    QJsonObject listTariffs() const;
    QJsonObject listMonthlyCardPlans(const QJsonObject &request) const;
    QJsonObject listMyMonthlyCards(const QJsonObject &request) const;
    QJsonObject listAdminMonthlyCards() const;
    QJsonObject buyMonthlyCard(const QJsonObject &request);
    QJsonObject createFeedback(const QJsonObject &request);
    QJsonObject listMyFeedback(const QJsonObject &request) const;
    QJsonObject feedbackMessages(const QJsonObject &request, bool adminView) const;
    QJsonObject replyFeedback(const QJsonObject &request, bool adminReply);
    QJsonObject listAdminFeedback(const QJsonObject &request) const;
    QJsonObject updateFeedbackStatus(const QJsonObject &request);
    QJsonObject listAuditLogs(const QJsonObject &request) const;

    QString m_connectionName;
    QString m_databasePath;
    QString m_lastError;
    QSqlDatabase m_database;
};

#endif // DATABASE_MANAGER_H
