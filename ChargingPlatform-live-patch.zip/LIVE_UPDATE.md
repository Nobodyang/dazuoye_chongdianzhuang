# 实时采样与历史预测补丁

保留现有 .venv、models/itransformer.pt 和数据库，不需要重新安装或训练。关闭旧服务后将补丁解压到项目根目录覆盖同名源码，重新执行 bash scripts/build.sh。使用 CHARGING_DB_PATH 指向原来的 ChargingData-v130/charging_platform.db 启动新版服务。

新终端在项目根目录运行：

```bash
analytics/.venv/bin/python analytics/watch_dashboard.py --db "$HOME/ChargingData-v130/charging_platform.db" --online
```

再用另一个终端运行：

```bash
python3 -m http.server 8080 --bind 127.0.0.1 --directory analytics/dashboard
```

打开 http://127.0.0.1:8080 ，Ctrl+F5 刷新。watch_dashboard 需要持续运行，每分钟采样、生成 JSON；外部数据最多每15分钟请求一次。不要同时运行多个采样进程或另一个定时生成程序。Ctrl+C 停止。无需另外运行 generate_dashboard.py。

旧数据超过两小时会显示“历史预测”与截止时间，预测横轴保持原日期，不移动到今天。已有模型可直接加载。未来时间数据仍拒绝预测。遇到采样间断，会选取最近一段至少120小时的完整站点序列；新的连续记录积累足够后才切换。因此开机后不会立即恢复当前预测，旧断档不自动补零。

采样需同一数据库中的服务端心跳在60秒内有效。每个完整小时需要60个不同分钟样本才汇总；启动所在的不完整小时不发布。负荷按 in_use 桩额定功率×0.85估算，空闲数按状态统计，不是硬件遥测或电表读数。停机/暂停/调度延迟可能留下缺小时，宁缺勿伪造。旧 hourly_load 不修改；新增 operational_load_samples、operational_load_hours、server_heartbeat 表。分钟样本保留7天，小时记录持续保留。

当前仍可能混有旧版种子演示数据，不能据此宣称真实预测精度。天气/交通仅展示，尚未并入模型训练。服务端心跳表示进程仍处理事件，不代表 TCP 一定已监听；端口冲突仍需解决。

验证：原7项检查、数据库约束检查，以及新增采样重复执行/完整小时/失效心跳/断档历史回退测试已通过；JavaScript和Python语法检查通过。当前环境未完成Qt编译及PyTorch真实权重推理，需在虚拟机验收。
