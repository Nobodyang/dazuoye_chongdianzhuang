"""Sample operational load every minute; publish snapshots every minute.

Run alongside the Qt server. Load is an estimate from charger state/power,
not telemetry. Only sufficiently observed completed hours are published.
"""
import argparse
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3
import time
from zoneinfo import ZoneInfo
from generate_dashboard import build_dashboard_data

ZONE = ZoneInfo('Asia/Shanghai')


def sample(db, now=None):
    now = now or datetime.now(ZONE)
    minute = now.replace(second=0, microsecond=0)
    hour = minute.replace(minute=0)
    with sqlite3.connect(db.as_uri()+'?mode=rw', uri=True, timeout=10) as c:
        if not c.execute("SELECT 1 FROM sqlite_master WHERE name='server_heartbeat'").fetchone():
            return
        heartbeat = c.execute('SELECT updated_at FROM server_heartbeat WHERE id=1').fetchone()
        if not heartbeat:
            return
        age = (now-datetime.fromisoformat(heartbeat[0].replace('Z','+00:00'))).total_seconds()
        if age < 0 or age > 60:
            return
        c.execute('CREATE TABLE IF NOT EXISTS operational_load_samples '
                  '(station_id INTEGER, minute TEXT, hour TEXT, load_kw REAL, available INTEGER, '
                  'PRIMARY KEY(station_id,minute))')
        c.execute('CREATE TABLE IF NOT EXISTS operational_load_hours '
                  '(station_id INTEGER,hour TEXT,PRIMARY KEY(station_id,hour))')
        rows = c.execute("SELECT s.id, COALESCE(SUM(CASE WHEN ch.status='in_use' THEN ch.power*0.85 ELSE 0 END),0), "
                         "SUM(CASE WHEN ch.status='idle' THEN 1 ELSE 0 END) "
                         "FROM stations s LEFT JOIN chargers ch ON ch.station_id=s.id GROUP BY s.id").fetchall()
        for sid, load, available in rows:
            c.execute('INSERT OR IGNORE INTO operational_load_samples VALUES(?,?,?,?,?)',
                      (sid,minute.isoformat(),hour.isoformat(),load,available))
        # Never fill downtime with zeros; require all 60 distinct minute samples.
        complete = c.execute('SELECT station_id,hour,AVG(load_kw),AVG(available),COUNT(*) '
                             'FROM operational_load_samples WHERE hour<? GROUP BY station_id,hour HAVING COUNT(*)=60',
                             (hour.isoformat(),)).fetchall()
        for sid, stamp, load, available, count in complete:
            if c.execute('SELECT 1 FROM operational_load_hours WHERE station_id=? AND hour=?',(sid,stamp)).fetchone():
                continue
            # Keep legacy samples untouched, including those with nonzero minutes.
            exists = c.execute('SELECT 1 FROM hourly_load WHERE station_id=? AND substr(timestamp,1,13)=?',
                               (sid,stamp[:13])).fetchone()
            if not exists:
                c.execute('INSERT INTO hourly_load(station_id,timestamp,load_kw,available_count,weather,is_holiday) '
                          'VALUES(?,?,?,?,NULL,?)',
                          (sid,stamp,load,round(available),int(datetime.fromisoformat(stamp).weekday()>=5)))
            c.execute('INSERT INTO operational_load_hours VALUES(?,?)',(sid,stamp))
        c.execute('DELETE FROM operational_load_samples WHERE minute<?',
                  ((now-timedelta(days=7)).isoformat(),))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    parser.add_argument('--online', action='store_true')
    args = parser.parse_args()
    db = Path(args.db).resolve()
    if not db.is_file():
        parser.error('数据库不存在')
    root = Path(__file__).resolve().parent
    output = root/'dashboard/data.json'
    realtime, fetched = None, 0
    print('采样与网页更新已启动；Ctrl+C 停止。负荷为业务状态估算。', flush=True)
    while True:
        start = time.monotonic()
        try:
            sample(db)
            online = args.online and start-fetched >= 900
            with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True,timeout=10) as c:
                data = build_dashboard_data(c, root/'models/itransformer.pt', online)
            if online:
                realtime, fetched = data['realtime'], start
            elif realtime:
                data['realtime']['weather'] = realtime['weather']
                data['realtime']['traffic'] = realtime['traffic']
            data['loadSource'] = '业务状态估算；历史记录可能包含演示数据'
            temporary = output.with_suffix('.watch.tmp')
            temporary.write_text(json.dumps(data,ensure_ascii=False,allow_nan=False),encoding='utf-8')
            temporary.replace(output)
            print(data['generatedAt'], data['model']['status'], flush=True)
        except (OSError, sqlite3.Error, ValueError) as error:
            print('本轮失败：', error, flush=True)
        time.sleep(max(1,60-(time.monotonic()-start)))


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('已停止')
