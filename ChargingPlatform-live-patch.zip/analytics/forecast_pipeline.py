"""Train-only-on-past iTransformer pipeline; never fabricate a current prediction."""
import argparse
import json
import math
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ZONE = ZoneInfo('Asia/Shanghai')
LOOKBACK, HORIZON = 96, 24


def local_time(value):
    dt = datetime.fromisoformat(value)
    return dt.replace(tzinfo=ZONE) if dt.tzinfo is None else dt.astimezone(ZONE)


def load_series(connection, historical_fallback=False):
    """Demand a complete hourly panel; missing samples are not zero load."""
    rows = connection.execute('SELECT station_id,timestamp,load_kw FROM hourly_load ORDER BY timestamp').fetchall()
    ids = [r[0] for r in connection.execute('SELECT id FROM stations ORDER BY id')]
    panel = {}
    for sid, stamp, load in rows:
        # Older server samples include minutes/seconds; assign to their hour,
        # without shifting the day or fabricating missing hours.
        stamp = local_time(stamp).replace(minute=0, second=0, microsecond=0)
        if sid not in ids or load is None or not math.isfinite(load) or load < 0:
            raise ValueError('历史负荷含未知站点或无效值')
        if sid in panel.setdefault(stamp, {}):
            raise ValueError('历史负荷存在重复站点小时')
        panel[stamp][sid] = float(load)
    times = sorted(panel)
    segments, segment = [], []
    for stamp in times:
        if set(panel[stamp]) != set(ids):
            if not historical_fallback:
                raise ValueError('站点小时序列缺站')
            if segment:
                segments.append(segment)
            segment = []
            continue
        if segment and stamp-segment[-1] != timedelta(hours=1):
            if not historical_fallback:
                raise ValueError('站点小时序列不连续')
            segments.append(segment)
            segment = []
        segment.append(stamp)
    if segment:
        segments.append(segment)
    eligible = [part for part in segments if len(part) >= LOOKBACK + HORIZON]
    if not eligible:
        raise ValueError('至少需要120个连续小时的完整站点负荷')
    times = eligible[-1]
    # Calendar covariates are known in advance; weekends do not imply legal holidays.
    values = []
    for t in times:
        values.append([panel[t][sid] for sid in ids] + [
            math.sin(t.hour*math.tau/24), math.cos(t.hour*math.tau/24),
            math.sin(t.weekday()*math.tau/7), math.cos(t.weekday()*math.tau/7),
            float(t.weekday() >= 5)])
    return times, ids, values


def forecast(connection, checkpoint):
    import torch
    from itransformer_model import ITransformer
    times, ids, values = load_series(connection, historical_fallback=True)
    now = datetime.now(ZONE)
    if times[-1] > now:
        raise ValueError('数据时间晚于当前时间，请检查系统时钟')
    historical = now-times[-1] > timedelta(hours=2)
    saved = torch.load(checkpoint, map_location='cpu', weights_only=True)
    if saved['station_ids'] != ids or saved['schema'] != 1:
        raise ValueError('模型站点或特征版本不匹配，请重新训练')
    model = ITransformer()
    model.load_state_dict(saved['weights'])
    model.eval()
    with torch.no_grad():
        output = model(torch.tensor([values[-LOOKBACK:]], dtype=torch.float32))[0, :, :len(ids)]
    if not torch.isfinite(output).all():
        raise ValueError('模型输出非有限值')
    series = []
    for i, vector in enumerate(output.clamp_min(0).tolist()):
        stamp = times[-1] + timedelta(hours=i+1)
        series.append({'time': stamp.strftime('%m-%d %H:00'),
                       'loadKw': round(sum(vector), 1), 'available': None})
    return series, {'name':'iTransformer', 'status':'historical' if historical else 'ready', 'trainingRows':saved['training_rows'],
                    'validation':saved['validation'], 'trainedAt':saved['trained_at'],
                    'dataThrough':times[-1].isoformat(),
                    'features':['station load','hour cycle','weekday cycle','weekend'],
                    'externalInputs':'天气及交通暂仅展示；积累同时间轴历史后方可训练接入'}


def train(db, out, epochs=20):
    import torch
    from itransformer_model import ITransformer
    torch.manual_seed(42)
    torch.set_num_threads(2)
    with sqlite3.connect(f'{Path(db).resolve().as_uri()}?mode=ro', uri=True) as conn:
        times, ids, values = load_series(conn)
    # Entire validation target period is strictly after all training targets.
    split = int(len(times)*0.8)
    train_starts = list(range(LOOKBACK, split-HORIZON+1))
    val_starts = list(range(max(split, LOOKBACK), len(times)-HORIZON+1, HORIZON))
    if len(train_starts) < 48 or not val_starts:
        raise ValueError('训练与独立验证至少需要约9天连续小时数据，建议30天以上')
    tensor = torch.tensor(values, dtype=torch.float32)
    model = ITransformer()
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
    best, weights = float('inf'), None
    for epoch in range(epochs):
        model.train()
        shuffled = torch.randperm(len(train_starts)).tolist()
        for offset in range(0, len(shuffled), 32):
            starts = [train_starts[i] for i in shuffled[offset:offset+32]]
            x = torch.stack([tensor[t-LOOKBACK:t] for t in starts])
            y = torch.stack([tensor[t:t+HORIZON, :len(ids)] for t in starts])
            optimizer.zero_grad()
            loss = ((model(x)[:, :, :len(ids)]-y)**2).mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        model.eval()
        with torch.no_grad():
            x = torch.stack([tensor[t-LOOKBACK:t] for t in val_starts])
            y = torch.stack([tensor[t:t+HORIZON, :len(ids)] for t in val_starts])
            error = model(x)[:, :, :len(ids)]-y
            mse = error.square().mean().item()
            if math.isfinite(mse) and mse < best:
                best = mse
                weights = {k:v.detach().clone() for k,v in model.state_dict().items()}
                metrics = {'MAE_kW':error.abs().mean().item(), 'RMSE_kW':math.sqrt(mse),
                           'seasonal24_MAE_kW':(x[:,-24:,:len(ids)]-y).abs().mean().item(),
                           'validationWindows':len(val_starts)}
        print(f'epoch {epoch+1}/{epochs}: validation MSE={mse:.4f}')
    if weights is None:
        raise ValueError('未获得有效权重')
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    temporary = out.with_suffix('.tmp')
    torch.save({'schema':1, 'station_ids':ids, 'weights':weights,
                'trained_at':datetime.now(ZONE).isoformat(), 'training_rows':split*len(ids),
                'validation':metrics}, temporary)
    temporary.replace(out)
    print(json.dumps(metrics, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    parser.add_argument('--out', default=str(Path(__file__).parent/'models/itransformer.pt'))
    parser.add_argument('--epochs', type=int, default=20)
    args = parser.parse_args()
    if not 1 <= args.epochs <= 1000:
        parser.error('epochs must be 1..1000')
    train(args.db, args.out, args.epochs)
