const palette = ['#47a7ff', '#4ce4d3', '#f3bd5b', '#ec6d72'];
function chart(id) {
  const element = document.getElementById(id);
  return echarts.getInstanceByDom(element) || echarts.init(element);
}
window.addEventListener('resize', () => ['revenueChart','statusChart','forecastChart','stationChart'].forEach(id => {
  const instance = echarts.getInstanceByDom(document.getElementById(id));
  if (instance) instance.resize();
}));

function renderContext(value) {
  if (!value) return;
  const weather = value.weather, traffic = value.traffic, calendar = value.calendar;
  document.getElementById('weatherInfo').textContent = weather.current
    ? `天气：${weather.current.temperature_2m} °C，降水 ${weather.current.precipitation} mm；位置 ${weather.coordinates.join(', ')}；观测 ${weather.current.time}（Open-Meteo）`
    : `天气：${weather.status === "未请求" ? "暂无数据" : "暂不可用"}`;
  document.getElementById('trafficInfo').textContent = `交通：${traffic.description || "暂无数据"} ${traffic.fetchedAt || ''}`;
  document.getElementById('calendarTitle').textContent = `${calendar.year} 年 ${calendar.month} 月 · 北京时间`;
  const grid = document.getElementById('calendarDays');
  grid.replaceChildren();
  ['一','二','三','四','五','六','日', ...calendar.weeks.flat()].forEach((day, index) => {
    const cell = document.createElement('span');
    cell.textContent = day || '';
    if (index >= 7 && day === calendar.today) cell.classList.add('today');
    if (index % 7 >= 5) cell.classList.add('weekend');
    grid.append(cell);
  });
  document.getElementById('calendarNote').textContent = '周末以金色标示';
}

function currency(value) {
  return Number(value || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function baseOption() {
  return {
    animationDuration: 850,
    textStyle: { color: '#bcd3e6', fontFamily: 'Microsoft YaHei' },
    tooltip: { trigger: 'axis', backgroundColor: 'rgba(8,25,43,.96)', borderColor: '#2d6f9f', textStyle: { color: '#eaf5ff' } },
    grid: { left: 48, right: 22, top: 28, bottom: 38 },
    xAxis: { axisLine: { lineStyle: { color: '#35536b' } }, axisLabel: { color: '#86a5bd' } },
    yAxis: { splitLine: { lineStyle: { color: 'rgba(90,135,168,.16)' } }, axisLine: { show: false }, axisLabel: { color: '#86a5bd' } }
  };
}

function render(data) {
  document.getElementById('todayRevenue').textContent = currency(data.metrics.todayRevenue);
  document.getElementById('monthRevenue').textContent = currency(data.metrics.monthRevenue);
  document.getElementById('onlineRate').textContent = data.metrics.onlineRate.toFixed(1);
  document.getElementById('forecastPeak').textContent = (data.metrics.forecastPeak == null ? '--' : data.metrics.forecastPeak.toFixed(1));
  document.getElementById('generated').textContent = `数据生成于 ${data.generatedAt.replace('T', ' ')}`;
  const historical = data.model.status === 'historical';
  document.querySelector('.forecast h2').textContent = historical ? '历史时点后 24 小时负荷预测' : '未来 24 小时负荷预测';
  document.getElementById('forecastPeak').previousElementSibling.textContent = historical ? '历史预测峰值' : '未来峰值负荷';
  document.getElementById('modelInfo').textContent = `预测模型：${data.model.name} · ${historical ? '历史预测' : data.model.status === 'ready' ? '预测已更新' : '预测暂不可用'}`;
  document.getElementById('forecastNote').textContent = data.forecast.length
    ? `${historical ? '历史预测，仅供参考。' : ''}数据截止 ${data.model.dataThrough}；预测峰值 ${data.metrics.forecastPeakTime}。负荷为业务估算，历史可能含演示数据。`
    : '暂无可用预测';

  const revenue = chart('revenueChart');
  revenue.setOption({
    ...baseOption(),
    xAxis: { ...baseOption().xAxis, type: 'category', data: data.revenue.map(item => item.day.slice(5)), boundaryGap: false },
    yAxis: { ...baseOption().yAxis, type: 'value', name: '元' },
    series: [{ type: 'line', smooth: true, symbol: 'none', data: data.revenue.map(item => item.revenue), lineStyle: { width: 3, color: palette[0] }, areaStyle: { color: 'rgba(71,167,255,.18)' } }]
  });

  const statusNames = { idle: '空闲', in_use: '在用', fault: '故障' };
  const status = chart('statusChart');
  status.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 4, textStyle: { color: '#8ba7c1' } },
    series: [{ type: 'pie', radius: ['48%', '72%'], center: ['50%', '46%'], label: { color: '#dcefff', formatter: '{b}\n{d}%' }, itemStyle: { borderColor: '#0b1d30', borderWidth: 3 }, data: data.chargerStatus.map((item, index) => ({ name: statusNames[item.status] || item.status, value: item.count, itemStyle: { color: palette[index] } })) }]
  });

  const forecast = chart('forecastChart');
  forecast.setOption({
    ...baseOption(),
    xAxis: { ...baseOption().xAxis, type: 'category', data: data.forecast.map(item => item.time), boundaryGap: false, axisLabel: { color: '#86a5bd', interval: 5 } },
    yAxis: { ...baseOption().yAxis, type: 'value', name: 'kW' },
    series: [{ type: 'line', smooth: true, showSymbol: false, data: data.forecast.map(item => item.loadKw), lineStyle: { width: 3, color: palette[1] }, areaStyle: { color: 'rgba(76,228,211,.16)' }, markPoint: { symbolSize: 46, data: [{ type: 'max', name: '峰值' }] } }]
  });

  const station = chart('stationChart');
  station.setOption({
    ...baseOption(),
    grid: { left: 42, right: 20, top: 20, bottom: 62 },
    xAxis: { ...baseOption().xAxis, type: 'category', data: data.stationLoad.map(item => item.name.replace('充电站', '').replace('充电中心', '')), axisLabel: { color: '#86a5bd', interval: 0, rotate: 25 } },
    yAxis: { ...baseOption().yAxis, type: 'value', name: 'kW' },
    series: [{ type: 'bar', barWidth: '48%', data: data.stationLoad.map((item, index) => ({ value: item.avg_load, itemStyle: { color: palette[index % palette.length], borderRadius: [5, 5, 0, 0] } })) }]
  });

  const strip = document.getElementById('stationStrip');
  strip.replaceChildren();
  data.stations.forEach(item => {
    const article = document.createElement('article');
    article.textContent = item.name + ' · ' + item.area + ' · ¥' + item.price.toFixed(2) + '/度';
    strip.append(article);
  });
  renderContext(data.realtime);
}

function updateClock() {
  document.getElementById('clock').textContent = new Date().toLocaleString('zh-CN', { hour12: false, timeZone: 'Asia/Shanghai' });
}
setInterval(updateClock, 1000);
updateClock();

function refresh() {
fetch('data.json', {cache:'no-store'})
  .then(response => {
    if (!response.ok) throw new Error('data.json 加载失败');
    return response.json();
  })
  .then(render)
  .catch(error => {
    document.getElementById('generated').textContent = '数据暂不可用';
  });

}
refresh();
setInterval(refresh, 60000);
