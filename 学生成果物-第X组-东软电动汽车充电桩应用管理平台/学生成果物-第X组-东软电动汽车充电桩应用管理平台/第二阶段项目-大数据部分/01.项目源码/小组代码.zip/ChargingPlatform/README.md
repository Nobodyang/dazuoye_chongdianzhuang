# 东软电动汽车充电桩应用管理平台

本工程包含 Qt 用户端、Qt 管理服务器、SQLite 数据库、TCP 多线程通信，以及第二阶段的数据分析与 ECharts 可视化大屏。

## 1. 环境

- Ubuntu 22.04 或更高版本
- Qt Creator 6.2 或更高版本
- Qt 5.15/Qt 6.x（Widgets、Network、Sql、Charts 模块）
- Python 3（仅用于第二阶段数据分析）

Ubuntu 22.04 可执行：

```bash
sudo apt update
sudo apt install build-essential qtcreator qtbase5-dev qt5-qmake \
  libqt5sql5-sqlite libqt5charts5-dev python3
```

## 2. 编译和运行第一阶段

1. 用 Qt Creator 打开 `ChargingPlatform.pro`。
2. 选择 Desktop Kit，执行“构建项目”。
3. 先运行 `charging_server`，服务器默认监听 `9999` 端口。
4. 再运行 `charging_client`，服务器地址保持 `127.0.0.1`。

演示账号：

- 管理员：`admin` / `123456`
- 用户：任意合法 11 位手机号；首次登录自动注册

SQLite 数据库首次运行时自动创建，默认位置为：

```text
~/.local/share/NeusoftTraining/ChargingServer/charging_platform.db
```

如果希望分析程序直接定位数据库，可以在运行服务端前设置：

```bash
export CHARGING_DB_PATH="$PWD/data/charging_platform.db"
```

## 3. 运行第二阶段

先确保服务端至少运行过一次，然后执行：

```bash
cd analytics
python3 generate_dashboard.py --db ../data/charging_platform.db
python3 -m http.server 8080 --directory dashboard
```

浏览器访问 `http://127.0.0.1:8080`。若数据库不在上述路径，使用 `--db` 指定实际文件。

## 4. 主要演示流程

1. 服务端使用管理员账号登录，查看仪表盘和服务器日志。
2. 客户端用手机号登录，选择区域并刷新附近电站。
3. 选择电站和空闲电桩，开始充电；随后结束充电并结算。
4. 回到服务端刷新，查看订单、营收和电桩状态变化。
5. 在用户管理页冻结/解冻用户，在充电桩管理页执行远程重启。
6. 运行分析脚本，打开大屏查看 24 小时负荷预测。

## 5. 工程结构

```text
ChargingPlatform/
├── client/       Qt 用户端
├── server/       Qt 管理服务器、SQLite 数据层、TCP 工作线程
├── shared/       公共主题资源
├── analytics/    数据聚合、线性回归预测、ECharts 大屏
├── data/         可选数据库目录
└── scripts/      构建与验收脚本
```

## 6. 设计说明

- 所有数据库语句均使用预处理和参数绑定，减少 SQL 注入风险。
- TCP 使用一行一个 JSON 对象的协议，每个请求包含 `requestId`，可关联响应。
- 网络服务对象运行在独立 `QThread` 事件循环中，数据库和 UI 保持在主线程；跨线程信号槽使用队列连接。
- 服务端执行订单创建、结算和电桩状态变化时使用事务，避免出现半完成数据。
- 导航功能通过系统浏览器打开腾讯地图路线页面，不保存地图密钥。

