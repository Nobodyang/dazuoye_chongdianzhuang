#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDesktopServices>
#include <QFileDialog>
#include <QHeaderView>
#include <QMessageBox>
#include <QStringList>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QUrl>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_network(this)
    , m_userId(0)
    , m_activeOrderId(0)
{
    ui->setupUi(this);
    setLoggedIn(false);
    ui->serverHostEdit->setText("127.0.0.1");
    ui->serverPortSpin->setValue(9999);
    ui->phoneEdit->setText("13800138000");
    ui->areaCombo->addItems({"全部区域", "海淀区", "西城区", "朝阳区"});
    ui->latitudeSpin->setValue(39.9570);
    ui->longitudeSpin->setValue(116.3270);
    ui->rechargeAmountSpin->setValue(50.0);

    const QList<QTableWidget *> tables = {
        ui->stationTable,
        ui->chargerTable,
        ui->orderTable
    };
    for (QTableWidget *table : tables) {
        table->setAlternatingRowColors(true);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->horizontalHeader()->setStretchLastSection(true);
        table->verticalHeader()->setVisible(false);
    }

    connect(&m_network, &NetworkClient::connectedChanged,
            this, &MainWindow::handleConnectionChanged);
    connect(&m_network, &NetworkClient::networkError,
            this, &MainWindow::handleNetworkError);
    connect(&m_network, &NetworkClient::responseReceived,
            this, &MainWindow::handleResponse);
    connect(&m_chargingTimer, &QTimer::timeout,
            this, &MainWindow::updateChargingClock);
    m_chargingTimer.start(1000);

    QTimer::singleShot(250, this, &MainWindow::on_connectButton_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setLoggedIn(bool loggedIn)
{
    ui->stackedWidget->setCurrentWidget(loggedIn ? ui->homePage : ui->loginPage);
    if (!loggedIn) {
        m_userId = 0;
        m_activeOrderId = 0;
        m_activeStartedAt = QDateTime();
    }
}

void MainWindow::on_connectButton_clicked()
{
    ui->connectionLabel->setText("正在连接服务器...");
    m_network.connectToServer(ui->serverHostEdit->text(),
                              static_cast<quint16>(ui->serverPortSpin->value()));
}

void MainWindow::handleConnectionChanged(bool connected)
{
    ui->connectionLabel->setText(connected ? "服务器已连接" : "服务器未连接");
    ui->connectionLabel->setStyleSheet(connected
                                       ? "color:#16803c;font-weight:600;"
                                       : "color:#c43b3b;font-weight:600;");
    ui->loginButton->setEnabled(connected);
    statusBar()->showMessage(connected ? "网络连接成功" : "网络连接已断开", 3000);
}

void MainWindow::handleNetworkError(const QString &message)
{
    ui->connectionLabel->setText("连接错误：" + message);
    ui->connectionLabel->setStyleSheet("color:#c43b3b;");
    statusBar()->showMessage(message, 5000);
}

qint64 MainWindow::send(const QString &action, const QJsonObject &payload)
{
    const qint64 requestId = m_network.sendRequest(action, payload);
    if (requestId > 0) {
        m_pendingActions.insert(requestId, action);
    }
    return requestId;
}

void MainWindow::on_loginButton_clicked()
{
    const QString phone = ui->phoneEdit->text().trimmed();
    if (phone.size() != 11) {
        ui->loginHintLabel->setText("请输入 11 位手机号");
        return;
    }
    ui->loginHintLabel->setText("正在登录...");
    send("login_user", {{"phone", phone}});
}

void MainWindow::on_logoutButton_clicked()
{
    setLoggedIn(false);
    ui->loginHintLabel->setText("已退出登录");
}

void MainWindow::refreshAfterLogin()
{
    requestProfile();
    requestStations();
    requestActiveOrder();
    requestOrders();
}

void MainWindow::requestStations()
{
    send("list_stations",
         {{"area", ui->areaCombo->currentText()},
          {"latitude", ui->latitudeSpin->value()},
          {"longitude", ui->longitudeSpin->value()}});
}

void MainWindow::requestProfile()
{
    if (m_userId > 0) {
        send("profile", {{"userId", m_userId}});
    }
}

void MainWindow::requestActiveOrder()
{
    if (m_userId > 0) {
        send("active_order", {{"userId", m_userId}});
    }
}

void MainWindow::requestOrders()
{
    if (m_userId > 0) {
        send("list_orders", {{"userId", m_userId}});
    }
}

void MainWindow::on_refreshStationsButton_clicked()
{
    requestStations();
}

void MainWindow::fillStationTable(const QJsonArray &stations)
{
    m_stations = stations;
    ui->stationTable->clear();
    ui->stationTable->setColumnCount(6);
    ui->stationTable->setHorizontalHeaderLabels(
                {"电站名称", "区域", "价格(元/度)", "空闲/总数", "距离(km)", "地址"});
    ui->stationTable->setRowCount(stations.size());
    for (int rowIndex = 0; rowIndex < stations.size(); ++rowIndex) {
        const QJsonObject station = stations.at(rowIndex).toObject();
        const QStringList values = {
            station.value("name").toString(),
            station.value("area").toString(),
            QString::number(station.value("price").toDouble(), 'f', 2),
            QString("%1/%2").arg(station.value("idle_count").toInt())
            .arg(station.value("total_count").toInt()),
            QString::number(station.value("distance").toDouble(), 'f', 2),
            station.value("address").toString()
        };
        for (int columnIndex = 0; columnIndex < values.size(); ++columnIndex) {
            QTableWidgetItem *item = new QTableWidgetItem(values.at(columnIndex));
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, station.value("id").toInt());
            }
            ui->stationTable->setItem(rowIndex, columnIndex, item);
        }
    }
    ui->stationTable->resizeColumnsToContents();
    if (!stations.isEmpty()) {
        ui->stationTable->selectRow(0);
    }
}

void MainWindow::fillChargerTable(const QJsonArray &chargers)
{
    ui->chargerTable->clear();
    ui->chargerTable->setColumnCount(6);
    ui->chargerTable->setHorizontalHeaderLabels(
                {"电桩编号", "类型", "功率(kW)", "状态", "累计次数", "累计分钟"});
    ui->chargerTable->setRowCount(chargers.size());
    for (int rowIndex = 0; rowIndex < chargers.size(); ++rowIndex) {
        const QJsonObject charger = chargers.at(rowIndex).toObject();
        const QStringList values = {
            charger.value("code").toString(),
            charger.value("type").toString(),
            QString::number(charger.value("power").toDouble(), 'f', 0),
            charger.value("status").toString(),
            QString::number(charger.value("charge_count").toInt()),
            QString::number(charger.value("charge_minutes").toInt())
        };
        for (int columnIndex = 0; columnIndex < values.size(); ++columnIndex) {
            QTableWidgetItem *item = new QTableWidgetItem(values.at(columnIndex));
            if (columnIndex == 0) {
                item->setData(Qt::UserRole, charger.value("id").toInt());
            }
            ui->chargerTable->setItem(rowIndex, columnIndex, item);
        }
    }
    ui->chargerTable->resizeColumnsToContents();
}

void MainWindow::fillOrderTable(const QJsonArray &orders)
{
    ui->orderTable->clear();
    ui->orderTable->setColumnCount(9);
    ui->orderTable->setHorizontalHeaderLabels(
                {"订单", "电站", "电桩", "状态", "开始时间", "结束时间", "分钟", "电量", "费用"});
    ui->orderTable->setRowCount(orders.size());
    const QStringList keys = {"id", "station", "code", "status", "started_at", "ended_at", "minutes", "energy", "fee"};
    for (int rowIndex = 0; rowIndex < orders.size(); ++rowIndex) {
        const QJsonObject order = orders.at(rowIndex).toObject();
        for (int columnIndex = 0; columnIndex < keys.size(); ++columnIndex) {
            const QString key = keys.at(columnIndex);
            QString text = order.value(key).toVariant().toString();
            if (key == "energy" || key == "fee") {
                text = QString::number(order.value(key).toDouble(), 'f', 2);
            }
            ui->orderTable->setItem(rowIndex, columnIndex, new QTableWidgetItem(text));
        }
    }
    ui->orderTable->resizeColumnsToContents();
}

int MainWindow::selectedId(QTableWidget *table) const
{
    const QList<QTableWidgetItem *> items = table->selectedItems();
    if (items.isEmpty()) {
        return 0;
    }
    const int row = items.first()->row();
    return table->item(row, 0)->data(Qt::UserRole).toInt();
}

QJsonObject MainWindow::selectedStation() const
{
    const int stationId = selectedId(ui->stationTable);
    for (const QJsonValue &value : m_stations) {
        const QJsonObject station = value.toObject();
        if (station.value("id").toInt() == stationId) {
            return station;
        }
    }
    return QJsonObject();
}

void MainWindow::on_stationTable_itemSelectionChanged()
{
    const int stationId = selectedId(ui->stationTable);
    if (stationId > 0) {
        send("station_detail", {{"stationId", stationId}});
        const QJsonObject station = selectedStation();
        ui->selectedStationLabel->setText(
                    QString("当前电站：%1（%2 元/度）")
                    .arg(station.value("name").toString())
                    .arg(station.value("price").toDouble(), 0, 'f', 2));
    }
}

void MainWindow::on_navigationButton_clicked()
{
    const QJsonObject station = selectedStation();
    if (station.isEmpty()) {
        QMessageBox::information(this, tr("请选择电站"), tr("请先选择一个充电站。"));
        return;
    }
    const QString url = QString(
                "https://apis.map.qq.com/uri/v1/routeplan?type=drive&"
                "from=当前位置&fromcoord=%1,%2&to=%3&tocoord=%4,%5&policy=0&referer=ChargingPlatform")
            .arg(ui->latitudeSpin->value(), 0, 'f', 6)
            .arg(ui->longitudeSpin->value(), 0, 'f', 6)
            .arg(QString::fromUtf8(QUrl::toPercentEncoding(station.value("name").toString())))
            .arg(station.value("latitude").toDouble(), 0, 'f', 6)
            .arg(station.value("longitude").toDouble(), 0, 'f', 6);
    QDesktopServices::openUrl(QUrl(url));
}

void MainWindow::on_startChargeButton_clicked()
{
    if (m_activeOrderId > 0) {
        QMessageBox::warning(this, tr("存在未结算订单"), tr("您有未完成的充电订单，请先结算。"));
        return;
    }
    const int chargerId = selectedId(ui->chargerTable);
    if (chargerId <= 0) {
        QMessageBox::information(this, tr("请选择电桩"), tr("请先选择一个空闲电桩。"));
        return;
    }
    if (QMessageBox::question(this,
                              tr("开始充电"),
                              tr("确认使用所选电桩开始充电吗？")) != QMessageBox::Yes) {
        return;
    }
    send("start_charging", {{"userId", m_userId}, {"chargerId", chargerId}});
}

void MainWindow::on_stopChargeButton_clicked()
{
    if (m_activeOrderId <= 0) {
        QMessageBox::information(this, tr("没有充电任务"), tr("当前没有进行中的充电订单。"));
        return;
    }
    if (QMessageBox::question(this,
                              tr("结束充电"),
                              tr("确认结束充电并从钱包结算吗？")) != QMessageBox::Yes) {
        return;
    }
    send("stop_charging", {{"orderId", m_activeOrderId}});
}

void MainWindow::on_saveProfileButton_clicked()
{
    send("update_profile",
         {{"userId", m_userId},
          {"nickname", ui->nicknameEdit->text().trimmed()},
          {"avatar", m_avatarPath}});
}

void MainWindow::on_chooseAvatarButton_clicked()
{
    const QString path = QFileDialog::getOpenFileName(
                this, tr("选择头像"), QString(), tr("图片文件 (*.png *.jpg *.jpeg *.bmp)"));
    if (!path.isEmpty()) {
        m_avatarPath = path;
        ui->avatarPathLabel->setText(path);
    }
}

void MainWindow::on_rechargeButton_clicked()
{
    send("recharge",
         {{"userId", m_userId}, {"amount", ui->rechargeAmountSpin->value()}});
}

void MainWindow::on_refreshOrdersButton_clicked()
{
    requestOrders();
}

void MainWindow::handleResponse(const QJsonObject &response)
{
    const qint64 requestId = response.value("requestId").toVariant().toLongLong();
    const QString action = m_pendingActions.take(requestId);
    const bool ok = response.value("ok").toBool();
    const QString message = response.value("message").toString();

    if (!ok) {
        if (action == "login_user") {
            ui->loginHintLabel->setText(message);
        } else {
            QMessageBox::warning(this, tr("操作失败"), message);
        }
        return;
    }

    if (action == "login_user") {
        const QJsonObject user = response.value("data").toObject();
        m_userId = user.value("id").toInt();
        setLoggedIn(true);
        ui->welcomeLabel->setText("你好，" + user.value("nickname").toString());
        refreshAfterLogin();
    } else if (action == "list_stations") {
        fillStationTable(response.value("data").toArray());
        statusBar()->showMessage(QString("已找到 %1 个充电站").arg(m_stations.size()), 3000);
    } else if (action == "station_detail") {
        fillChargerTable(response.value("data").toArray());
    } else if (action == "profile"
               || action == "update_profile"
               || action == "recharge") {
        const QJsonObject user = response.value("data").toObject();
        ui->welcomeLabel->setText("你好，" + user.value("nickname").toString());
        ui->phoneValueLabel->setText(user.value("phone").toString());
        ui->balanceValueLabel->setText(QString("¥ %1").arg(user.value("balance").toDouble(), 0, 'f', 2));
        ui->nicknameEdit->setText(user.value("nickname").toString());
        m_avatarPath = user.value("avatar").toString();
        ui->avatarPathLabel->setText(m_avatarPath.isEmpty() ? "默认头像" : m_avatarPath);
        if (action != "profile") {
            QMessageBox::information(this, tr("操作成功"), message);
        }
    } else if (action == "active_order") {
        const QJsonObject order = response.value("data").toObject();
        if (order.isEmpty()) {
            m_activeOrderId = 0;
            m_activeStartedAt = QDateTime();
            ui->chargeStatusLabel->setText("当前没有进行中的充电订单");
            ui->stopChargeButton->setEnabled(false);
            ui->startChargeButton->setEnabled(true);
        } else {
            m_activeOrderId = order.value("id").toInt();
            m_activeStartedAt = QDateTime::fromString(order.value("started_at").toString(), Qt::ISODate);
            ui->chargeStatusLabel->setText(
                        QString("充电中：%1 / %2")
                        .arg(order.value("station_name").toString(), order.value("code").toString()));
            ui->stopChargeButton->setEnabled(true);
            ui->startChargeButton->setEnabled(false);
            ui->tabWidget->setCurrentWidget(ui->chargeTab);
        }
        updateChargingClock();
    } else if (action == "start_charging") {
        const QJsonObject data = response.value("data").toObject();
        m_activeOrderId = data.value("orderId").toInt();
        m_activeStartedAt = QDateTime::fromString(data.value("startedAt").toString(), Qt::ISODate);
        QMessageBox::information(this, tr("充电开始"), message);
        requestActiveOrder();
        requestStations();
        requestOrders();
    } else if (action == "stop_charging") {
        const QJsonObject data = response.value("data").toObject();
        QMessageBox::information(
                    this,
                    tr("结算完成"),
                    QString("%1\n充电 %2 分钟，电量 %3 kWh，费用 ¥%4")
                    .arg(message)
                    .arg(data.value("minutes").toInt())
                    .arg(data.value("energy").toDouble(), 0, 'f', 2)
                    .arg(data.value("fee").toDouble(), 0, 'f', 2));
        m_activeOrderId = 0;
        m_activeStartedAt = QDateTime();
        requestActiveOrder();
        requestProfile();
        requestStations();
        requestOrders();
    } else if (action == "list_orders") {
        fillOrderTable(response.value("data").toArray());
    }
}

void MainWindow::updateChargingClock()
{
    if (m_activeOrderId <= 0 || !m_activeStartedAt.isValid()) {
        ui->elapsedValueLabel->setText("--:--:--");
        return;
    }
    const qint64 seconds = qMax<qint64>(0, m_activeStartedAt.secsTo(QDateTime::currentDateTime()));
    ui->elapsedValueLabel->setText(
                QString("%1:%2:%3")
                .arg(seconds / 3600, 2, 10, QChar('0'))
                .arg((seconds % 3600) / 60, 2, 10, QChar('0'))
                .arg(seconds % 60, 2, 10, QChar('0')));
}
