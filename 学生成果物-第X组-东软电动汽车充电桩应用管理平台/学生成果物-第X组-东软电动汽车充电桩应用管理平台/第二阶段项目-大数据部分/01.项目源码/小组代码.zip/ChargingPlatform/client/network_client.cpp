#include "network_client.h"

#include <QJsonDocument>
#include <QJsonParseError>

NetworkClient::NetworkClient(QObject *parent)
    : QObject(parent)
    , m_nextRequestId(1)
{
    connect(&m_socket, &QTcpSocket::connected,
            this, &NetworkClient::socketConnected);
    connect(&m_socket, &QTcpSocket::disconnected,
            this, &NetworkClient::socketDisconnected);
    connect(&m_socket, &QTcpSocket::readyRead,
            this, &NetworkClient::readData);
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
    connect(&m_socket, &QAbstractSocket::errorOccurred,
            this, &NetworkClient::socketError);
#else
    connect(&m_socket,
            QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),
            this, &NetworkClient::socketError);
#endif
}

void NetworkClient::connectToServer(const QString &host, quint16 port)
{
    if (m_socket.state() != QAbstractSocket::UnconnectedState) {
        m_socket.abort();
    }
    m_buffer.clear();
    m_socket.connectToHost(host.trimmed(), port);
}

qint64 NetworkClient::sendRequest(const QString &action, const QJsonObject &payload)
{
    if (!isConnected()) {
        emit networkError("尚未连接到服务器");
        return -1;
    }

    QJsonObject request = payload;
    request.insert("action", action);
    const qint64 requestId = m_nextRequestId++;
    request.insert("requestId", requestId);
    m_socket.write(QJsonDocument(request).toJson(QJsonDocument::Compact));
    m_socket.write("\n");
    return requestId;
}

bool NetworkClient::isConnected() const
{
    return m_socket.state() == QAbstractSocket::ConnectedState;
}

void NetworkClient::readData()
{
    m_buffer.append(m_socket.readAll());
    while (m_buffer.contains('\n')) {
        const int delimiterIndex = m_buffer.indexOf('\n');
        const QByteArray line = m_buffer.left(delimiterIndex).trimmed();
        m_buffer.remove(0, delimiterIndex + 1);
        if (line.isEmpty()) {
            continue;
        }

        QJsonParseError error;
        const QJsonDocument document = QJsonDocument::fromJson(line, &error);
        if (error.error != QJsonParseError::NoError || !document.isObject()) {
            emit networkError("服务器返回了无法解析的数据");
            continue;
        }
        emit responseReceived(document.object());
    }
}

void NetworkClient::socketConnected()
{
    emit connectedChanged(true);
}

void NetworkClient::socketDisconnected()
{
    emit connectedChanged(false);
}

void NetworkClient::socketError(QAbstractSocket::SocketError error)
{
    Q_UNUSED(error)
    emit networkError(m_socket.errorString());
}

