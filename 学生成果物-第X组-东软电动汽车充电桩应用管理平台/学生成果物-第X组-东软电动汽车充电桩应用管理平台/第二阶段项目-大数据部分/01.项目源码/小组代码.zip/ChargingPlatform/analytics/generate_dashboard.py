#!/usr/bin/env python3
"""Aggregate the charging SQLite database and forecast the next 24 hours.

The forecasting model is ridge linear regression implemented with the Python
standard library.  Features describe hour-of-day, weekday, weekend, station
and time trend.  This keeps the exercise reproducible without third-party
machine-learning packages.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path


def solve_linear_system(matrix: list[list[float]], vector: list[float]) -> list[float]:
    """Solve Ax=b with Gaussian elimination and partial pivoting."""
    size = len(vector)
    augmented = [matrix[row][:] + [vector[row]] for row in range(size)]
    for column in range(size):
        pivot = max(range(column, size), key=lambda row: abs(augmented[row][column]))
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        divisor = augmented[column][column]
        if abs(divisor) < 1e-12:
            continue
        augmented[column] = [value / divisor for value in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                augmented[row][index] - factor * augmented[column][index]
                for index in range(size + 1)
            ]
    return [augmented[row][-1] for row in range(size)]


def feature_vector(timestamp: datetime, station_id: int, trend: float) -> list[float]:
    hour_angle = 2.0 * math.pi * timestamp.hour / 24.0
    weekday_angle = 2.0 * math.pi * timestamp.weekday() / 7.0
    return [
        1.0,
        math.sin(hour_angle),
        math.cos(hour_angle),
        math.sin(weekday_angle),
        math.cos(weekday_angle),
        1.0 if timestamp.weekday() >= 5 else 0.0,
        float(station_id),
        trend,
    ]


def fit_ridge(samples: list[tuple[list[float], float]], penalty: float = 8.0) -> list[float]:
    feature_count = len(samples[0][0])
    xtx = [[0.0] * feature_count for _ in range(feature_count)]
    xty = [0.0] * feature_count
    for features, target in samples:
        for row in range(feature_count):
            xty[row] += features[row] * target
            for column in range(feature_count):
                xtx[row][column] += features[row] * features[column]
    for index in range(1, feature_count):
        xtx[index][index] += penalty
    return solve_linear_system(xtx, xty)


def predict(weights: list[float], features: list[float]) -> float:
    return max(0.0, sum(weight * value for weight, value in zip(weights, features)))


def table_exists(connection: sqlite3.Connection, table: str) -> bool:
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone()
    return row is not None


def create_demo_database(database_path: Path) -> None:
    database_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database_path)
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS stations(
          id INTEGER PRIMARY KEY, name TEXT, area TEXT, price REAL);
        CREATE TABLE IF NOT EXISTS chargers(
          id INTEGER PRIMARY KEY, station_id INTEGER, status TEXT);
        CREATE TABLE IF NOT EXISTS orders(
          id INTEGER PRIMARY KEY, status TEXT, ended_at TEXT, fee REAL);
        CREATE TABLE IF NOT EXISTS hourly_load(
          id INTEGER PRIMARY KEY, station_id INTEGER, timestamp TEXT,
          load_kw REAL, available_count INTEGER, weather REAL, is_holiday INTEGER);
        DELETE FROM stations; DELETE FROM chargers; DELETE FROM orders; DELETE FROM hourly_load;
        """
    )
    stations = [
        (1, "中关村新能源充电站", "海淀区", 1.38),
        (2, "魏公村智慧充电中心", "海淀区", 1.22),
        (3, "西单绿色出行站", "西城区", 1.48),
        (4, "国贸快速充电站", "朝阳区", 1.65),
    ]
    connection.executemany("INSERT INTO stations VALUES(?,?,?,?)", stations)
    charger_id = 1
    for station_id in range(1, 5):
        for index in range(6):
            status = "fault" if station_id == 3 and index == 4 else "idle"
            connection.execute(
                "INSERT INTO chargers VALUES(?,?,?)", (charger_id, station_id, status)
            )
            charger_id += 1

    random.seed(20260903)
    current = datetime.now().replace(minute=0, second=0, microsecond=0)
    load_rows = []
    for hours_ago in range(24 * 28, 0, -1):
        timestamp = current - timedelta(hours=hours_ago)
        busy = 1.0 if timestamp.hour in range(7, 11) or timestamp.hour in range(17, 22) else 0.38
        for station_id in range(1, 5):
            load = 22 + station_id * 9 + busy * 96 + random.uniform(-11, 13)
            load_rows.append(
                (
                    station_id,
                    timestamp.isoformat(timespec="seconds"),
                    round(max(5, load), 2),
                    max(0, 6 - round(load / 45)),
                    17 + random.uniform(0, 14),
                    1 if timestamp.weekday() >= 5 else 0,
                )
            )
    connection.executemany(
        "INSERT INTO hourly_load(station_id,timestamp,load_kw,available_count,weather,is_holiday) "
        "VALUES(?,?,?,?,?,?)",
        load_rows,
    )
    for day in range(30, 0, -1):
        finished = current - timedelta(days=day, hours=random.randint(0, 10))
        for _ in range(random.randint(3, 8)):
            connection.execute(
                "INSERT INTO orders(status,ended_at,fee) VALUES('completed',?,?)",
                (finished.isoformat(timespec="seconds"), round(random.uniform(18, 96), 2)),
            )
    connection.commit()
    connection.close()


def build_dashboard_data(connection: sqlite3.Connection) -> dict:
    connection.row_factory = sqlite3.Row
    stations = [dict(row) for row in connection.execute(
        "SELECT id,name,area,price FROM stations ORDER BY id"
    )]
    load_rows = list(connection.execute(
        "SELECT station_id,timestamp,load_kw,available_count FROM hourly_load "
        "ORDER BY timestamp,station_id"
    ))
    if len(load_rows) < 48:
        raise RuntimeError("hourly_load 数据不足，至少需要 48 条历史记录")

    first_time = datetime.fromisoformat(load_rows[0]["timestamp"])
    samples: list[tuple[list[float], float]] = []
    for row in load_rows:
        timestamp = datetime.fromisoformat(row["timestamp"])
        trend = (timestamp - first_time).total_seconds() / 3600.0 / max(1, len(load_rows))
        samples.append((feature_vector(timestamp, row["station_id"], trend), row["load_kw"]))
    weights = fit_ridge(samples)

    forecast_start = datetime.now().replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    forecast = []
    for offset in range(24):
        timestamp = forecast_start + timedelta(hours=offset)
        station_predictions = []
        for station in stations:
            trend = (timestamp - first_time).total_seconds() / 3600.0 / max(1, len(load_rows))
            station_predictions.append(
                predict(weights, feature_vector(timestamp, station["id"], trend))
            )
        forecast.append(
            {
                "time": timestamp.strftime("%m-%d %H:00"),
                "loadKw": round(sum(station_predictions), 1),
                "available": max(0, len(stations) * 6 - round(sum(station_predictions) / 55.0)),
            }
        )

    revenue_rows = connection.execute(
        "WITH RECURSIVE days(day) AS ("
        "SELECT date('now','-29 day') UNION ALL "
        "SELECT date(day,'+1 day') FROM days WHERE day<date('now')) "
        "SELECT day,ROUND(COALESCE(SUM(o.fee),0),2) AS revenue "
        "FROM days LEFT JOIN orders o ON date(o.ended_at)=day AND o.status='completed' "
        "GROUP BY day ORDER BY day"
    ).fetchall()
    status_rows = connection.execute(
        "SELECT status,COUNT(*) AS count FROM chargers GROUP BY status"
    ).fetchall()
    station_load_rows = connection.execute(
        "SELECT s.name,ROUND(AVG(h.load_kw),1) AS avg_load,"
        "ROUND(AVG(h.available_count),1) AS avg_available "
        "FROM stations s JOIN hourly_load h ON h.station_id=s.id "
        "GROUP BY s.id ORDER BY avg_load DESC"
    ).fetchall()
    metrics = connection.execute(
        "SELECT ROUND(COALESCE(SUM(CASE WHEN date(ended_at)=date('now') THEN fee END),0),2) today,"
        "ROUND(COALESCE(SUM(CASE WHEN strftime('%Y-%m',ended_at)=strftime('%Y-%m','now') THEN fee END),0),2) month,"
        "ROUND(COALESCE(SUM(fee),0),2) total, COUNT(*) orders "
        "FROM orders WHERE status='completed'"
    ).fetchone()

    total_chargers = sum(row["count"] for row in status_rows)
    non_fault = sum(row["count"] for row in status_rows if row["status"] != "fault")
    online_rate = 100.0 * non_fault / total_chargers if total_chargers else 0.0
    peak = max(forecast, key=lambda item: item["loadKw"])

    return {
        "generatedAt": datetime.now().isoformat(timespec="seconds"),
        "metrics": {
            "todayRevenue": metrics["today"],
            "monthRevenue": metrics["month"],
            "totalRevenue": metrics["total"],
            "completedOrders": metrics["orders"],
            "onlineRate": round(online_rate, 1),
            "forecastPeak": peak["loadKw"],
            "forecastPeakTime": peak["time"],
        },
        "revenue": [dict(row) for row in revenue_rows],
        "chargerStatus": [dict(row) for row in status_rows],
        "stationLoad": [dict(row) for row in station_load_rows],
        "forecast": forecast,
        "stations": stations,
        "model": {
            "name": "Ridge Linear Regression",
            "features": ["hour cycle", "weekday cycle", "weekend", "station", "time trend"],
            "trainingRows": len(samples),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="生成充电平台 ECharts 大屏数据")
    parser.add_argument("--db", default="../data/charging_platform.db", help="SQLite 数据库路径")
    parser.add_argument("--out", default="dashboard/data.json", help="输出 JSON 路径")
    parser.add_argument("--demo", action="store_true", help="数据库不存在时创建可演示数据")
    arguments = parser.parse_args()

    script_directory = Path(__file__).resolve().parent
    database_path = (script_directory / arguments.db).resolve()
    output_path = (script_directory / arguments.out).resolve()
    if not database_path.exists():
        if not arguments.demo:
            raise SystemExit(f"数据库不存在：{database_path}\n请先运行 Qt 服务端，或追加 --demo。")
        create_demo_database(database_path)

    connection = sqlite3.connect(database_path)
    required = {"stations", "chargers", "orders", "hourly_load"}
    missing = [table for table in required if not table_exists(connection, table)]
    if missing:
        connection.close()
        raise SystemExit("数据库缺少表：" + ", ".join(sorted(missing)))

    data = build_dashboard_data(connection)
    connection.close()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Dashboard data written to {output_path}")


if __name__ == "__main__":
    main()

