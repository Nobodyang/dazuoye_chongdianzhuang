TEMPLATE = subdirs
CONFIG += ordered

SUBDIRS += \
    server \
    client

server.file = server/server.pro
client.file = client/client.pro
client.depends = server

