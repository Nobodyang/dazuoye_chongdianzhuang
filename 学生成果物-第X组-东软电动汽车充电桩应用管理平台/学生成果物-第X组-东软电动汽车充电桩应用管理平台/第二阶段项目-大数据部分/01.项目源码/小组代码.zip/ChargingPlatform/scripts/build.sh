#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
build_dir="${project_dir}/build"

mkdir -p "$build_dir"
cd "$build_dir"
qmake "${project_dir}/ChargingPlatform.pro"
make -j"$(nproc)"

echo "Build completed: ${build_dir}"
