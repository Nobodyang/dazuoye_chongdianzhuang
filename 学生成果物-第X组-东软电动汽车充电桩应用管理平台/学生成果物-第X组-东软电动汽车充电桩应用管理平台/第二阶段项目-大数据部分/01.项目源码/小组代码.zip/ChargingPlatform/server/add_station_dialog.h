#ifndef ADD_STATION_DIALOG_H
#define ADD_STATION_DIALOG_H

#include <QDialog>
#include <QJsonObject>

namespace Ui {
class AddStationDialog;
}

class AddStationDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddStationDialog(QWidget *parent = nullptr);
    ~AddStationDialog();

    QJsonObject stationData() const;

private slots:
    void validateAndAccept();

private:
    Ui::AddStationDialog *ui;
};

#endif // ADD_STATION_DIALOG_H

