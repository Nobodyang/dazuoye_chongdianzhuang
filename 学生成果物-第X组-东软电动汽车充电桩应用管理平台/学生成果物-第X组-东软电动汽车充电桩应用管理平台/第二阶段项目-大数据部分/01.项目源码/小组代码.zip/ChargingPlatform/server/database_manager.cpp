#include "database_manager.h"

#include <QDate>
#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QJsonDocument>
#include <QProcessEnvironment>
#include <QRegularExpression>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QStandardPaths>
#include <QStringList>
#include <QtMath>

#include <algorithm>

namespace {

double distanceKilometers(double latitude1,
                          double longitude1,
                          double latitude2,
                          double longitude2)
{
    const double earthRadius = 6371.0;
    const double latDelta = qDegreesToRadians(latitude2 - latitude1);
    const double lonDelta = qDegreesToRadians(longitude2 - longitude1);
    const double a = qPow(qSin(latDelta / 2.0), 2.0)
            + qCos(qDegreesToRadians(latitude1))
            * qCos(qDegreesToRadians(latitude2))
            * qPow(qSin(lonDelta / 2.0), 2.0);
    return earthRadius * 2.0 * qAtan2(qSqrt(a), qSqrt(1.0 - a));
}

QString nowIso()
{
    return QDateTime::currentDateTime().toString(Qt::ISODate);
}

} // namespace

DatabaseManager::DatabaseManager()
    : m_connectionName("charging_server_main")
{
}

DatabaseManager::~DatabaseManager()
{
    if (m_database.isValid()) {
        m_database.close();
    }
}

bool DatabaseManager::open()
{
    QString configuredPath = qEnvironmentVariable("CHARGING_DB_PATH");
    if (configuredPath.isEmpty()) {
        const QString dataDirectory =
                QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        QDir().mkpath(dataDirectory);
        configuredPath = QDir(dataDirectory).filePath("charging_platform.db");
    } else {
        QDir().mkpath(QFileInfo(configuredPath).absolutePath());
    }

    m_databasePath = configuredPath;
    m_database = QSqlDatabase::addDatabase("QSQLITE", m_connectionName);
    m_database.setDatabaseName(m_databasePath);

    if (!m_database.open()) {
        m_lastError = m_database.lastError().text();
        return false;
    }

    if (!execute("PRAGMA foreign_keys = ON")
            || !execute("PRAGMA journal_mode = WAL")
            || !createTables()
            || !seedData()) {
        return false;
    }
    return true;
}

QString DatabaseManager::databasePath() const
{
    return m_databasePath;
}

QString DatabaseManager::lastError() const
{
    return m_lastError;
}

bool DatabaseManager::execute(const QString &sql)
{
    QSqlQuery query(m_database);
    if (!query.exec(sql)) {
        m_lastError = query.lastError().text() + " | SQL: " + sql;
        return false;
    }
    return true;
}

bool DatabaseManager::createTables()
{
    const QStringList statements = {
        "CREATE TABLE IF NOT EXISTS admins("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, "
        "password TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS users("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE NOT NULL, "
        "nickname TEXT NOT NULL, avatar TEXT DEFAULT '', balance REAL DEFAULT 100.0, "
        "status TEXT DEFAULT 'normal', registered_at TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS stations("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, area TEXT NOT NULL, "
        "address TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL, "
        "price REAL NOT NULL, created_at TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS chargers("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, station_id INTEGER NOT NULL, "
        "code TEXT UNIQUE NOT NULL, type TEXT NOT NULL, power REAL NOT NULL, "
        "status TEXT DEFAULT 'idle', charge_count INTEGER DEFAULT 0, "
        "charge_minutes INTEGER DEFAULT 0, last_restart TEXT DEFAULT '', "
        "FOREIGN KEY(station_id) REFERENCES stations(id) ON DELETE CASCADE)",
        "CREATE TABLE IF NOT EXISTS orders("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, "
        "charger_id INTEGER NOT NULL, status TEXT NOT NULL, started_at TEXT NOT NULL, "
        "ended_at TEXT DEFAULT '', minutes INTEGER DEFAULT 0, energy REAL DEFAULT 0, "
        "fee REAL DEFAULT 0, FOREIGN KEY(user_id) REFERENCES users(id), "
        "FOREIGN KEY(charger_id) REFERENCES chargers(id))",
        "CREATE TABLE IF NOT EXISTS hourly_load("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, station_id INTEGER NOT NULL, "
        "timestamp TEXT NOT NULL, load_kw REAL NOT NULL, available_count INTEGER NOT NULL, "
        "weather REAL DEFAULT 20, is_holiday INTEGER DEFAULT 0, "
        "FOREIGN KEY(station_id) REFERENCES stations(id))"
    };

    for (const QString &statement : statements) {
        if (!execute(statement)) {
            return false;
        }
    }
    return true;
}

bool DatabaseManager::seedData()
{
    QSqlQuery countQuery(m_database);
    if (!countQuery.exec("SELECT COUNT(*) FROM admins") || !countQuery.next()) {
        m_lastError = countQuery.lastError().text();
        return false;
    }
    if (countQuery.value(0).toInt() == 0
            && !execute("INSERT INTO admins(username,password) VALUES('admin','123456')")) {
        return false;
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM stations") || !countQuery.next()) {
        m_lastError = countQuery.lastError().text();
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        const QString current = nowIso();
        QSqlQuery insertStation(m_database);
        insertStation.prepare("INSERT INTO stations(name,area,address,latitude,longitude,price,created_at) "
                              "VALUES(?,?,?,?,?,?,?)");
        const QList<QVariantList> stations = {
            {"中关村新能源充电站", "海淀区", "北京市海淀区中关村南大街5号", 39.9587, 116.3269, 1.38, current},
            {"魏公村智慧充电中心", "海淀区", "北京市海淀区魏公村路2号", 39.9535, 116.3235, 1.22, current},
            {"西单绿色出行站", "西城区", "北京市西城区西单北大街120号", 39.9102, 116.3741, 1.48, current},
            {"国贸快速充电站", "朝阳区", "北京市朝阳区建国门外大街1号", 39.9086, 116.4605, 1.65, current}
        };
        for (const QVariantList &station : stations) {
            for (int index = 0; index < station.size(); ++index) {
                insertStation.bindValue(index, station.at(index));
            }
            if (!insertStation.exec()) {
                m_lastError = insertStation.lastError().text();
                return false;
            }
            const int stationId = insertStation.lastInsertId().toInt();
            for (int chargerIndex = 1; chargerIndex <= 6; ++chargerIndex) {
                QSqlQuery insertCharger(m_database);
                insertCharger.prepare("INSERT INTO chargers(station_id,code,type,power,status) "
                                      "VALUES(:station,:code,:type,:power,:status)");
                insertCharger.bindValue(":station", stationId);
                insertCharger.bindValue(":code",
                                        QString("S%1-C%2")
                                        .arg(stationId, 2, 10, QChar('0'))
                                        .arg(chargerIndex, 2, 10, QChar('0')));
                insertCharger.bindValue(":type", chargerIndex <= 4 ? "快充" : "慢充");
                insertCharger.bindValue(":power", chargerIndex <= 4 ? 120.0 : 7.0);
                insertCharger.bindValue(":status",
                                        chargerIndex == 5 && stationId == 3 ? "fault" : "idle");
                if (!insertCharger.exec()) {
                    m_lastError = insertCharger.lastError().text();
                    return false;
                }
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM users") || !countQuery.next()) {
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        QSqlQuery insertUser(m_database);
        insertUser.prepare("INSERT INTO users(phone,nickname,balance,status,registered_at) "
                           "VALUES(?,?,?,?,?)");
        const QList<QVariantList> users = {
            {"13800138000", "演示用户8000", 188.0, "normal", QDateTime::currentDateTime().addDays(-30).toString(Qt::ISODate)},
            {"13900139000", "绿色先锋9000", 92.5, "normal", QDateTime::currentDateTime().addDays(-18).toString(Qt::ISODate)},
            {"13700137000", "测试用户7000", 65.0, "frozen", QDateTime::currentDateTime().addDays(-8).toString(Qt::ISODate)}
        };
        for (const QVariantList &user : users) {
            for (int index = 0; index < user.size(); ++index) {
                insertUser.bindValue(index, user.at(index));
            }
            if (!insertUser.exec()) {
                m_lastError = insertUser.lastError().text();
                return false;
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM orders") || !countQuery.next()) {
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        for (int day = 12; day >= 1; --day) {
            const int chargerId = (day % 20) + 1;
            const int userId = (day % 2) + 1;
            const int minutes = 24 + day * 3;
            const double energy = minutes * (chargerId % 5 == 0 ? 7.0 : 120.0) / 60.0 * 0.72;
            const double fee = energy * (1.18 + (chargerId % 4) * 0.1);
            const QDateTime start = QDateTime::currentDateTime().addDays(-day).addSecs(-3600);
            QSqlQuery order(m_database);
            order.prepare("INSERT INTO orders(user_id,charger_id,status,started_at,ended_at,minutes,energy,fee) "
                          "VALUES(?,?,'completed',?,?,?,?,?)");
            order.addBindValue(userId);
            order.addBindValue(chargerId);
            order.addBindValue(start.toString(Qt::ISODate));
            order.addBindValue(start.addSecs(minutes * 60).toString(Qt::ISODate));
            order.addBindValue(minutes);
            order.addBindValue(energy);
            order.addBindValue(fee);
            if (!order.exec()) {
                m_lastError = order.lastError().text();
                return false;
            }
        }
    }

    if (!countQuery.exec("SELECT COUNT(*) FROM hourly_load") || !countQuery.next()) {
        return false;
    }
    if (countQuery.value(0).toInt() == 0) {
        QSqlQuery loadInsert(m_database);
        loadInsert.prepare("INSERT INTO hourly_load(station_id,timestamp,load_kw,available_count,weather,is_holiday) "
                           "VALUES(?,?,?,?,?,?)");
        for (int hoursAgo = 24 * 21; hoursAgo >= 1; --hoursAgo) {
            const QDateTime time = QDateTime::currentDateTime().addSecs(-hoursAgo * 3600);
            const int hour = time.time().hour();
            const double rush = (hour >= 7 && hour <= 10) || (hour >= 17 && hour <= 21) ? 1.0 : 0.45;
            for (int stationId = 1; stationId <= 4; ++stationId) {
                const double load = 25.0 + stationId * 8.0 + rush * 92.0
                        + ((hoursAgo * 17 + stationId * 13) % 31);
                loadInsert.bindValue(0, stationId);
                loadInsert.bindValue(1, time.toString(Qt::ISODate));
                loadInsert.bindValue(2, load);
                loadInsert.bindValue(3, qMax(0, 6 - qRound(load / 45.0)));
                loadInsert.bindValue(4, 18.0 + ((hoursAgo + stationId) % 12));
                loadInsert.bindValue(5, time.date().dayOfWeek() >= 6 ? 1 : 0);
                if (!loadInsert.exec()) {
                    m_lastError = loadInsert.lastError().text();
                    return false;
                }
            }
        }
    }

    return true;
}

QJsonArray DatabaseManager::selectRows(const QString &sql, const QVariantMap &bindings)
{
    QJsonArray result;
    QSqlQuery query(m_database);
    query.prepare(sql);
    for (auto iterator = bindings.constBegin(); iterator != bindings.constEnd(); ++iterator) {
        query.bindValue(iterator.key(), iterator.value());
    }
    if (!query.exec()) {
        m_lastError = query.lastError().text();
        return result;
    }
    while (query.next()) {
        QJsonObject row;
        const QSqlRecord record = query.record();
        for (int index = 0; index < record.count(); ++index) {
            row.insert(record.fieldName(index), QJsonValue::fromVariant(query.value(index)));
        }
        result.append(row);
    }
    return result;
}

QJsonObject DatabaseManager::selectOne(const QString &sql, const QVariantMap &bindings)
{
    const QJsonArray rows = selectRows(sql, bindings);
    return rows.isEmpty() ? QJsonObject() : rows.first().toObject();
}

QJsonObject DatabaseManager::response(bool ok,
                                      const QString &message,
                                      const QJsonValue &data) const
{
    QJsonObject object;
    object.insert("ok", ok);
    object.insert("message", message);
    if (!data.isUndefined() && !data.isNull()) {
        object.insert("data", data);
    }
    return object;
}

bool DatabaseManager::validateAdmin(const QString &username, const QString &password)
{
    QSqlQuery query(m_database);
    query.prepare("SELECT id FROM admins WHERE username=:username AND password=:password");
    query.bindValue(":username", username.trimmed());
    query.bindValue(":password", password);
    return query.exec() && query.next();
}

QJsonObject DatabaseManager::handleRequest(const QJsonObject &request)
{
    const QString action = request.value("action").toString();
    QJsonObject result;

    if (action == "login_user") {
        result = loginUser(request);
    } else if (action == "list_stations") {
        result = listStations(request);
    } else if (action == "station_detail") {
        result = stationDetail(request);
    } else if (action == "profile") {
        result = profile(request);
    } else if (action == "update_profile") {
        result = updateProfile(request);
    } else if (action == "recharge") {
        result = recharge(request);
    } else if (action == "start_charging") {
        result = startCharging(request);
    } else if (action == "stop_charging") {
        result = stopCharging(request);
    } else if (action == "active_order") {
        result = activeOrder(request);
    } else if (action == "list_orders") {
        result = listOrders(request);
    } else if (action == "dashboard") {
        result = dashboard();
    } else if (action == "admin_chargers") {
        result = listChargers(request);
    } else if (action == "restart_charger") {
        result = restartCharger(request);
    } else if (action == "admin_stations") {
        result = listAdminStations();
    } else if (action == "add_station") {
        result = addStation(request);
    } else if (action == "admin_users") {
        result = listUsers(request);
    } else if (action == "toggle_user") {
        result = toggleUser(request);
    } else if (action == "admin_orders") {
        result = listAllOrders();
    } else {
        result = response(false, "未知请求：" + action);
    }

    result.insert("requestId", request.value("requestId"));
    return result;
}

QJsonObject DatabaseManager::loginUser(const QJsonObject &request)
{
    const QString phone = request.value("phone").toString().trimmed();
    const QRegularExpression phonePattern("^1[3-9]\\d{9}$");
    if (!phonePattern.match(phone).hasMatch()) {
        return response(false, "请输入合法的 11 位手机号");
    }

    QJsonObject user = selectOne(
                "SELECT id,phone,nickname,avatar,balance,status,registered_at FROM users WHERE phone=:phone",
                {{":phone", phone}});
    if (user.isEmpty()) {
        QSqlQuery insert(m_database);
        insert.prepare("INSERT INTO users(phone,nickname,balance,status,registered_at) "
                       "VALUES(:phone,:nickname,100.0,'normal',:registered)");
        insert.bindValue(":phone", phone);
        insert.bindValue(":nickname", "用户" + phone.right(4));
        insert.bindValue(":registered", nowIso());
        if (!insert.exec()) {
            return response(false, "注册失败：" + insert.lastError().text());
        }
        user = selectOne(
                    "SELECT id,phone,nickname,avatar,balance,status,registered_at FROM users WHERE phone=:phone",
                    {{":phone", phone}});
    }

    if (user.value("status").toString() == "frozen") {
        return response(false, "账号已冻结，请联系管理员");
    }
    return response(true, "登录成功", user);
}

QJsonObject DatabaseManager::listStations(const QJsonObject &request)
{
    const QString area = request.value("area").toString().trimmed();
    const double latitude = request.value("latitude").toDouble(39.9570);
    const double longitude = request.value("longitude").toDouble(116.3270);
    QString sql =
            "SELECT s.id,s.name,s.area,s.address,s.latitude,s.longitude,s.price,"
            "COUNT(c.id) AS total_count,"
            "SUM(CASE WHEN c.status='idle' THEN 1 ELSE 0 END) AS idle_count "
            "FROM stations s LEFT JOIN chargers c ON c.station_id=s.id ";
    QVariantMap bindings;
    if (!area.isEmpty() && area != "全部区域") {
        sql += "WHERE s.area=:area ";
        bindings.insert(":area", area);
    }
    sql += "GROUP BY s.id ORDER BY s.id";

    QJsonArray rows = selectRows(sql, bindings);
    QList<QJsonObject> sorted;
    for (const QJsonValue &value : rows) {
        QJsonObject station = value.toObject();
        station.insert("distance",
                       distanceKilometers(latitude,
                                          longitude,
                                          station.value("latitude").toDouble(),
                                          station.value("longitude").toDouble()));
        sorted.append(station);
    }
    std::sort(sorted.begin(), sorted.end(), [](const QJsonObject &left, const QJsonObject &right) {
        return left.value("distance").toDouble() < right.value("distance").toDouble();
    });
    QJsonArray sortedArray;
    for (const QJsonObject &station : sorted) {
        sortedArray.append(station);
    }
    return response(true, "查询成功", sortedArray);
}

QJsonObject DatabaseManager::stationDetail(const QJsonObject &request)
{
    const int stationId = request.value("stationId").toInt();
    const QJsonArray chargers = selectRows(
                "SELECT id,code,type,power,status,charge_count,charge_minutes "
                "FROM chargers WHERE station_id=:station ORDER BY code",
                {{":station", stationId}});
    return response(true, "查询成功", chargers);
}

QJsonObject DatabaseManager::profile(const QJsonObject &request)
{
    const QJsonObject user = selectOne(
                "SELECT id,phone,nickname,avatar,balance,status,registered_at "
                "FROM users WHERE id=:id",
                {{":id", request.value("userId").toInt()}});
    return user.isEmpty() ? response(false, "用户不存在") : response(true, "查询成功", user);
}

QJsonObject DatabaseManager::updateProfile(const QJsonObject &request)
{
    const QString nickname = request.value("nickname").toString().trimmed();
    const QString avatar = request.value("avatar").toString().trimmed();
    if (nickname.isEmpty() || nickname.size() > 20) {
        return response(false, "昵称长度应为 1 至 20 个字符");
    }
    QSqlQuery query(m_database);
    query.prepare("UPDATE users SET nickname=:nickname,avatar=:avatar WHERE id=:id");
    query.bindValue(":nickname", nickname);
    query.bindValue(":avatar", avatar);
    query.bindValue(":id", request.value("userId").toInt());
    if (!query.exec() || query.numRowsAffected() != 1) {
        return response(false, "保存失败：" + query.lastError().text());
    }
    return profile(request);
}

QJsonObject DatabaseManager::recharge(const QJsonObject &request)
{
    const double amount = request.value("amount").toDouble();
    if (amount <= 0.0 || amount > 10000.0) {
        return response(false, "充值金额应大于 0 且不超过 10000 元");
    }
    QSqlQuery query(m_database);
    query.prepare("UPDATE users SET balance=ROUND(balance+:amount,2) WHERE id=:id");
    query.bindValue(":amount", amount);
    query.bindValue(":id", request.value("userId").toInt());
    if (!query.exec() || query.numRowsAffected() != 1) {
        return response(false, "充值失败：" + query.lastError().text());
    }
    return profile(request);
}

QJsonObject DatabaseManager::startCharging(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    const int chargerId = request.value("chargerId").toInt();
    if (userId <= 0 || chargerId <= 0) {
        return response(false, "用户或电桩参数无效");
    }

    const QJsonObject user = selectOne("SELECT status FROM users WHERE id=:id", {{":id", userId}});
    if (user.value("status").toString() != "normal") {
        return response(false, "账号不可用");
    }
    if (!selectOne("SELECT id FROM orders WHERE user_id=:user AND status='charging'",
                   {{":user", userId}}).isEmpty()) {
        return response(false, "您有未完成的充电订单，请先结算");
    }
    const QJsonObject charger = selectOne("SELECT status FROM chargers WHERE id=:id",
                                          {{":id", chargerId}});
    if (charger.value("status").toString() != "idle") {
        return response(false, "所选电桩当前不可用");
    }

    if (!m_database.transaction()) {
        return response(false, "无法启动数据库事务");
    }
    QSqlQuery order(m_database);
    order.prepare("INSERT INTO orders(user_id,charger_id,status,started_at) "
                  "VALUES(:user,:charger,'charging',:started)");
    order.bindValue(":user", userId);
    order.bindValue(":charger", chargerId);
    order.bindValue(":started", nowIso());
    QSqlQuery update(m_database);
    update.prepare("UPDATE chargers SET status='in_use' WHERE id=:id AND status='idle'");
    update.bindValue(":id", chargerId);
    if (!order.exec() || !update.exec() || update.numRowsAffected() != 1 || !m_database.commit()) {
        m_database.rollback();
        return response(false, "创建充电订单失败");
    }
    QJsonObject data;
    data.insert("orderId", order.lastInsertId().toInt());
    data.insert("startedAt", nowIso());
    return response(true, "充电已开始", data);
}

QJsonObject DatabaseManager::stopCharging(const QJsonObject &request)
{
    const int orderId = request.value("orderId").toInt();
    QJsonObject order = selectOne(
                "SELECT o.id,o.user_id,o.charger_id,o.started_at,u.balance,c.power,s.price "
                "FROM orders o JOIN users u ON u.id=o.user_id "
                "JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id "
                "WHERE o.id=:id AND o.status='charging'",
                {{":id", orderId}});
    if (order.isEmpty()) {
        return response(false, "没有找到进行中的订单");
    }

    const QDateTime start = QDateTime::fromString(order.value("started_at").toString(), Qt::ISODate);
    const int minutes = qMax(1, static_cast<int>(start.secsTo(QDateTime::currentDateTime()) / 60));
    const double energy = order.value("power").toDouble() * minutes / 60.0 * 0.85;
    const double fee = qRound(energy * order.value("price").toDouble() * 100.0) / 100.0;
    if (order.value("balance").toDouble() + 0.0001 < fee) {
        return response(false, QString("余额不足，当前需支付 %1 元，请先充值").arg(fee, 0, 'f', 2));
    }

    if (!m_database.transaction()) {
        return response(false, "无法启动数据库事务");
    }
    QSqlQuery finish(m_database);
    finish.prepare("UPDATE orders SET status='completed',ended_at=:ended,minutes=:minutes,"
                   "energy=:energy,fee=:fee WHERE id=:id AND status='charging'");
    finish.bindValue(":ended", nowIso());
    finish.bindValue(":minutes", minutes);
    finish.bindValue(":energy", energy);
    finish.bindValue(":fee", fee);
    finish.bindValue(":id", orderId);

    QSqlQuery updateCharger(m_database);
    updateCharger.prepare("UPDATE chargers SET status='idle',charge_count=charge_count+1,"
                          "charge_minutes=charge_minutes+:minutes WHERE id=:id");
    updateCharger.bindValue(":minutes", minutes);
    updateCharger.bindValue(":id", order.value("charger_id").toInt());

    QSqlQuery updateUser(m_database);
    updateUser.prepare("UPDATE users SET balance=ROUND(balance-:fee,2) WHERE id=:id");
    updateUser.bindValue(":fee", fee);
    updateUser.bindValue(":id", order.value("user_id").toInt());

    if (!finish.exec() || !updateCharger.exec() || !updateUser.exec() || !m_database.commit()) {
        m_database.rollback();
        return response(false, "订单结算失败");
    }

    QJsonObject data;
    data.insert("minutes", minutes);
    data.insert("energy", energy);
    data.insert("fee", fee);
    return response(true, "充电已结束并完成结算", data);
}

QJsonObject DatabaseManager::activeOrder(const QJsonObject &request)
{
    const QJsonObject order = selectOne(
                "SELECT o.id,o.started_at,c.code,c.power,s.name AS station_name,s.price "
                "FROM orders o JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id "
                "WHERE o.user_id=:user AND o.status='charging'",
                {{":user", request.value("userId").toInt()}});
    return response(true, order.isEmpty() ? "当前无充电订单" : "查询成功", order);
}

QJsonObject DatabaseManager::listOrders(const QJsonObject &request)
{
    const QJsonArray rows = selectRows(
                "SELECT o.id,s.name AS station,c.code,o.status,o.started_at,o.ended_at,"
                "o.minutes,ROUND(o.energy,2) AS energy,ROUND(o.fee,2) AS fee "
                "FROM orders o JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id WHERE o.user_id=:user "
                "ORDER BY o.id DESC LIMIT 100",
                {{":user", request.value("userId").toInt()}});
    return response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::dashboard() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    QJsonObject data;
    data.insert("metrics", self->selectOne(
                    "SELECT "
                    "ROUND(COALESCE(SUM(CASE WHEN date(ended_at)=date('now','localtime') THEN fee END),0),2) AS today_revenue,"
                    "ROUND(COALESCE(SUM(CASE WHEN strftime('%Y-%m',ended_at)=strftime('%Y-%m','now','localtime') THEN fee END),0),2) AS month_revenue,"
                    "ROUND(COALESCE(SUM(fee),0),2) AS total_revenue,"
                    "COUNT(*) AS total_orders FROM orders WHERE status='completed'"));
    data.insert("chargerStatus", self->selectRows(
                    "SELECT status,COUNT(*) AS count FROM chargers GROUP BY status ORDER BY status"));
    data.insert("revenueTrend", self->selectRows(
                    "WITH RECURSIVE days(day) AS ("
                    "SELECT date('now','localtime','-6 day') UNION ALL "
                    "SELECT date(day,'+1 day') FROM days WHERE day<date('now','localtime')) "
                    "SELECT day,ROUND(COALESCE(SUM(o.fee),0),2) AS revenue "
                    "FROM days LEFT JOIN orders o ON date(o.ended_at)=day AND o.status='completed' "
                    "GROUP BY day ORDER BY day"));
    return self->response(true, "查询成功", data);
}

QJsonObject DatabaseManager::listChargers(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    QString sql = "SELECT c.id,c.code,s.name AS station,c.type,c.power,c.status,"
                  "c.charge_count,c.charge_minutes,c.last_restart "
                  "FROM chargers c JOIN stations s ON s.id=c.station_id ";
    QVariantMap bindings;
    if (request.value("stationId").toInt() > 0) {
        sql += "WHERE s.id=:station ";
        bindings.insert(":station", request.value("stationId").toInt());
    }
    sql += "ORDER BY c.code";
    return self->response(true, "查询成功", self->selectRows(sql, bindings));
}

QJsonObject DatabaseManager::restartCharger(const QJsonObject &request)
{
    QSqlQuery query(m_database);
    query.prepare("UPDATE chargers SET status='idle',last_restart=:time WHERE id=:id");
    query.bindValue(":time", nowIso());
    query.bindValue(":id", request.value("chargerId").toInt());
    if (!query.exec() || query.numRowsAffected() != 1) {
        return response(false, "远程重启失败");
    }
    return response(true, "远程重启指令已执行");
}

QJsonObject DatabaseManager::listAdminStations() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT s.id,s.name,s.area,s.address,s.latitude,s.longitude,s.price,"
                "COUNT(c.id) AS total_count,"
                "ROUND(100.0*SUM(CASE WHEN c.status!='fault' THEN 1 ELSE 0 END)/COUNT(c.id),1) AS online_rate "
                "FROM stations s LEFT JOIN chargers c ON c.station_id=s.id "
                "GROUP BY s.id ORDER BY s.id");
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::addStation(const QJsonObject &request)
{
    const QString name = request.value("name").toString().trimmed();
    const QString area = request.value("area").toString().trimmed();
    const QString address = request.value("address").toString().trimmed();
    const int chargerCount = request.value("chargerCount").toInt();
    if (name.isEmpty() || area.isEmpty() || address.isEmpty()
            || chargerCount < 1 || chargerCount > 50) {
        return response(false, "电站信息不完整或电桩数量无效");
    }

    if (!m_database.transaction()) {
        return response(false, "无法启动数据库事务");
    }
    QSqlQuery station(m_database);
    station.prepare("INSERT INTO stations(name,area,address,latitude,longitude,price,created_at) "
                    "VALUES(:name,:area,:address,:latitude,:longitude,:price,:created)");
    station.bindValue(":name", name);
    station.bindValue(":area", area);
    station.bindValue(":address", address);
    station.bindValue(":latitude", request.value("latitude").toDouble());
    station.bindValue(":longitude", request.value("longitude").toDouble());
    station.bindValue(":price", request.value("price").toDouble());
    station.bindValue(":created", nowIso());
    if (!station.exec()) {
        m_database.rollback();
        return response(false, "新增电站失败：" + station.lastError().text());
    }
    const int stationId = station.lastInsertId().toInt();
    for (int index = 1; index <= chargerCount; ++index) {
        QSqlQuery charger(m_database);
        charger.prepare("INSERT INTO chargers(station_id,code,type,power,status) "
                        "VALUES(:station,:code,:type,:power,'idle')");
        charger.bindValue(":station", stationId);
        charger.bindValue(":code",
                          QString("S%1-C%2")
                          .arg(stationId, 2, 10, QChar('0'))
                          .arg(index, 2, 10, QChar('0')));
        charger.bindValue(":type", index <= qCeil(chargerCount * 0.7) ? "快充" : "慢充");
        charger.bindValue(":power", index <= qCeil(chargerCount * 0.7) ? 120.0 : 7.0);
        if (!charger.exec()) {
            m_database.rollback();
            return response(false, "新增电桩失败：" + charger.lastError().text());
        }
    }
    if (!m_database.commit()) {
        m_database.rollback();
        return response(false, "提交新增电站事务失败");
    }
    return response(true, "电站及电桩新增成功");
}

QJsonObject DatabaseManager::listUsers(const QJsonObject &request) const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QString keyword = request.value("keyword").toString().trimmed();
    const QJsonArray rows = self->selectRows(
                "SELECT id,phone,nickname,ROUND(balance,2) AS balance,registered_at,status "
                "FROM users WHERE phone LIKE :keyword OR nickname LIKE :keyword ORDER BY id DESC",
                {{":keyword", "%" + keyword + "%"}});
    return self->response(true, "查询成功", rows);
}

QJsonObject DatabaseManager::toggleUser(const QJsonObject &request)
{
    const int userId = request.value("userId").toInt();
    const QJsonObject user = selectOne("SELECT status FROM users WHERE id=:id", {{":id", userId}});
    if (user.isEmpty()) {
        return response(false, "用户不存在");
    }
    const QString target = user.value("status").toString() == "normal" ? "frozen" : "normal";
    QSqlQuery query(m_database);
    query.prepare("UPDATE users SET status=:status WHERE id=:id");
    query.bindValue(":status", target);
    query.bindValue(":id", userId);
    if (!query.exec()) {
        return response(false, "用户状态修改失败");
    }
    return response(true, target == "normal" ? "用户已解冻" : "用户已冻结");
}

QJsonObject DatabaseManager::listAllOrders() const
{
    DatabaseManager *self = const_cast<DatabaseManager *>(this);
    const QJsonArray rows = self->selectRows(
                "SELECT o.id,u.phone,s.name AS station,c.code,o.status,o.started_at,o.ended_at,"
                "o.minutes,ROUND(o.energy,2) AS energy,ROUND(o.fee,2) AS fee "
                "FROM orders o JOIN users u ON u.id=o.user_id "
                "JOIN chargers c ON c.id=o.charger_id "
                "JOIN stations s ON s.id=c.station_id ORDER BY o.id DESC LIMIT 200");
    return self->response(true, "查询成功", rows);
}
