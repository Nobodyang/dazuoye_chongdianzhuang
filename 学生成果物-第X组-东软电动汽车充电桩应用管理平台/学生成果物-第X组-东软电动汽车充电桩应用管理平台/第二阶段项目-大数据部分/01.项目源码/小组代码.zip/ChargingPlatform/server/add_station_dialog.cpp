#include "add_station_dialog.h"
#include "ui_add_station_dialog.h"

#include <QMessageBox>

AddStationDialog::AddStationDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddStationDialog)
{
    ui->setupUi(this);
    connect(ui->buttonBox, &QDialogButtonBox::accepted,
            this, &AddStationDialog::validateAndAccept);
    connect(ui->buttonBox, &QDialogButtonBox::rejected,
            this, &QDialog::reject);
}

AddStationDialog::~AddStationDialog()
{
    delete ui;
}

QJsonObject AddStationDialog::stationData() const
{
    QJsonObject data;
    data.insert("name", ui->nameEdit->text().trimmed());
    data.insert("area", ui->areaEdit->text().trimmed());
    data.insert("address", ui->addressEdit->text().trimmed());
    data.insert("latitude", ui->latitudeSpin->value());
    data.insert("longitude", ui->longitudeSpin->value());
    data.insert("price", ui->priceSpin->value());
    data.insert("chargerCount", ui->chargerCountSpin->value());
    return data;
}

void AddStationDialog::validateAndAccept()
{
    if (ui->nameEdit->text().trimmed().isEmpty()
            || ui->areaEdit->text().trimmed().isEmpty()
            || ui->addressEdit->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, tr("信息不完整"), tr("请填写电站名称、区域和详细地址。"));
        return;
    }
    accept();
}

