#ifndef TCP_SERVER_WORKER_H
#define TCP_SERVER_WORKER_H

#include <QHash>
#include <QJsonObject>
#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

class TcpServerWorker : public QObject
{
    Q_OBJECT

public:
    explicit TcpServerWorker(QObject *parent = nullptr);

public slots:
    void start(quint16 port);
    void stop();
    void sendResponse(qintptr clientId, const QJsonObject &response);

signals:
    void requestReceived(qintptr clientId, const QJsonObject &request);
    void logMessage(const QString &message);
    void listeningChanged(bool listening, quint16 port);

private slots:
    void acceptConnection();
    void readClientData();
    void removeClient();

private:
    QTcpServer *m_server;
    QHash<QTcpSocket *, QByteArray> m_buffers;
};

#endif // TCP_SERVER_WORKER_H

