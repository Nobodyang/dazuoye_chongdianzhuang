#include "mainwindow.h"

#include <QApplication>
#include <QFile>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication application(argc, argv);
    QApplication::setOrganizationName("NeusoftTraining");
    QApplication::setApplicationName("ChargingServer");

    QFile styleFile(":/styles/theme.qss");
    if (styleFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        application.setStyleSheet(QString::fromUtf8(styleFile.readAll()));
    }

    MainWindow window;
    if (!window.initialize()) {
        QMessageBox::critical(nullptr,
                              QObject::tr("启动失败"),
                              QObject::tr("数据库初始化失败，请检查目录权限和 SQLite 驱动。"));
        return 1;
    }

    window.show();
    return application.exec();
}

