#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include <QJsonArray>
#include <QJsonObject>
#include <QSqlDatabase>
#include <QString>
#include <QVariantMap>

class DatabaseManager
{
public:
    DatabaseManager();
    ~DatabaseManager();

    bool open();
    QString databasePath() const;
    QString lastError() const;

    bool validateAdmin(const QString &username, const QString &password);
    QJsonObject handleRequest(const QJsonObject &request);

private:
    bool createTables();
    bool seedData();
    bool execute(const QString &sql);
    QJsonArray selectRows(const QString &sql, const QVariantMap &bindings = QVariantMap());
    QJsonObject selectOne(const QString &sql, const QVariantMap &bindings = QVariantMap());
    QJsonObject response(bool ok,
                         const QString &message,
                         const QJsonValue &data = QJsonValue()) const;

    QJsonObject loginUser(const QJsonObject &request);
    QJsonObject listStations(const QJsonObject &request);
    QJsonObject stationDetail(const QJsonObject &request);
    QJsonObject profile(const QJsonObject &request);
    QJsonObject updateProfile(const QJsonObject &request);
    QJsonObject recharge(const QJsonObject &request);
    QJsonObject startCharging(const QJsonObject &request);
    QJsonObject stopCharging(const QJsonObject &request);
    QJsonObject activeOrder(const QJsonObject &request);
    QJsonObject listOrders(const QJsonObject &request);
    QJsonObject dashboard() const;
    QJsonObject listChargers(const QJsonObject &request) const;
    QJsonObject restartCharger(const QJsonObject &request);
    QJsonObject listAdminStations() const;
    QJsonObject addStation(const QJsonObject &request);
    QJsonObject listUsers(const QJsonObject &request) const;
    QJsonObject toggleUser(const QJsonObject &request);
    QJsonObject listAllOrders() const;

    QString m_connectionName;
    QString m_databasePath;
    QString m_lastError;
    QSqlDatabase m_database;
};

#endif // DATABASE_MANAGER_H
