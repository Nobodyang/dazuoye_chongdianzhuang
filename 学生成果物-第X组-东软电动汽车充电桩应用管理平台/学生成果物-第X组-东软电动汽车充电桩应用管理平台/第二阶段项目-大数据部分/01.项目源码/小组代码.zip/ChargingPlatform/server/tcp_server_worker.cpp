#include "tcp_server_worker.h"

#include <QDateTime>
#include <QHostAddress>
#include <QJsonDocument>
#include <QJsonParseError>

TcpServerWorker::TcpServerWorker(QObject *parent)
    : QObject(parent)
    , m_server(nullptr)
{
}

void TcpServerWorker::start(quint16 port)
{
    if (m_server != nullptr) {
        return;
    }

    m_server = new QTcpServer(this);
    connect(m_server, &QTcpServer::newConnection,
            this, &TcpServerWorker::acceptConnection);

    const bool listening = m_server->listen(QHostAddress::Any, port);
    emit listeningChanged(listening, port);
    emit logMessage(listening
                    ? QString("TCP 服务已启动，监听端口 %1").arg(port)
                    : QString("TCP 服务启动失败：%1").arg(m_server->errorString()));
}

void TcpServerWorker::stop()
{
    if (m_server == nullptr) {
        return;
    }

    const QList<QTcpSocket *> clients = m_buffers.keys();
    for (QTcpSocket *client : clients) {
        client->disconnectFromHost();
        client->deleteLater();
    }
    m_buffers.clear();
    m_server->close();
    m_server->deleteLater();
    m_server = nullptr;
    emit listeningChanged(false, 0);
    emit logMessage("TCP 服务已停止");
}

void TcpServerWorker::acceptConnection()
{
    while (m_server->hasPendingConnections()) {
        QTcpSocket *client = m_server->nextPendingConnection();
        m_buffers.insert(client, QByteArray());
        connect(client, &QTcpSocket::readyRead,
                this, &TcpServerWorker::readClientData);
        connect(client, &QTcpSocket::disconnected,
                this, &TcpServerWorker::removeClient);
        emit logMessage(QString("客户端已连接：%1:%2")
                        .arg(client->peerAddress().toString())
                        .arg(client->peerPort()));
    }
}

void TcpServerWorker::readClientData()
{
    QTcpSocket *client = qobject_cast<QTcpSocket *>(sender());
    if (client == nullptr || !m_buffers.contains(client)) {
        return;
    }

    QByteArray &buffer = m_buffers[client];
    buffer.append(client->readAll());
    while (buffer.contains('\n')) {
        const int delimiterIndex = buffer.indexOf('\n');
        const QByteArray line = buffer.left(delimiterIndex).trimmed();
        buffer.remove(0, delimiterIndex + 1);
        if (line.isEmpty()) {
            continue;
        }

        QJsonParseError error;
        const QJsonDocument document = QJsonDocument::fromJson(line, &error);
        if (error.error != QJsonParseError::NoError || !document.isObject()) {
            QJsonObject invalid;
            invalid.insert("ok", false);
            invalid.insert("message", "JSON 请求格式错误");
            sendResponse(client->socketDescriptor(), invalid);
            emit logMessage("收到无法解析的 JSON 请求");
            continue;
        }

        emit requestReceived(client->socketDescriptor(), document.object());
    }
}

void TcpServerWorker::sendResponse(qintptr clientId, const QJsonObject &response)
{
    for (QTcpSocket *client : m_buffers.keys()) {
        if (client->socketDescriptor() == clientId
                && client->state() == QAbstractSocket::ConnectedState) {
            client->write(QJsonDocument(response).toJson(QJsonDocument::Compact));
            client->write("\n");
            return;
        }
    }
}

void TcpServerWorker::removeClient()
{
    QTcpSocket *client = qobject_cast<QTcpSocket *>(sender());
    if (client == nullptr) {
        return;
    }
    emit logMessage(QString("客户端已断开：%1:%2")
                    .arg(client->peerAddress().toString())
                    .arg(client->peerPort()));
    m_buffers.remove(client);
    client->deleteLater();
}

